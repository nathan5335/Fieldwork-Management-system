# Project Progress — NGO-Based Student Field Work Management System

Tracking against the original 79-section spec. Read this first in any new
session before continuing the build.

## ✅ DONE — Backend (Django + DRF + Channels), fully working & tested

- Project scaffold: `django-admin startproject config .` + 9 apps
  (accounts, colleges, ngos, applications, attendance, reports,
  notifications, documents, dashboard), modular structure, `common/` package
  for shared permissions/pagination/validators.
- Custom User model, 5 roles (Admin/Principal/Teacher/Student/NGO), secure
  password hashing, UUID pk.
- Full data model: College, PrincipalProfile, TeacherProfile, StudentProfile,
  NGO, NGOVerificationDocument, Application, NGOPrioritySelection, Approval
  (audit trail), Attendance, Report, PhotoUpload, Grade, Document,
  Notification. All migrations generated & applied cleanly.
- **Core workflow state machine** (`applications/services.py`): submit →
  teacher review → principal review → priority-1/2/3 NGO cascade (approve
  cancels lower priorities; reject activates next priority; all-3-reject →
  ALL_NGOS_REJECTED → reapply) → assignment → grading. Every transition in
  `transaction.atomic()` with an Approval audit row and a notification.
- JWT auth (Simple JWT): login/refresh/logout+blacklist/me. Registration:
  Principal+College self-registration, Principal→Teacher creation,
  Teacher→Student creation, NGO self-registration.
- Daily report **3-attempts-per-day limit enforced server-side** against a
  live DB count inside a transaction (not a client-supplied number).
- Attendance marking (NGO-only, one record/day/student, upsert-corrects).
- Photo upload + NGO review of reports + A/B/C/D grading (marks application
  COMPLETED).
- Django Channels: JWT-authenticated WebSocket (`config/middleware.py`,
  token via `?token=` query param, user derived only from validated token
  claims), per-user private group `user_<id>`, `NotificationConsumer`,
  `notify()` service that persists to DB and pushes via
  `transaction.on_commit` (so rollbacks never fire phantom events).
- Reusable DRF permission classes: IsAdmin/IsPrincipal/IsTeacher/IsStudent/
  IsNGO/IsCollegeMember/IsAssignedTeacher/IsAssignedNGO/IsOwner.
- Role-scoped REST endpoints for every resource above (see backend/README.md
  for the full endpoint list) + one role-shaped `/api/dashboard/summary/`.
- `seed_demo_data` management command — creates Admin, Principal+College, 2
  Teachers, 4 Students, 3 NGOs, and 4 sample applications sitting at
  different pipeline stages (one fully graded end-to-end). **Verified
  working** — ran successfully, all statuses/notifications/audit rows
  correct on inspection.
- **14 automated tests, all passing** (`applications/tests.py`): NGO
  duplicate-validation, full priority cascade in both directions, all-3-
  reject→reapply, priority-1 cancellation, report 4th-attempt block, and
  4 API-level permission-boundary tests (cross-role, cross-college,
  cross-NGO, unauthenticated — all correctly blocked with 403/404/401).
- `requirements.txt`, `.env.example`, full `backend/README.md` (install,
  run, demo credentials, endpoint list, WebSocket test snippet,
  troubleshooting).

## ✅ DONE — Frontend foundation (Next.js + TypeScript + Tailwind v4)

- Scaffolded with `create-next-app` (App Router, `src/` dir, Tailwind v4).
  Note: `shadcn@latest init` CLI could NOT run in this sandbox (its registry
  domain `ui.shadcn.com` isn't in the allowed egress list) — worked around
  by hand-writing shadcn-style primitives instead (same visual/API
  conventions, no CLI dependency): `components/ui/{button,card,input,label,
  badge,empty-state,skeleton}.tsx`, using `cva` + `tailwind-merge` +
  `@radix-ui/react-slot` for `asChild`. Radix installed for future
  Dialog/Tabs/DropdownMenu/Select/Avatar use.
- Dark enterprise design tokens in `globals.css` (Tailwind v4 `@theme
  inline`) — ink-navy background, distinct accent hue per role (Admin gold /
  Principal violet / Teacher teal / Student blue / NGO coral) per spec
  section 54. Deliberately NOT using `next/font/google` (that domain is also
  outside this sandbox's egress list) — using a system-font stack instead;
  works everywhere with zero external font fetch, on the user's machine too.
- **Auth architecture, done properly**: access token lives in memory only
  (`lib/api.ts`), refresh token in an **httpOnly cookie** set by Next.js
  Route Handlers (`app/api/auth/{login,refresh,logout}/route.ts`) that proxy
  to Django — browser JS never touches the refresh token, matching spec
  section 11 exactly. Axios response interceptor does silent-refresh-and-
  retry on a 401. `AuthProvider`/`useAuth()` in `lib/auth-context.tsx`
  attempts silent refresh on mount so a hard reload doesn't force re-login.
- `RoleGuard` component — redirects unauthenticated users to `/login` and
  wrong-role users to their own dashboard (UI convenience; real enforcement
  is server-side per-endpoint, already in the backend).
- `useNotifications()` hook — fetches notification history over REST, opens
  exactly one authenticated WebSocket per mount (token via query param),
  prepends live pushes, exposes `markRead`/`markAllRead`.
- Shared layout: `Sidebar`, `DashboardShell`, `NotificationBell` (bell +
  unread badge + live-connection dot + dropdown panel) — used by every role
  dashboard so per-dashboard code only supplies nav items + page content.
- Pages built and passing `tsc --noEmit` with zero errors: landing page
  (`/`), shared login (`/login`), hidden admin login (`/admin-portal-access`,
  unlinked from nav), Principal+College registration (`/register/principal`),
  NGO registration (`/register/ngo`).
- **Full Student dashboard** (`/student/*`) — the first fully wired,
  end-to-end role dashboard: `dashboard` (live summary cards),
  `application` (NGO priority picker enforcing 3 distinct NGOs, status +
  audit-trail timeline, Cancel-Priority-1, Reapply-after-all-rejected),
  `attendance` (summary + history), `reports` (submit form with a live
  "N/3 attempts used today" counter that disables the button at the limit,
  history with NGO feedback), `photos` (upload with `capture="environment"`
  for mobile camera, gallery), `notifications` (full list, mark read/all),
  `profile` (read-only for now — no PATCH endpoint wired yet).
- **`npm run lint` → 0 errors, 0 remaining errors (2 warnings, intentionally
  downgraded — see eslint.config.mjs comment). `npm run build` → succeeds
  cleanly, all 18 routes compile** (this is the real proof point: a fresh
  `git clone` + `npm install` + `npm run build` on the user's machine will
  work, not just "looks right in the editor").
- Extracted for reuse across roles: `NotificationsPageContent`,
  `ProfilePageContent`, `DataTable` (generic typed table), `ReviewActions`
  (approve/reject-with-reason control used by Teacher review now, and by
  Principal review + NGO respond next).
- **Full Teacher dashboard** (`/teacher/*`) — second fully wired role:
  `dashboard` (summary cards), `students` (searchable list via `DataTable`),
  `approved-students` (students with an ASSIGNED/COMPLETED application),
  `applications` (pending-review queue with `ReviewActions` calling
  `POST .../teacher-review/`, plus a full history list), `attendance`
  (monitoring list + a computed "<75%" low-attendance alert banner),
  `reports` (monitoring list with feedback), `notes` (PDF/doc upload via
  `POST /api/documents/` + list), `notifications`, `profile` (shared
  components). No rejected-student-list page, per spec section 46.
  `npm run build` → 27 routes, still 0 lint errors.

- **Full Principal dashboard** (`/principal/*`): `dashboard` (8 live cards +
  Recharts "students per NGO" chart), `teachers` (list + create-teacher form
  via react-hook-form/zod -> `POST /auth/register/teacher/`), `students`,
  `approved-students`, `attendance`, `reports` (all shared components; backend
  scopes to the principal's college), `applications` (pending-principal queue
  using `ReviewActions` -> `.../principal-review/`), notifications, profile.
- **Teacher can now create Students** (`StudentCreateForm` on
  `/teacher/students`, -> `POST /auth/register/student/`).
- **Full NGO dashboard** (`/ngo/*`): `dashboard` (6 cards + pipeline and
  grade-distribution charts), `applications` (actionable queue: Accept /
  Decline with reason, plus accepted-students list), `attendance` (mark or
  correct a day for an accepted student + history), `reports` (per-report
  approve / request-revision with feedback, attempt "n of 3", attachment link,
  plus photo-evidence gallery), `grades` (A/B/C/D + remarks, update allowed),
  notifications, profile (shows org details + verification status).
- Shared components/hooks added: `ApplicationReviewQueue`, `StudentsListContent`,
  `ApprovedStudentsContent`, `AttendanceMonitorContent`, `ReportsMonitorContent`,
  `BarChartCard`, `StudentCreateForm`, `useAcceptedStudents`.
- **Backend fix found while building the NGO UI**: the NGO queue endpoint
  returned anonymous priority slots (no student identity) and the applications
  list lacked student/NGO ids. Added `NGOQueueItemSerializer` and `student` /
  `assigned_ngo` ids on the list serializer, with 2 regression tests
  (backend suite is now **16 tests, all passing**).
- `npm run lint` -> 0 errors; `npm run build` -> **43 routes**, clean.

## ✅ DONE — Admin dashboard + live end-to-end verification

- **Full Admin dashboard** (`/admin/*`), all 14 sections from spec section 51:
  `dashboard` (12 live stats + accounts-by-role chart + recent-activity feed
  from the `Approval` audit table), `users`/`students`/`teachers`/`principals`
  (one shared `UsersTable` component, filtered by role), `colleges`, `ngos`
  (**verification workflow**: view uploaded documents, Verify/Revoke button
  wired to `POST /api/ngos/<id>/verify/`), `applications` (status-filterable,
  system-wide), `attendance`, `reports`, `grades`, `documents`,
  `notifications`, `settings` (read-only system info — deliberately not a
  fake settings form with nothing behind it).
- **Backend gaps found and fixed while building Admin UI** (this is exactly
  why building the UI against a real backend matters):
  - No admin user-directory endpoint existed → added
    `GET /api/auth/users/` (`IsAdmin`, role filter, search) + 4 tests.
  - `NGOSerializer` didn't expose `verification_documents` → added it, so
    Admin can actually see what an NGO uploaded before verifying → 3 tests,
    including confirming **an NGO cannot verify itself** (403).
  - Backend test count: **23 tests, all passing.**
- `npm run lint` → 0 errors; `npm run build` → **57 routes**, clean.
- **Live end-to-end verification** (the thing that was still unverified
  before this round) — ran the real Django server + real Next.js production
  build together against the seeded demo data and confirmed, with actual
  HTTP/WebSocket traffic (not just static analysis):
  - **Auth proxy**: login issues an access token + sets an httpOnly refresh
    cookie (refresh token never appears in any JSON body); the access token
    works directly against Django; silent refresh rotates the cookie; the
    pre-rotation token is then rejected (blacklist confirmed); logout kills
    the session; wrong password is rejected with no cookie set.
  - **WebSocket notifications, the highest-risk piece of the whole spec**:
    a connection with no token is refused; a connection with a garbage
    token is refused; two real authenticated sockets (Principal, Student)
    connect successfully; a genuine REST action (Teacher approving an
    application) triggers a real-time push to the Principal's socket
    **and the Student's socket receives nothing** — i.e. no cross-user
    notification leakage, confirmed by direct observation, not just code
    review. Reusable check: `backend/scripts/ws_e2e_check.py`.
  - **Route smoke test**: all 25 sampled routes across all 5 roles return
    HTTP 200 (no server-side crashes).
  - **API smoke test**: every endpoint every dashboard actually calls,
    called for real as each of the 5 seeded demo users, returns 200 with
    real data — 30 calls, 0 failures.

## ✅ DONE — Frontend design retheme (dark botanical / editorial)

Restyled the frontend ONLY, on request, toward a dark botanical/editorial
look (deep charcoal-forest background, muted sage green as the single
brand accent, warm cream text, serif display headings) — no backend,
routing, or functional changes.

- `globals.css`: full palette swap, same variable names (`--background`,
  `--surface`, `--border`, `--foreground`, `--muted`, role accents, etc.),
  so nearly every component re-themed automatically via CSS custom
  properties. Added `--brand` / `--brand-foreground` as the one consistent
  primary-action color site-wide (role accents are now reserved for
  sidebar/identity use only, not buttons/links/focus rings).
- `Badge`: switched from filled pills to dot + label (status is never
  color-only).
- `Button`: default/link variants now use `--brand` instead of a hardcoded
  role color.
- Shared multi-role primitives (`Input`, `ReviewActions` textarea,
  `BarChartCard` default) moved off the old hardcoded student-blue onto
  `--brand`; genuinely role-specific components (NGOPriorityForm,
  ApplicationTimeline — both student-only; UsersTable — admin-only) kept
  their own role accent, since that was already the established pattern.
- `Sidebar`: wordmark now serif, logo mark is a small `Leaf` icon
  (lucide-react, already a dependency — no new assets).
- New `AuthLayout` component: two-column shell (branded left panel with a
  faint inline-SVG line decoration + serif tagline, form on the right),
  used by `/login` and `/admin-portal-access`. `LoginForm` itself untouched
  except its heading font.
- Landing page (`/`) and both registration pages: serif headings, adjusted
  copy tone, no structural/route changes. Deliberately did NOT add
  fabricated stats ("120+ Students" etc.) some reference designs use for
  this kind of landing page — this app shows real data everywhere else, so
  inventing numbers on the public page would break that consistency.
  Deliberately used inline SVG line-art instead of photography for hero/
  decoration — no stock photos bundled into the repo (copyright/licensing
  risk for a deliverable, and no image assets were supplied).
- Verified: `tsc --noEmit` clean, `npm run lint` → 0 errors (same 2
  pre-existing warnings), `npm run build` → still 57 routes, confirmed the
  new palette's hex values are actually present in the compiled CSS output
  (not just the source).

## ⏳ NOT DONE YET

1. Not yet covered by dedicated tests: the `attendance` and `reports` apps
   beyond the 3-attempt-limit test, `documents`, `notifications` app logic,
   `dashboard` aggregation correctness. (The *integration* — real HTTP calls
   above — passed; these would be unit-level regression tests for the same
   code.)
2. Profile editing (PATCH) — `MeView` is GET-only. Profile photo upload UI.
3. `AttendanceCalendar` widget (currently lists), shared `FileUploader`,
   toast component for live notifications (bell + panel exist, popup toast
   does not), pagination controls (lists fetch up to 100–200 rows, no page
   UI — fine for a demo dataset, would matter at real scale).
4. Top-level README tying backend + frontend + `.env.local` together (each
   has its own README/`.env.example` right now).
5. `drf-spectacular` schema has cosmetic enum-naming collision warnings
   (harmless — schema is still valid — just not manually polished with
   `ENUM_NAME_OVERRIDES`).

## HOW TO RESUME

1. The whole backend lives in `/home/claude/ngo-fieldwork-system/backend/`
   inside the sandbox for THIS chat session only — it does not persist to a
   new conversation. Each checkpoint zip presented in-chat is the durable
   copy; if starting a fresh conversation, **upload the latest zip** and
   ask Claude to unpack and continue from it.
2. To verify the backend still works after unpacking: `pip install -r
   requirements.txt`, `python manage.py migrate`, `python manage.py test`,
   `python manage.py seed_demo_data`, `python manage.py runserver`.
3. Frontend: `cd frontend && npm install`, create `.env.local` with
   `NEXT_PUBLIC_API_URL=http://localhost:8000/api`,
   `NEXT_PUBLIC_WS_URL=ws://localhost:8000/ws`,
   `DJANGO_API_URL=http://localhost:8000/api`, then `npm run dev`.
4. Next concrete step: do the live click-through (item 2 above), then build
   `/admin/*`.
