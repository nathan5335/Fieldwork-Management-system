"""
Root URL configuration.

NOTE on "hidden" Admin access (spec section 13): the Django admin site at
/admin/ is left enabled for local demo/debugging convenience (seeded data
inspection, quick fixes). The REAL Admin-role API surface used by the
Next.js Admin dashboard is the ordinary role-checked REST API below
(/api/...), reached from the frontend's un-advertised /admin-portal-access
route — hiding that route is a UX choice, never the security boundary.
Every admin-only endpoint still enforces IsAdmin server-side regardless of
which URL the request came in on.
"""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path("admin/", admin.site.urls),

    path("api/auth/", include("accounts.urls")),
    path("api/colleges/", include("colleges.urls")),
    path("api/ngos/", include("ngos.urls")),
    path("api/applications/", include("applications.urls")),
    path("api/attendance/", include("attendance.urls")),
    path("api/reports/", include("reports.urls")),
    path("api/documents/", include("documents.urls")),
    path("api/notifications/", include("notifications.urls")),
    path("api/dashboard/", include("dashboard.urls")),

    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
