"""WebSocket authentication for Django Channels using the same SimpleJWT
access tokens the REST API issues. The token is passed as a query-string
parameter (browsers cannot set custom headers on a WebSocket handshake):

    ws://localhost:8000/ws/notifications/?token=<access_token>

The user is derived ONLY from a validated token's claims — a connection can
never claim to be a different user_id than the one the token was issued
for."""

from urllib.parse import parse_qs

from channels.db import database_sync_to_async
from channels.middleware import BaseMiddleware
from django.contrib.auth.models import AnonymousUser
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.tokens import AccessToken


@database_sync_to_async
def _get_user_from_token(token):
    from accounts.models import User

    try:
        validated = AccessToken(token)
        return User.objects.get(id=validated["user_id"], is_active=True)
    except (TokenError, InvalidToken, User.DoesNotExist, KeyError, ValueError):
        return AnonymousUser()


class JWTAuthMiddleware(BaseMiddleware):
    async def __call__(self, scope, receive, send):
        query_string = scope.get("query_string", b"").decode()
        token = parse_qs(query_string).get("token", [None])[0]
        scope["user"] = await _get_user_from_token(token) if token else AnonymousUser()
        return await super().__call__(scope, receive, send)
