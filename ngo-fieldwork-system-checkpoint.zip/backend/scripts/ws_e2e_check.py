"""Live WebSocket end-to-end check (needs a RUNNING server + seeded data).

    python manage.py seed_demo_data
    python manage.py runserver
    pip install websockets
    python scripts/ws_e2e_check.py

Verifies: unauthenticated / garbage-token sockets are refused; an
authenticated Principal socket receives a real-time push when a Teacher
approves an application over plain REST; and a different user's socket
(student1) receives nothing, i.e. no cross-user leakage.
"""
import asyncio
import json
import urllib.request

import websockets

API = "http://127.0.0.1:8000/api"
WS = "ws://127.0.0.1:8000/ws/notifications/"


def _call(method, path, body=None, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(API + path, data, headers, method=method)
    return json.load(urllib.request.urlopen(req))


def login(email, password):
    return _call("POST", "/auth/login/", {"email": email, "password": password})["access"]


async def listen(name, token, out, ready):
    async with websockets.connect(f"{WS}?token={token}", origin="http://127.0.0.1:3000") as ws:
        hello = json.loads(await ws.recv())
        assert hello["type"] == "connected", hello
        ready.set()
        try:
            while True:
                out.append((name, json.loads(await asyncio.wait_for(ws.recv(), timeout=5))))
        except asyncio.TimeoutError:
            pass


async def main():
    principal = login("principal@demo.local", "DemoPrincipal#123")
    student1 = login("student1@demo.local", "DemoStudent#123")

    print("Rejected connections:")
    for label, url in [("no token", WS), ("garbage token", f"{WS}?token=abc.def.ghi")]:
        try:
            async with websockets.connect(url, origin="http://127.0.0.1:3000") as ws:
                await ws.recv()
            print(f"  {label}: UNEXPECTEDLY ACCEPTED  <-- FAIL")
        except websockets.exceptions.ConnectionClosed as exc:
            print(f"  {label}: refused (closed, code={exc.rcvd.code if exc.rcvd else '?'})")
        except Exception as exc:  # noqa: BLE001
            print(f"  {label}: refused ({type(exc).__name__})")

    out = []
    ready_p, ready_s = asyncio.Event(), asyncio.Event()
    tasks = [
        asyncio.create_task(listen("principal", principal, out, ready_p)),
        asyncio.create_task(listen("student1", student1, out, ready_s)),
    ]
    await asyncio.wait_for(ready_p.wait(), 5)
    await asyncio.wait_for(ready_s.wait(), 5)
    print("Principal and student1 sockets connected + authenticated.")

    pending = []
    teacher = None
    for email in ("teacher1@demo.local", "teacher2@demo.local"):
        candidate = login(email, "DemoTeacher#123")
        rows = _call("GET", "/applications/?status=SUBMITTED_TO_TEACHER", token=candidate)["results"]
        if rows:
            teacher, pending = candidate, rows
            break
    if not pending:
        print("No application awaiting teacher review (re-seed the DB) - cannot run push test.")
        return
    app_id = pending[0]["id"]
    _call("POST", f"/applications/{app_id}/teacher-review/", {"approve": True}, teacher)
    print(f"Teacher approved application #{app_id} over REST.")

    await asyncio.gather(*tasks)
    print("\nFrames received:")
    for who, msg in out:
        print(f"  -> {who}: {msg.get('notification_type')} | {msg.get('title')}")

    principal_ok = any(m.get("notification_type") == "TEACHER_APPROVED" for w, m in out if w == "principal")
    student_leak = [m for w, m in out if w == "student1"]
    print(f"\nPrincipal received real-time push : {principal_ok}")
    print(f"student1 received nothing (no leak): {len(student_leak) == 0}")


asyncio.run(main())
