from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from colleges.models import College, PrincipalProfile, TeacherProfile, StudentProfile

from .models import User


class UserSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(source="get_full_name", read_only=True)

    class Meta:
        model = User
        fields = [
            "id", "email", "first_name", "last_name", "full_name", "phone",
            "role", "profile_photo", "is_active", "is_verified", "created_at",
        ]
        read_only_fields = ["id", "role", "is_active", "is_verified", "created_at"]


class RoleTokenObtainPairSerializer(TokenObtainPairSerializer):
    """Adds role + display name into the JWT claims and the login response
    body, so the frontend can route to the right dashboard without an extra
    round trip. Admin authenticates through the same endpoint — the hidden
    `/admin-portal-access` route is a frontend convenience only, never the
    security boundary (see README/security notes)."""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["role"] = user.role
        token["full_name"] = user.get_full_name()
        return token

    def validate(self, attrs):
        data = super().validate(attrs)
        data["user"] = UserSerializer(self.user).data
        return data


class PrincipalRegistrationSerializer(serializers.Serializer):
    """Principal self-registration: creates the User, the College, and the
    PrincipalProfile linking them, atomically."""

    # Principal
    first_name = serializers.CharField(max_length=150)
    last_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    email = serializers.EmailField()
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, validators=[validate_password])
    confirm_password = serializers.CharField(write_only=True)

    # College
    college_name = serializers.CharField(max_length=255)
    college_code = serializers.CharField(max_length=30)
    address = serializers.CharField()
    district = serializers.CharField(max_length=100)
    state = serializers.CharField(max_length=100)
    contact_number = serializers.CharField(max_length=20)
    official_email = serializers.EmailField()
    website = serializers.URLField(required=False, allow_blank=True)

    def validate(self, attrs):
        if attrs["password"] != attrs.pop("confirm_password"):
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        if User.objects.filter(email__iexact=attrs["email"]).exists():
            raise serializers.ValidationError({"email": "A user with this email already exists."})
        if College.objects.filter(code__iexact=attrs["college_code"]).exists():
            raise serializers.ValidationError({"college_code": "This college code is already registered."})
        return attrs

    @transaction.atomic
    def create(self, validated_data):
        user = User.objects.create_user(
            email=validated_data["email"],
            password=validated_data["password"],
            first_name=validated_data["first_name"],
            last_name=validated_data.get("last_name", ""),
            phone=validated_data.get("phone", ""),
            role=User.Role.PRINCIPAL,
        )
        college = College.objects.create(
            name=validated_data["college_name"],
            code=validated_data["college_code"],
            address=validated_data["address"],
            district=validated_data["district"],
            state=validated_data["state"],
            contact_number=validated_data["contact_number"],
            official_email=validated_data["official_email"],
            website=validated_data.get("website", ""),
        )
        PrincipalProfile.objects.create(user=user, college=college)
        return user


class TeacherCreateSerializer(serializers.Serializer):
    """Used by a Principal to create a Teacher account in their own college.
    The requesting Principal (and therefore the college) comes from the
    view's request context, never from the request body."""

    first_name = serializers.CharField(max_length=150)
    last_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    email = serializers.EmailField()
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, validators=[validate_password])
    employee_id = serializers.CharField(max_length=50)
    department = serializers.CharField(max_length=150)
    designation = serializers.CharField(max_length=150, required=False, allow_blank=True)

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("A user with this email already exists.")
        return value

    @transaction.atomic
    def create(self, validated_data):
        principal_user = self.context["request"].user
        college = principal_user.principal_profile.college

        if TeacherProfile.objects.filter(
            college=college, employee_id__iexact=validated_data["employee_id"]
        ).exists():
            raise serializers.ValidationError({"employee_id": "This employee ID is already in use at your college."})

        user = User.objects.create_user(
            email=validated_data["email"],
            password=validated_data["password"],
            first_name=validated_data["first_name"],
            last_name=validated_data.get("last_name", ""),
            phone=validated_data.get("phone", ""),
            role=User.Role.TEACHER,
            is_verified=True,
        )
        return TeacherProfile.objects.create(
            user=user,
            college=college,
            employee_id=validated_data["employee_id"],
            department=validated_data["department"],
            designation=validated_data.get("designation", ""),
            created_by=principal_user,
        )


class StudentCreateSerializer(serializers.Serializer):
    """Used by a Teacher to create a Student account. The Teacher becomes
    the assigned in-charge automatically."""

    first_name = serializers.CharField(max_length=150)
    last_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    email = serializers.EmailField()
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, validators=[validate_password])
    student_id = serializers.CharField(max_length=50)
    register_number = serializers.CharField(max_length=50)
    course = serializers.CharField(max_length=150)
    program = serializers.CharField(max_length=150, required=False, allow_blank=True)
    year = serializers.IntegerField(min_value=1)
    semester = serializers.IntegerField(min_value=1)
    department = serializers.CharField(max_length=150)
    address = serializers.CharField(required=False, allow_blank=True)
    emergency_contact = serializers.CharField(max_length=20, required=False, allow_blank=True)

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("A user with this email already exists.")
        return value

    @transaction.atomic
    def create(self, validated_data):
        teacher_user = self.context["request"].user
        teacher_profile = teacher_user.teacher_profile
        college = teacher_profile.college

        if StudentProfile.objects.filter(
            college=college, student_id__iexact=validated_data["student_id"]
        ).exists():
            raise serializers.ValidationError({"student_id": "This student ID is already in use at your college."})

        user = User.objects.create_user(
            email=validated_data["email"],
            password=validated_data["password"],
            first_name=validated_data["first_name"],
            last_name=validated_data.get("last_name", ""),
            phone=validated_data.get("phone", ""),
            role=User.Role.STUDENT,
            is_verified=True,
        )
        return StudentProfile.objects.create(
            user=user,
            college=college,
            teacher=teacher_profile,
            student_id=validated_data["student_id"],
            register_number=validated_data["register_number"],
            course=validated_data["course"],
            program=validated_data.get("program", ""),
            year=validated_data["year"],
            semester=validated_data["semester"],
            department=validated_data["department"],
            address=validated_data.get("address", ""),
            emergency_contact=validated_data.get("emergency_contact", ""),
            created_by=teacher_user,
        )
