from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User


class AdminUserDirectoryTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(email="admin@test.local", password="TestPass#123", first_name="Ada")
        self.student = User.objects.create_user(
            email="s@test.local", password="TestPass#123", first_name="Stu", role=User.Role.STUDENT
        )
        User.objects.create_user(email="t@test.local", password="TestPass#123", first_name="Tea", role=User.Role.TEACHER)
        self.client = APIClient()

    def _login(self, email):
        response = self.client.post("/api/auth/login/", {"email": email, "password": "TestPass#123"})
        self.assertEqual(response.status_code, 200)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {response.data['access']}")

    def test_admin_can_list_and_filter_by_role(self):
        self._login("admin@test.local")
        everyone = self.client.get("/api/auth/users/")
        self.assertEqual(everyone.status_code, 200)
        self.assertEqual(everyone.data["count"], 3)

        teachers = self.client.get("/api/auth/users/", {"role": "TEACHER"})
        self.assertEqual([u["email"] for u in teachers.data["results"]], ["t@test.local"])

    def test_non_admin_cannot_list_users(self):
        self._login("s@test.local")
        self.assertEqual(self.client.get("/api/auth/users/").status_code, 403)

    def test_unauthenticated_cannot_list_users(self):
        self.assertEqual(self.client.get("/api/auth/users/").status_code, 401)

    def test_login_response_carries_role_for_frontend_routing(self):
        response = self.client.post("/api/auth/login/", {"email": "admin@test.local", "password": "TestPass#123"})
        self.assertEqual(response.data["user"]["role"], "ADMIN")
