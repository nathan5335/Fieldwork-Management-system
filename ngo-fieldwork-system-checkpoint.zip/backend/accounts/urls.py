from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView

from . import views

urlpatterns = [
    path("login/", views.LoginView.as_view(), name="auth-login"),
    path("refresh/", TokenRefreshView.as_view(), name="auth-refresh"),
    path("logout/", views.LogoutView.as_view(), name="auth-logout"),
    path("me/", views.MeView.as_view(), name="auth-me"),
    path("users/", views.UserListView.as_view(), name="auth-users"),
    path("register/principal/", views.RegisterPrincipalView.as_view(), name="register-principal"),
    path("register/teacher/", views.TeacherCreateView.as_view(), name="register-teacher"),
    path("register/student/", views.StudentCreateView.as_view(), name="register-student"),
]
