from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView  # noqa: F401
from rest_framework_simplejwt.tokens import RefreshToken

from rest_framework.filters import OrderingFilter, SearchFilter
from django_filters.rest_framework import DjangoFilterBackend

from common.pagination import StandardResultsPagination
from common.permissions import IsAdmin, IsPrincipal, IsTeacher

from .models import User
from .serializers import (
    PrincipalRegistrationSerializer,
    RoleTokenObtainPairSerializer,
    StudentCreateSerializer,
    TeacherCreateSerializer,
    UserSerializer,
)


class LoginView(TokenObtainPairView):
    """Shared login for Student / Teacher / Principal / NGO / Admin. The
    Admin-only frontend route is just a different page hitting this same
    endpoint — role is enforced server-side on every subsequent request."""

    serializer_class = RoleTokenObtainPairSerializer
    permission_classes = [permissions.AllowAny]


class LogoutView(APIView):
    """Blacklists the supplied refresh token so it can no longer be used to
    mint new access tokens."""

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        refresh_token = request.data.get("refresh")
        if not refresh_token:
            return Response({"detail": "Refresh token is required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            RefreshToken(refresh_token).blacklist()
        except Exception:
            return Response({"detail": "Invalid or already-expired token."}, status=status.HTTP_400_BAD_REQUEST)
        return Response(status=status.HTTP_205_RESET_CONTENT)


class RegisterPrincipalView(generics.CreateAPIView):
    """POST /api/auth/register/principal/ — Principal self-registers, along
    with the College they run."""

    serializer_class = PrincipalRegistrationSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)


class TeacherCreateView(generics.CreateAPIView):
    """POST /api/auth/register/teacher/ — Principal creates a Teacher in
    their own college."""

    serializer_class = TeacherCreateSerializer
    permission_classes = [permissions.IsAuthenticated, IsPrincipal]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        teacher_profile = serializer.save()
        return Response(UserSerializer(teacher_profile.user).data, status=status.HTTP_201_CREATED)


class StudentCreateView(generics.CreateAPIView):
    """POST /api/auth/register/student/ — Teacher creates a Student and
    becomes their assigned in-charge."""

    serializer_class = StudentCreateSerializer
    permission_classes = [permissions.IsAuthenticated, IsTeacher]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        student_profile = serializer.save()
        return Response(UserSerializer(student_profile.user).data, status=status.HTTP_201_CREATED)


class MeView(APIView):
    """GET /api/auth/me/ — the authenticated user's own profile."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)


class UserListView(generics.ListAPIView):
    """GET /api/auth/users/ — Admin-only directory of every account, with
    role filter and search. Powers the Admin Users/Students/Teachers/
    Principals pages."""

    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdmin]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ["role", "is_active", "is_verified"]
    search_fields = ["email", "first_name", "last_name"]
    ordering_fields = ["created_at", "email"]
    queryset = User.objects.all()
