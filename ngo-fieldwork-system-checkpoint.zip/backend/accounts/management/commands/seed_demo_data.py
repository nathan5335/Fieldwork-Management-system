"""Seeds a small but realistic demo dataset exercising the full workflow:
a college with a principal/teachers/students, three NGOs, and applications
sitting at several different stages of the pipeline (including one fully
graded end-to-end, and one that was rejected by all three NGOs so the
Reapply button has something to show).

Safe to re-run: uses get_or_create keyed on unique fields throughout.
"""

import datetime

from django.core.management.base import BaseCommand
from django.db import transaction

from accounts.models import User
from applications import services as app_services
from attendance import services as attendance_services
from colleges.models import College, PrincipalProfile, StudentProfile, TeacherProfile
from ngos.models import NGO
from reports import services as report_services


class Command(BaseCommand):
    help = "Seed demo Admin/Principal/Teachers/Students/NGOs and sample applications."

    @transaction.atomic
    def handle(self, *args, **options):
        self.stdout.write("Seeding demo data...")

        # --- Admin -----------------------------------------------------
        if not User.objects.filter(email="admin@demo.local").exists():
            User.objects.create_superuser(
                email="admin@demo.local", password="DemoAdmin#123", first_name="System", last_name="Admin",
            )
        self.stdout.write(self.style.SUCCESS("  Admin ready: admin@demo.local / DemoAdmin#123"))

        # --- College + Principal ----------------------------------------
        principal_user, created = User.objects.get_or_create(
            email="principal@demo.local",
            defaults=dict(first_name="Anitha", last_name="Menon", role=User.Role.PRINCIPAL, is_verified=True),
        )
        if created:
            principal_user.set_password("DemoPrincipal#123")
            principal_user.save()

        college, _ = College.objects.get_or_create(
            code="GCE001",
            defaults=dict(
                name="Government College of Engineering", address="MG Road, Kottayam",
                district="Kottayam", state="Kerala", contact_number="9800000001",
                official_email="office@gce-demo.edu", website="https://gce-demo.edu",
            ),
        )
        PrincipalProfile.objects.get_or_create(user=principal_user, college=college)
        self.stdout.write(self.style.SUCCESS("  Principal ready: principal@demo.local / DemoPrincipal#123"))

        # --- Teachers -----------------------------------------------------
        teacher_defs = [
            ("teacher1@demo.local", "Rahul", "Nair", "T001", "Computer Applications"),
            ("teacher2@demo.local", "Divya", "Pillai", "T002", "Computer Science"),
        ]
        teachers = []
        for email, fname, lname, emp_id, dept in teacher_defs:
            user, created = User.objects.get_or_create(
                email=email, defaults=dict(first_name=fname, last_name=lname, role=User.Role.TEACHER, is_verified=True),
            )
            if created:
                user.set_password("DemoTeacher#123")
                user.save()
            profile, _ = TeacherProfile.objects.get_or_create(
                user=user, defaults=dict(college=college, employee_id=emp_id, department=dept, created_by=principal_user),
            )
            teachers.append(profile)
        self.stdout.write(self.style.SUCCESS("  Teachers ready: teacher1@demo.local / teacher2@demo.local (password: DemoTeacher#123)"))

        # --- Students -----------------------------------------------------
        student_defs = [
            ("student1@demo.local", "Aleena", "Thomas", "S001", "R2301", teachers[0]),
            ("student2@demo.local", "Kiran", "Raj", "S002", "R2302", teachers[0]),
            ("student3@demo.local", "Meera", "Suresh", "S003", "R2303", teachers[1]),
            ("student4@demo.local", "Nikhil", "George", "S004", "R2304", teachers[1]),
        ]
        students = []
        for email, fname, lname, sid, reg, teacher in student_defs:
            user, created = User.objects.get_or_create(
                email=email, defaults=dict(first_name=fname, last_name=lname, role=User.Role.STUDENT, is_verified=True),
            )
            if created:
                user.set_password("DemoStudent#123")
                user.save()
            profile, _ = StudentProfile.objects.get_or_create(
                user=user,
                defaults=dict(
                    college=college, teacher=teacher, student_id=sid, register_number=reg,
                    course="MCA", program="Master of Computer Applications", year=2, semester=3,
                    department="Computer Applications", created_by=teacher.user,
                ),
            )
            students.append(profile)
        self.stdout.write(self.style.SUCCESS("  Students ready: student1..4@demo.local (password: DemoStudent#123)"))

        # --- NGOs -----------------------------------------------------
        ngo_defs = [
            ("ngo1@demo.local", "Green Earth Foundation", "Environmental conservation"),
            ("ngo2@demo.local", "Bright Futures Trust", "Child education & literacy"),
            ("ngo3@demo.local", "Helping Hands Society", "Elderly & community care"),
        ]
        ngos = []
        for email, name, area in ngo_defs:
            user, created = User.objects.get_or_create(
                email=email, defaults=dict(first_name=name.split()[0], role=User.Role.NGO, is_verified=True),
            )
            if created:
                user.set_password("DemoNGO#123")
                user.save()
            ngo, _ = NGO.objects.get_or_create(
                user=user,
                defaults=dict(
                    name=name, address="Kottayam, Kerala", contact_person="Coordinator",
                    contact_number="9800000099", email=email, areas_of_work=area,
                    description=f"{name} — {area}.", is_verified=True,
                ),
            )
            ngos.append(ngo)
        self.stdout.write(self.style.SUCCESS("  NGOs ready: ngo1..3@demo.local (password: DemoNGO#123)"))

        # --- Sample applications at different pipeline stages -------------
        s1, s2, s3, s4 = students
        n1, n2, n3 = ngos
        today = datetime.date.today()

        # 1) Fully completed pipeline for student1: submit -> teacher ok ->
        #    principal ok -> NGO1 accepts -> attendance + report + photo + grade
        if not s1.applications.exists():
            app1 = app_services.submit_application(s1, {1: n1, 2: n2, 3: n3})
            app_services.teacher_review(app1, teachers[0].user, approve=True)
            app_services.principal_review(app1, principal_user, approve=True)
            p1 = app1.ngo_priorities.get(priority=1)
            app1 = app_services.ngo_respond(p1, n1.user, approve=True)
            attendance_services.mark_attendance(
                n1, n1.user, s1.id, today - datetime.timedelta(days=1), "PRESENT", activity="Tree plantation drive"
            )
            report_services.submit_report(s1, today - datetime.timedelta(days=1), "Day 1 report", "Helped with sapling planting.")
            report_services.award_grade(app1, n1.user, "A", remarks="Excellent commitment throughout.")
            self.stdout.write(self.style.SUCCESS("  Sample application 1 (student1): fully graded A at Green Earth Foundation"))

        # 2) Priority-1 rejects, priority-2 (NGO2) currently active, for student2
        if not s2.applications.exists():
            app2 = app_services.submit_application(s2, {1: n2, 2: n1, 3: n3})
            app_services.teacher_review(app2, teachers[0].user, approve=True)
            app_services.principal_review(app2, principal_user, approve=True)
            p1 = app2.ngo_priorities.get(priority=1)
            app_services.ngo_respond(p1, n2.user, approve=False, reason="No current openings.")
            self.stdout.write(self.style.SUCCESS("  Sample application 2 (student2): priority-1 declined, priority-2 now active"))

        # 3) Sitting with the Principal, awaiting review, for student3
        if not s3.applications.exists():
            app3 = app_services.submit_application(s3, {1: n3, 2: n1, 3: n2})
            app_services.teacher_review(app3, teachers[1].user, approve=True)
            self.stdout.write(self.style.SUCCESS("  Sample application 3 (student3): approved by teacher, awaiting principal"))

        # 4) Fresh submission still with the Teacher, for student4
        if not s4.applications.exists():
            app_services.submit_application(s4, {1: n1, 2: n3, 3: n2})
            self.stdout.write(self.style.SUCCESS("  Sample application 4 (student4): awaiting teacher review"))

        self.stdout.write(self.style.SUCCESS("Demo data seeding complete."))
