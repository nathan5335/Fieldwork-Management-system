from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import generics, permissions, status
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from common.pagination import StandardResultsPagination
from common.permissions import IsNGO, IsPrincipal, IsStudent, IsTeacher

from . import services
from .models import Application, NGOPrioritySelection
from .serializers import (
    ApplicationListSerializer,
    ApplicationSerializer,
    ApplicationSubmitSerializer,
    NGOPrioritySelectionSerializer,
    NGOQueueItemSerializer,
    ReviewActionSerializer,
)


def _application_queryset_for(user):
    qs = Application.objects.select_related(
        "student__user", "student__teacher__user", "college", "assigned_ngo"
    ).prefetch_related("ngo_priorities__ngo", "audit_trail")

    if user.is_admin:
        return qs
    if user.is_principal:
        return qs.filter(college=user.principal_profile.college)
    if user.is_teacher:
        return qs.filter(student__teacher=user.teacher_profile)
    if user.is_student:
        return qs.filter(student=user.student_profile)
    if user.is_ngo_user:
        return qs.filter(ngo_priorities__ngo=user.ngo_profile).distinct()
    return qs.none()


class ApplicationListView(generics.ListAPIView):
    serializer_class = ApplicationListSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ["status", "college", "assigned_ngo"]
    search_fields = ["student__user__first_name", "student__user__last_name", "student__student_id"]
    ordering_fields = ["created_at", "updated_at", "status"]

    def get_queryset(self):
        return _application_queryset_for(self.request.user)


class ApplicationDetailView(generics.RetrieveAPIView):
    serializer_class = ApplicationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return _application_queryset_for(self.request.user)


class ApplicationSubmitView(APIView):
    """POST /api/applications/submit/ — Student submits a new application.
    College and student come from the authenticated user, never the body."""

    permission_classes = [permissions.IsAuthenticated, IsStudent]

    def post(self, request):
        serializer = ApplicationSubmitSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            application = services.submit_application(
                request.user.student_profile, serializer.to_ngos_by_priority()
            )
        except services.WorkflowError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ApplicationSerializer(application).data, status=status.HTTP_201_CREATED)


class TeacherReviewView(APIView):
    """POST /api/applications/<id>/teacher-review/"""

    permission_classes = [permissions.IsAuthenticated, IsTeacher]

    def post(self, request, pk):
        application = get_object_or_404(
            Application.objects.select_related("student__teacher"),
            pk=pk, student__teacher=request.user.teacher_profile,
        )
        serializer = ReviewActionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            application = services.teacher_review(
                application, request.user, serializer.validated_data["approve"], serializer.validated_data["reason"]
            )
        except services.WorkflowError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ApplicationSerializer(application).data)


class PrincipalReviewView(APIView):
    """POST /api/applications/<id>/principal-review/"""

    permission_classes = [permissions.IsAuthenticated, IsPrincipal]

    def post(self, request, pk):
        application = get_object_or_404(
            Application, pk=pk, college=request.user.principal_profile.college
        )
        serializer = ReviewActionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            application = services.principal_review(
                application, request.user, serializer.validated_data["approve"], serializer.validated_data["reason"]
            )
        except services.WorkflowError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ApplicationSerializer(application).data)


class NGOQueueView(generics.ListAPIView):
    """GET /api/applications/ngo-queue/ — this NGO's currently-actionable
    priority selections (status=ACTIVATED)."""

    serializer_class = NGOQueueItemSerializer
    permission_classes = [permissions.IsAuthenticated, IsNGO]
    pagination_class = StandardResultsPagination

    def get_queryset(self):
        return NGOPrioritySelection.objects.filter(
            ngo=self.request.user.ngo_profile, status=NGOPrioritySelection.Status.ACTIVATED
        ).select_related("application__student__user", "application__college", "ngo")


class NGORespondView(APIView):
    """POST /api/applications/priorities/<id>/respond/"""

    permission_classes = [permissions.IsAuthenticated, IsNGO]

    def post(self, request, pk):
        priority_selection = get_object_or_404(
            NGOPrioritySelection, pk=pk, ngo=request.user.ngo_profile
        )
        serializer = ReviewActionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            application = services.ngo_respond(
                priority_selection, request.user, serializer.validated_data["approve"], serializer.validated_data["reason"]
            )
        except services.WorkflowError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ApplicationSerializer(application).data)


class CancelPriorityOneView(APIView):
    """POST /api/applications/<id>/cancel-priority-one/"""

    permission_classes = [permissions.IsAuthenticated, IsStudent]

    def post(self, request, pk):
        application = get_object_or_404(Application, pk=pk, student=request.user.student_profile)
        try:
            application = services.cancel_priority_one(
                application, request.user, request.data.get("reason", "")
            )
        except services.WorkflowError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ApplicationSerializer(application).data)


class ReapplyView(APIView):
    """POST /api/applications/<id>/reapply/"""

    permission_classes = [permissions.IsAuthenticated, IsStudent]

    def post(self, request, pk):
        previous_application = get_object_or_404(
            Application, pk=pk, student=request.user.student_profile
        )
        serializer = ApplicationSubmitSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            application = services.reapply(previous_application, serializer.to_ngos_by_priority())
        except services.WorkflowError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ApplicationSerializer(application).data, status=status.HTTP_201_CREATED)
