from rest_framework import serializers

from colleges.serializers import StudentProfileSerializer
from ngos.models import NGO
from ngos.serializers import NGOSerializer

from .models import Application, Approval, NGOPrioritySelection


class NGOPrioritySelectionSerializer(serializers.ModelSerializer):
    ngo = NGOSerializer(read_only=True)

    class Meta:
        model = NGOPrioritySelection
        fields = [
            "id", "ngo", "priority", "status", "response", "response_reason",
            "responded_at", "created_at",
        ]
        read_only_fields = fields


class NGOQueueItemSerializer(serializers.ModelSerializer):
    """One actionable slot in an NGO's queue, including WHO is asking —
    the NGO cannot respond to an application it cannot identify."""

    application_id = serializers.IntegerField(source="application.id", read_only=True)
    student_name = serializers.CharField(source="application.student.user.get_full_name", read_only=True)
    student_number = serializers.CharField(source="application.student.student_id", read_only=True)
    course = serializers.CharField(source="application.student.course", read_only=True)
    college_name = serializers.CharField(source="application.college.name", read_only=True)

    class Meta:
        model = NGOPrioritySelection
        fields = [
            "id", "application_id", "priority", "status", "student_name",
            "student_number", "course", "college_name", "created_at",
        ]
        read_only_fields = fields


class ApprovalSerializer(serializers.ModelSerializer):
    user_name = serializers.CharField(source="user.get_full_name", read_only=True, default="")

    class Meta:
        model = Approval
        fields = ["id", "user", "user_name", "role", "action", "reason", "created_at"]
        read_only_fields = fields


class ApplicationSerializer(serializers.ModelSerializer):
    student = StudentProfileSerializer(read_only=True)
    assigned_ngo = NGOSerializer(read_only=True)
    ngo_priorities = NGOPrioritySelectionSerializer(many=True, read_only=True)
    audit_trail = ApprovalSerializer(many=True, read_only=True)

    class Meta:
        model = Application
        fields = [
            "id", "student", "college", "status", "assigned_ngo",
            "teacher_reviewed_by", "teacher_reviewed_at", "teacher_rejection_reason",
            "principal_reviewed_by", "principal_reviewed_at", "principal_rejection_reason",
            "is_reapplication", "previous_application",
            "ngo_priorities", "audit_trail", "created_at", "updated_at",
        ]
        read_only_fields = fields


class ApplicationListSerializer(serializers.ModelSerializer):
    """Lighter representation for list views."""

    student_name = serializers.CharField(source="student.user.get_full_name", read_only=True)
    student_number = serializers.CharField(source="student.student_id", read_only=True)
    college_name = serializers.CharField(source="college.name", read_only=True)
    assigned_ngo_name = serializers.CharField(source="assigned_ngo.name", read_only=True, default="")

    class Meta:
        model = Application
        fields = [
            "id", "student", "student_name", "student_number", "college_name", "status",
            "assigned_ngo", "assigned_ngo_name", "is_reapplication", "created_at", "updated_at",
        ]
        read_only_fields = fields


class ApplicationSubmitSerializer(serializers.Serializer):
    ngo_priority_1 = serializers.PrimaryKeyRelatedField(queryset=NGO.objects.filter(is_verified=True, is_active=True))
    ngo_priority_2 = serializers.PrimaryKeyRelatedField(queryset=NGO.objects.filter(is_verified=True, is_active=True))
    ngo_priority_3 = serializers.PrimaryKeyRelatedField(queryset=NGO.objects.filter(is_verified=True, is_active=True))

    def validate(self, attrs):
        ngos = [attrs["ngo_priority_1"], attrs["ngo_priority_2"], attrs["ngo_priority_3"]]
        if len({ngo.id for ngo in ngos}) != 3:
            raise serializers.ValidationError("Priorities 1, 2 and 3 must be three different NGOs.")
        return attrs

    def to_ngos_by_priority(self):
        data = self.validated_data
        return {1: data["ngo_priority_1"], 2: data["ngo_priority_2"], 3: data["ngo_priority_3"]}


class ReviewActionSerializer(serializers.Serializer):
    approve = serializers.BooleanField()
    reason = serializers.CharField(required=False, allow_blank=True, default="")
