from django.contrib import admin

from .models import Application, NGOPrioritySelection, Approval

admin.site.register(Application)
admin.site.register(NGOPrioritySelection)
admin.site.register(Approval)
