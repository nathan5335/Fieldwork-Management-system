import datetime

from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from applications import services
from applications.models import Application, NGOPrioritySelection
from colleges.models import College, PrincipalProfile, StudentProfile, TeacherProfile
from ngos.models import NGO
from reports import services as report_services


def make_user(email, role, **extra):
    user = User.objects.create_user(email=email, password="TestPass#123", first_name="Test", role=role, **extra)
    return user


class WorkflowFixtureMixin:
    """Builds one college, one teacher, one student, and three NGOs — the
    minimum cast needed to exercise the application workflow."""

    def setUp(self):
        self.principal_user = make_user("principal@test.local", User.Role.PRINCIPAL)
        self.college = College.objects.create(
            name="Test College", code="TC001", address="Addr", district="D", state="S",
            contact_number="1", official_email="c@test.local",
        )
        PrincipalProfile.objects.create(user=self.principal_user, college=self.college)

        self.teacher_user = make_user("teacher@test.local", User.Role.TEACHER)
        self.teacher = TeacherProfile.objects.create(
            user=self.teacher_user, college=self.college, employee_id="E1", department="CS",
        )

        self.student_user = make_user("student@test.local", User.Role.STUDENT)
        self.student = StudentProfile.objects.create(
            user=self.student_user, college=self.college, teacher=self.teacher, student_id="S1",
            register_number="R1", course="MCA", year=1, semester=1, department="CS",
        )

        self.ngo_users = [make_user(f"ngo{i}@test.local", User.Role.NGO) for i in (1, 2, 3)]
        self.ngos = [
            NGO.objects.create(
                user=u, name=f"NGO {i}", address="A", contact_person="C", contact_number="1",
                email=f"ngo{i}@test.local", areas_of_work="Work", is_verified=True,
            )
            for i, u in enumerate(self.ngo_users, start=1)
        ]

    def submit_and_approve_to_ngo_review(self):
        application = services.submit_application(
            self.student, {1: self.ngos[0], 2: self.ngos[1], 3: self.ngos[2]}
        )
        application = services.teacher_review(application, self.teacher_user, approve=True)
        application = services.principal_review(application, self.principal_user, approve=True)
        return application


class ApplicationSubmissionTests(WorkflowFixtureMixin, TestCase):
    def test_duplicate_ngo_rejected(self):
        with self.assertRaises(services.WorkflowError):
            services.submit_application(self.student, {1: self.ngos[0], 2: self.ngos[0], 3: self.ngos[1]})

    def test_submission_creates_three_priority_rows(self):
        application = services.submit_application(
            self.student, {1: self.ngos[0], 2: self.ngos[1], 3: self.ngos[2]}
        )
        self.assertEqual(application.status, Application.Status.SUBMITTED_TO_TEACHER)
        self.assertEqual(application.ngo_priorities.count(), 3)


class TeacherPrincipalReviewTests(WorkflowFixtureMixin, TestCase):
    def test_teacher_rejection_stops_flow(self):
        application = services.submit_application(
            self.student, {1: self.ngos[0], 2: self.ngos[1], 3: self.ngos[2]}
        )
        application = services.teacher_review(application, self.teacher_user, approve=False, reason="Incomplete")
        self.assertEqual(application.status, Application.Status.TEACHER_REJECTED)

    def test_principal_approval_activates_priority_one_only(self):
        application = self.submit_and_approve_to_ngo_review()
        self.assertEqual(application.status, Application.Status.NGO_REVIEW)
        priorities = {p.priority: p.status for p in application.ngo_priorities.all()}
        self.assertEqual(priorities[1], NGOPrioritySelection.Status.ACTIVATED)
        self.assertEqual(priorities[2], NGOPrioritySelection.Status.PENDING)
        self.assertEqual(priorities[3], NGOPrioritySelection.Status.PENDING)


class NGOPriorityCascadeTests(WorkflowFixtureMixin, TestCase):
    def test_priority_one_approval_cancels_two_and_three(self):
        application = self.submit_and_approve_to_ngo_review()
        p1 = application.ngo_priorities.get(priority=1)
        application = services.ngo_respond(p1, self.ngo_users[0], approve=True)

        self.assertEqual(application.status, Application.Status.ASSIGNED)
        self.assertEqual(application.assigned_ngo, self.ngos[0])
        statuses = {p.priority: p.status for p in application.ngo_priorities.all()}
        self.assertEqual(statuses[1], NGOPrioritySelection.Status.APPROVED)
        self.assertEqual(statuses[2], NGOPrioritySelection.Status.CANCELLED)
        self.assertEqual(statuses[3], NGOPrioritySelection.Status.CANCELLED)

    def test_full_cascade_down_to_priority_three(self):
        application = self.submit_and_approve_to_ngo_review()

        p1 = application.ngo_priorities.get(priority=1)
        application = services.ngo_respond(p1, self.ngo_users[0], approve=False)
        self.assertEqual(
            application.ngo_priorities.get(priority=2).status, NGOPrioritySelection.Status.ACTIVATED
        )

        p2 = application.ngo_priorities.get(priority=2)
        application = services.ngo_respond(p2, self.ngo_users[1], approve=False)
        self.assertEqual(
            application.ngo_priorities.get(priority=3).status, NGOPrioritySelection.Status.ACTIVATED
        )

        p3 = application.ngo_priorities.get(priority=3)
        application = services.ngo_respond(p3, self.ngo_users[2], approve=True)
        self.assertEqual(application.status, Application.Status.ASSIGNED)
        self.assertEqual(application.assigned_ngo, self.ngos[2])

    def test_all_three_reject_triggers_reapply_state(self):
        application = self.submit_and_approve_to_ngo_review()
        for priority, ngo_user in zip((1, 2, 3), self.ngo_users):
            selection = application.ngo_priorities.get(priority=priority)
            application = services.ngo_respond(selection, ngo_user, approve=False)

        self.assertEqual(application.status, Application.Status.ALL_NGOS_REJECTED)

        new_application = services.reapply(
            application, {1: self.ngos[1], 2: self.ngos[2], 3: self.ngos[0]}
        )
        self.assertTrue(new_application.is_reapplication)
        self.assertEqual(new_application.previous_application, application)

    def test_non_active_ngo_cannot_respond(self):
        application = self.submit_and_approve_to_ngo_review()
        p2 = application.ngo_priorities.get(priority=2)  # still PENDING, not ACTIVATED
        with self.assertRaises(services.WorkflowError):
            services.ngo_respond(p2, self.ngo_users[1], approve=True)

    def test_cancel_priority_one_activates_priority_two(self):
        application = self.submit_and_approve_to_ngo_review()
        application = services.cancel_priority_one(application, self.student_user)
        statuses = {p.priority: p.status for p in application.ngo_priorities.all()}
        self.assertEqual(statuses[1], NGOPrioritySelection.Status.CANCELLED)
        self.assertEqual(statuses[2], NGOPrioritySelection.Status.ACTIVATED)


class ReportAttemptLimitTests(WorkflowFixtureMixin, TestCase):
    def test_fourth_attempt_blocked(self):
        application = self.submit_and_approve_to_ngo_review()
        p1 = application.ngo_priorities.get(priority=1)
        services.ngo_respond(p1, self.ngo_users[0], approve=True)

        today = datetime.date.today()
        for i in range(3):
            report_services.submit_report(self.student, today, f"Attempt {i + 1}")

        with self.assertRaises(report_services.ReportError):
            report_services.submit_report(self.student, today, "Attempt 4")


class PermissionBoundaryAPITests(WorkflowFixtureMixin, TestCase):
    """Hits the real REST endpoints to prove server-side role/ownership
    checks — never just the frontend hiding a button."""

    def setUp(self):
        super().setUp()
        self.client = APIClient()

    def _login(self, email):
        response = self.client.post("/api/auth/login/", {"email": email, "password": "TestPass#123"})
        self.assertEqual(response.status_code, 200, response.content)
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {response.data['access']}")

    def test_student_cannot_hit_teacher_review_endpoint(self):
        application = services.submit_application(
            self.student, {1: self.ngos[0], 2: self.ngos[1], 3: self.ngos[2]}
        )
        self._login("student@test.local")
        response = self.client.post(f"/api/applications/{application.id}/teacher-review/", {"approve": True})
        self.assertEqual(response.status_code, 403)

    def test_principal_from_another_college_cannot_review(self):
        other_principal = make_user("other-principal@test.local", User.Role.PRINCIPAL)
        other_college = College.objects.create(
            name="Other College", code="OC001", address="Addr", district="D", state="S",
            contact_number="1", official_email="o@test.local",
        )
        PrincipalProfile.objects.create(user=other_principal, college=other_college)

        application = services.submit_application(
            self.student, {1: self.ngos[0], 2: self.ngos[1], 3: self.ngos[2]}
        )
        services.teacher_review(application, self.teacher_user, approve=True)

        self._login("other-principal@test.local")
        response = self.client.post(f"/api/applications/{application.id}/principal-review/", {"approve": True})
        self.assertEqual(response.status_code, 404)  # scoped queryset — not even visible

    def test_ngo_cannot_respond_to_someone_elses_priority_slot(self):
        application = self.submit_and_approve_to_ngo_review()
        p1 = application.ngo_priorities.get(priority=1)  # belongs to ngos[0] / ngo_users[0]

        self._login("ngo2@test.local")  # a DIFFERENT ngo trying to act on priority 1
        response = self.client.post(f"/api/applications/priorities/{p1.id}/respond/", {"approve": True})
        self.assertEqual(response.status_code, 404)

    def test_unauthenticated_request_rejected(self):
        response = self.client.get("/api/applications/")
        self.assertEqual(response.status_code, 401)


class NGOQueueVisibilityTests(WorkflowFixtureMixin, TestCase):
    def setUp(self):
        super().setUp()
        self.client = APIClient()

    def _login(self, email):
        response = self.client.post("/api/auth/login/", {"email": email, "password": "TestPass#123"})
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {response.data['access']}")

    def test_queue_identifies_the_student_and_only_shows_active_slot(self):
        self.submit_and_approve_to_ngo_review()

        self._login("ngo1@test.local")  # priority 1 -> actionable
        rows = self.client.get("/api/applications/ngo-queue/").data["results"]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["student_number"], "S1")
        self.assertEqual(rows[0]["priority"], 1)
        self.assertTrue(rows[0]["student_name"])

        self._login("ngo2@test.local")  # priority 2 -> queued, NOT yet actionable
        self.assertEqual(self.client.get("/api/applications/ngo-queue/").data["results"], [])

    def test_application_list_exposes_ids_needed_for_attendance_marking(self):
        application = self.submit_and_approve_to_ngo_review()
        services.ngo_respond(application.ngo_priorities.get(priority=1), self.ngo_users[0], approve=True)

        self._login("ngo1@test.local")
        row = self.client.get("/api/applications/").data["results"][0]
        self.assertEqual(row["student"], self.student.id)
        self.assertEqual(row["assigned_ngo"], self.ngos[0].id)
