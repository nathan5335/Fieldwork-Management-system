from django.conf import settings
from django.db import models


class Application(models.Model):
    """A single fieldwork application submitted by a Student. Its `status`
    drives the whole workflow state machine described in the project spec."""

    class Status(models.TextChoices):
        SUBMITTED_TO_TEACHER = "SUBMITTED_TO_TEACHER", "Submitted to Teacher"
        TEACHER_REJECTED = "TEACHER_REJECTED", "Rejected by Teacher"
        PENDING_PRINCIPAL = "PENDING_PRINCIPAL", "Pending Principal Review"
        PRINCIPAL_REJECTED = "PRINCIPAL_REJECTED", "Rejected by Principal"
        NGO_REVIEW = "NGO_REVIEW", "Under NGO Review"
        ALL_NGOS_REJECTED = "ALL_NGOS_REJECTED", "All NGOs Rejected"
        ASSIGNED = "ASSIGNED", "Assigned — Fieldwork Active"
        COMPLETED = "COMPLETED", "Fieldwork Completed"
        CANCELLED = "CANCELLED", "Cancelled"

    student = models.ForeignKey(
        "colleges.StudentProfile", on_delete=models.CASCADE, related_name="applications"
    )
    college = models.ForeignKey(
        "colleges.College", on_delete=models.CASCADE, related_name="applications"
    )
    status = models.CharField(
        max_length=30, choices=Status.choices, default=Status.SUBMITTED_TO_TEACHER, db_index=True
    )

    assigned_ngo = models.ForeignKey(
        "ngos.NGO",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_applications",
    )

    teacher_reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="applications_teacher_reviewed",
    )
    teacher_reviewed_at = models.DateTimeField(null=True, blank=True)
    teacher_rejection_reason = models.TextField(blank=True)

    principal_reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="applications_principal_reviewed",
    )
    principal_reviewed_at = models.DateTimeField(null=True, blank=True)
    principal_rejection_reason = models.TextField(blank=True)

    is_reapplication = models.BooleanField(default=False)
    previous_application = models.ForeignKey(
        "self", on_delete=models.SET_NULL, null=True, blank=True, related_name="reapplications"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Application #{self.pk} — {self.student} [{self.status}]"


class NGOPrioritySelection(models.Model):
    """One of a student's three NGO preferences for a given application, and
    that NGO's response. Exactly one row per (application, priority) and per
    (application, ngo) — enforced both here and in the service layer."""

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        CANCELLED = "CANCELLED", "Cancelled"
        ACTIVATED = "ACTIVATED", "Activated"
        SKIPPED = "SKIPPED", "Skipped"

    application = models.ForeignKey(
        Application, on_delete=models.CASCADE, related_name="ngo_priorities"
    )
    ngo = models.ForeignKey(
        "ngos.NGO", on_delete=models.CASCADE, related_name="priority_selections"
    )
    priority = models.PositiveSmallIntegerField(choices=[(1, "1"), (2, "2"), (3, "3")])
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    response = models.CharField(max_length=20, choices=Status.choices, blank=True)
    response_reason = models.TextField(blank=True)
    responded_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["application", "priority"]
        constraints = [
            models.UniqueConstraint(
                fields=["application", "priority"], name="unique_priority_per_application"
            ),
            models.UniqueConstraint(
                fields=["application", "ngo"], name="unique_ngo_per_application"
            ),
        ]

    def __str__(self):
        return f"App #{self.application_id} — Priority {self.priority} — {self.ngo.name} [{self.status}]"


class Approval(models.Model):
    """Audit trail entry for an application-level action. One row per
    action taken by any user in the workflow."""

    class Action(models.TextChoices):
        SUBMITTED = "SUBMITTED", "Submitted"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        CANCELLED = "CANCELLED", "Cancelled"
        ASSIGNED = "ASSIGNED", "Assigned"

    application = models.ForeignKey(
        Application, on_delete=models.CASCADE, related_name="audit_trail"
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="approvals"
    )
    role = models.CharField(max_length=20, blank=True)
    action = models.CharField(max_length=20, choices=Action.choices)
    reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"App #{self.application_id} — {self.action} by {self.user}"
