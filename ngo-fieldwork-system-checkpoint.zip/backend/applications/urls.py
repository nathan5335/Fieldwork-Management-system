from django.urls import path

from . import views

urlpatterns = [
    path("", views.ApplicationListView.as_view(), name="application-list"),
    path("submit/", views.ApplicationSubmitView.as_view(), name="application-submit"),
    path("ngo-queue/", views.NGOQueueView.as_view(), name="application-ngo-queue"),
    path("priorities/<int:pk>/respond/", views.NGORespondView.as_view(), name="priority-respond"),
    path("<int:pk>/", views.ApplicationDetailView.as_view(), name="application-detail"),
    path("<int:pk>/teacher-review/", views.TeacherReviewView.as_view(), name="application-teacher-review"),
    path("<int:pk>/principal-review/", views.PrincipalReviewView.as_view(), name="application-principal-review"),
    path("<int:pk>/cancel-priority-one/", views.CancelPriorityOneView.as_view(), name="application-cancel-p1"),
    path("<int:pk>/reapply/", views.ReapplyView.as_view(), name="application-reapply"),
]
