"""The application / NGO-priority workflow state machine.

Every transition below runs inside transaction.atomic() and writes an
Approval audit row, so the Application + NGOPrioritySelection tables can
never be left in a contradictory state, and every decision is traceable.

State machine summary (see project README for the full diagram):

    SUBMITTED_TO_TEACHER --teacher reject--> TEACHER_REJECTED
    SUBMITTED_TO_TEACHER --teacher approve--> PENDING_PRINCIPAL
    PENDING_PRINCIPAL --principal reject--> PRINCIPAL_REJECTED
    PENDING_PRINCIPAL --principal approve--> NGO_REVIEW  (priority 1 -> ACTIVATED)
    NGO_REVIEW --priority N approves--> ASSIGNED (lower priorities CANCELLED)
    NGO_REVIEW --priority N (1 or 2) rejects--> still NGO_REVIEW (priority N+1 -> ACTIVATED)
    NGO_REVIEW --priority 3 rejects--> ALL_NGOS_REJECTED  (student may REAPPLY)
"""

from django.db import transaction
from django.utils import timezone

from notifications.services import notify, notify_many

from .models import Application, Approval, NGOPrioritySelection

PrioritySelectionStatus = NGOPrioritySelection.Status
ApplicationStatus = Application.Status


class WorkflowError(Exception):
    """Raised whenever a requested transition is not legal from the
    application's/selection's current state, or the actor isn't entitled to
    perform it. Views translate this into a 400/403 response."""


def _record_audit(application, user, action, reason=""):
    Approval.objects.create(
        application=application,
        user=user,
        role=getattr(user, "role", ""),
        action=action,
        reason=reason,
    )


def _recipient_user(profile_or_user):
    """Accepts either a *Profile instance (StudentProfile/TeacherProfile/
    NGO) or a User and always returns the User to notify."""
    return getattr(profile_or_user, "user", profile_or_user)


# ---------------------------------------------------------------------------
# 1. Submission
# ---------------------------------------------------------------------------

@transaction.atomic
def submit_application(student_profile, ngos_by_priority, is_reapplication=False, previous_application=None):
    """ngos_by_priority: {1: NGO, 2: NGO, 3: NGO} — three DISTINCT NGOs."""
    ngo_ids = {ngo.id for ngo in ngos_by_priority.values()}
    if len(ngos_by_priority) != 3 or len(ngo_ids) != 3:
        raise WorkflowError("You must select three different NGOs for priorities 1, 2 and 3.")

    if student_profile.teacher_id is None:
        raise WorkflowError("This student has no assigned teacher and cannot submit an application.")

    application = Application.objects.create(
        student=student_profile,
        college=student_profile.college,
        status=ApplicationStatus.SUBMITTED_TO_TEACHER,
        is_reapplication=is_reapplication,
        previous_application=previous_application,
    )

    for priority, ngo in ngos_by_priority.items():
        NGOPrioritySelection.objects.create(
            application=application, ngo=ngo, priority=priority, status=PrioritySelectionStatus.PENDING
        )

    _record_audit(application, student_profile.user, Approval.Action.SUBMITTED)

    notify(
        _recipient_user(student_profile.teacher),
        "APPLICATION_SUBMITTED",
        "New fieldwork application",
        f"{student_profile.user.get_full_name()} submitted a fieldwork application for your review.",
        related_application=application,
    )
    return application


# ---------------------------------------------------------------------------
# 2. Teacher review
# ---------------------------------------------------------------------------

@transaction.atomic
def teacher_review(application, teacher_user, approve, reason=""):
    if application.status != ApplicationStatus.SUBMITTED_TO_TEACHER:
        raise WorkflowError("This application is not awaiting teacher review.")

    application.teacher_reviewed_by = teacher_user
    application.teacher_reviewed_at = timezone.now()

    if approve:
        application.status = ApplicationStatus.PENDING_PRINCIPAL
        _record_audit(application, teacher_user, Approval.Action.APPROVED, reason)
        notify(
            _recipient_user(application.college.principal_profile.user),
            "TEACHER_APPROVED",
            "Application awaiting your review",
            f"{application.student.user.get_full_name()}'s application was approved by their teacher and now needs your review.",
            related_application=application,
        )
    else:
        application.status = ApplicationStatus.TEACHER_REJECTED
        application.teacher_rejection_reason = reason
        _record_audit(application, teacher_user, Approval.Action.REJECTED, reason)
        notify(
            _recipient_user(application.student),
            "TEACHER_REJECTED",
            "Application rejected by teacher",
            reason or "Your fieldwork application was rejected by your teacher.",
            related_application=application,
        )

    application.save()
    return application


# ---------------------------------------------------------------------------
# 3. Principal review
# ---------------------------------------------------------------------------

@transaction.atomic
def principal_review(application, principal_user, approve, reason=""):
    if application.status != ApplicationStatus.PENDING_PRINCIPAL:
        raise WorkflowError("This application is not awaiting principal review.")

    application.principal_reviewed_by = principal_user
    application.principal_reviewed_at = timezone.now()

    if approve:
        application.status = ApplicationStatus.NGO_REVIEW
        _record_audit(application, principal_user, Approval.Action.APPROVED, reason)

        priorities = {p.priority: p for p in application.ngo_priorities.select_related("ngo").all()}
        priorities[1].status = PrioritySelectionStatus.ACTIVATED
        priorities[1].save(update_fields=["status", "updated_at"])

        notify(
            _recipient_user(priorities[1].ngo),
            "NGO_APPLICATION_RECEIVED",
            "New fieldwork application (Priority 1)",
            f"{application.student.user.get_full_name()} has listed you as their first-priority NGO.",
            related_application=application,
        )
        for priority in (2, 3):
            notify(
                _recipient_user(priorities[priority].ngo),
                "NGO_APPLICATION_RECEIVED",
                "You're in the NGO queue for a new application",
                f"{application.student.user.get_full_name()} listed you as priority {priority}. "
                "You'll be notified if higher-priority NGOs decline.",
                related_application=application,
            )
        notify(
            _recipient_user(application.student),
            "PRINCIPAL_APPROVED",
            "Application approved by principal",
            "Your application has been sent to your selected NGOs.",
            related_application=application,
        )
    else:
        application.status = ApplicationStatus.PRINCIPAL_REJECTED
        application.principal_rejection_reason = reason
        _record_audit(application, principal_user, Approval.Action.REJECTED, reason)
        for recipient in (application.student, application.student.teacher):
            notify(
                _recipient_user(recipient),
                "PRINCIPAL_REJECTED",
                "Application rejected by principal",
                reason or "The fieldwork application was rejected by the principal.",
                related_application=application,
            )

    application.save()
    return application


# ---------------------------------------------------------------------------
# 4. NGO response (priority 1 / 2 / 3)
# ---------------------------------------------------------------------------

@transaction.atomic
def ngo_respond(priority_selection, ngo_user, approve, reason=""):
    application = Application.objects.select_for_update().get(pk=priority_selection.application_id)
    priority_selection.refresh_from_db()

    if application.status != ApplicationStatus.NGO_REVIEW:
        raise WorkflowError("This application is not currently under NGO review.")
    if priority_selection.status != PrioritySelectionStatus.ACTIVATED:
        raise WorkflowError("This NGO priority is not currently active and cannot be responded to.")

    priority_selection.response = (
        PrioritySelectionStatus.APPROVED if approve else PrioritySelectionStatus.REJECTED
    )
    priority_selection.response_reason = reason
    priority_selection.responded_at = timezone.now()

    student_user = _recipient_user(application.student)
    teacher_user = _recipient_user(application.student.teacher)
    principal_user = _recipient_user(application.college.principal_profile.user)

    if approve:
        priority_selection.status = PrioritySelectionStatus.APPROVED
        priority_selection.save()

        application.ngo_priorities.exclude(pk=priority_selection.pk).filter(
            status__in=[PrioritySelectionStatus.PENDING, PrioritySelectionStatus.ACTIVATED]
        ).update(status=PrioritySelectionStatus.CANCELLED, updated_at=timezone.now())

        application.status = ApplicationStatus.ASSIGNED
        application.assigned_ngo = priority_selection.ngo
        application.save()

        _record_audit(application, ngo_user, Approval.Action.ASSIGNED, reason)

        title = f"Assigned to {priority_selection.ngo.name}"
        message = f"{application.student.user.get_full_name()} has been assigned to your organization."
        for recipient in (student_user, teacher_user, principal_user):
            notify(recipient, "NGO_ASSIGNED", title, message, related_application=application)
        return application

    # Rejected
    priority_selection.status = PrioritySelectionStatus.REJECTED
    priority_selection.save()
    _record_audit(application, ngo_user, Approval.Action.REJECTED, reason)
    notify(
        student_user, "NGO_REJECTED", f"{priority_selection.ngo.name} declined",
        reason or "This NGO was unable to accept your application.", related_application=application,
    )

    next_priority = priority_selection.priority + 1
    if next_priority > 3:
        application.status = ApplicationStatus.ALL_NGOS_REJECTED
        application.save()
        for recipient in (student_user, teacher_user, principal_user):
            notify(
                recipient, "REAPPLY_REQUIRED", "All selected NGOs declined",
                "All three selected NGOs have rejected this application. You may submit a new "
                "application with different NGO preferences.",
                related_application=application,
            )
        return application

    next_selection = application.ngo_priorities.get(priority=next_priority)
    next_selection.status = PrioritySelectionStatus.ACTIVATED
    next_selection.save()
    notify(
        _recipient_user(next_selection.ngo), "NGO_PRIORITY_ACTIVATED",
        "A fieldwork application now needs your response",
        f"{application.student.user.get_full_name()}'s application has reached your organization "
        f"(priority {next_priority}).",
        related_application=application,
    )
    notify(
        student_user, "NGO_PRIORITY_ACTIVATED", "Moved to your next-priority NGO",
        f"Your application has moved to {next_selection.ngo.name} (priority {next_priority}).",
        related_application=application,
    )
    return application


# ---------------------------------------------------------------------------
# 5. Student cancels the currently-active Priority 1 request
# ---------------------------------------------------------------------------

@transaction.atomic
def cancel_priority_one(application, student_user, reason=""):
    if application.status != ApplicationStatus.NGO_REVIEW:
        raise WorkflowError("Only an application currently under NGO review can be cancelled.")

    priority_one = application.ngo_priorities.select_for_update().get(priority=1)
    if priority_one.status != PrioritySelectionStatus.ACTIVATED:
        raise WorkflowError("Priority 1 is no longer pending and cannot be cancelled.")

    priority_one.status = PrioritySelectionStatus.CANCELLED
    priority_one.response_reason = reason
    priority_one.save()
    _record_audit(application, student_user, Approval.Action.CANCELLED, reason)

    priority_two = application.ngo_priorities.select_for_update().get(priority=2)
    priority_two.status = PrioritySelectionStatus.ACTIVATED
    priority_two.save()

    notify(
        _recipient_user(priority_one.ngo), "NGO_PRIORITY_CANCELLED",
        "Application request cancelled", "The student cancelled this priority-1 request.",
        related_application=application,
    )
    notify(
        _recipient_user(priority_two.ngo), "NGO_PRIORITY_ACTIVATED",
        "A fieldwork application now needs your response",
        f"{application.student.user.get_full_name()}'s application has reached your organization (priority 2).",
        related_application=application,
    )
    return application


# ---------------------------------------------------------------------------
# 6. Reapply after ALL_NGOS_REJECTED
# ---------------------------------------------------------------------------

@transaction.atomic
def reapply(previous_application, ngos_by_priority):
    if previous_application.status != ApplicationStatus.ALL_NGOS_REJECTED:
        raise WorkflowError("Reapplication is only available after all selected NGOs have rejected.")
    return submit_application(
        previous_application.student,
        ngos_by_priority,
        is_reapplication=True,
        previous_application=previous_application,
    )
