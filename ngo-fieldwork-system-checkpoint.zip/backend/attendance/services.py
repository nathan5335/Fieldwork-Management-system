from django.db import transaction

from applications.models import Application
from colleges.models import StudentProfile
from notifications.services import notify

from .models import Attendance


class AttendanceError(Exception):
    pass


@transaction.atomic
def mark_attendance(ngo, marked_by_user, student_id, date, status, activity="", remarks=""):
    try:
        student = StudentProfile.objects.select_related("user", "teacher__user").get(pk=student_id)
    except StudentProfile.DoesNotExist:
        raise AttendanceError("Student not found.")

    application = Application.objects.filter(
        student=student, assigned_ngo=ngo, status__in=[Application.Status.ASSIGNED, Application.Status.COMPLETED]
    ).first()
    if application is None:
        raise AttendanceError("This student is not assigned to your organization.")

    record, _created = Attendance.objects.update_or_create(
        student=student, date=date,
        defaults={
            "ngo": ngo, "application": application, "status": status,
            "activity": activity, "remarks": remarks, "marked_by": marked_by_user,
        },
    )

    notify(
        student.user, "ATTENDANCE_UPDATED", "Attendance updated",
        f"Your attendance for {date} was marked {status.title()}.", related_application=application,
    )
    return record
