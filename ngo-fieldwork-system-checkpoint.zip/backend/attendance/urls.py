from django.urls import path

from . import views

urlpatterns = [
    path("", views.AttendanceListView.as_view(), name="attendance-list"),
    path("mark/", views.AttendanceMarkView.as_view(), name="attendance-mark"),
    path("my-summary/", views.MyAttendanceSummaryView.as_view(), name="attendance-my-summary"),
]
