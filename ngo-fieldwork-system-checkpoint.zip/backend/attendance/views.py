from rest_framework import generics, permissions, status
from rest_framework.filters import OrderingFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from common.pagination import StandardResultsPagination
from common.permissions import IsNGO

from . import services
from .models import Attendance
from .serializers import AttendanceMarkSerializer, AttendanceSerializer


class AttendanceMarkView(APIView):
    """POST /api/attendance/mark/ — NGO marks (or corrects) one day's
    attendance for one of their assigned students."""

    permission_classes = [permissions.IsAuthenticated, IsNGO]

    def post(self, request):
        serializer = AttendanceMarkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            record = services.mark_attendance(
                ngo=request.user.ngo_profile, marked_by_user=request.user, **serializer.validated_data
            )
        except services.AttendanceError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(AttendanceSerializer(record).data, status=status.HTTP_200_OK)


class AttendanceListView(generics.ListAPIView):
    serializer_class = AttendanceSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ["student", "status", "date", "ngo"]
    ordering_fields = ["date"]

    def get_queryset(self):
        user = self.request.user
        qs = Attendance.objects.select_related("student__user", "ngo")
        if user.is_admin:
            return qs
        if user.is_ngo_user:
            return qs.filter(ngo=user.ngo_profile)
        if user.is_student:
            return qs.filter(student=user.student_profile)
        if user.is_teacher:
            return qs.filter(student__teacher=user.teacher_profile)
        if user.is_principal:
            return qs.filter(student__college=user.principal_profile.college)
        return qs.none()


class MyAttendanceSummaryView(APIView):
    """GET /api/attendance/my-summary/ — the authenticated Student's own
    working-day / present / absent / percentage summary."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        student_profile = getattr(request.user, "student_profile", None)
        student_id = request.query_params.get("student")
        if student_profile is None and student_id:
            student_profile = student_id  # Teacher/Principal/Admin/NGO passing an explicit id
        if student_profile is None:
            return Response({"detail": "student query param is required for this role."}, status=400)

        qs = Attendance.objects.filter(student=student_profile)
        total = qs.count()
        present = qs.filter(status=Attendance.Status.PRESENT).count()
        absent = qs.filter(status=Attendance.Status.ABSENT).count()
        percentage = round((present / total) * 100, 1) if total else 0.0
        return Response(
            {"working_days": total, "present": present, "absent": absent, "attendance_percentage": percentage}
        )
