from rest_framework import serializers

from .models import Attendance


class AttendanceSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source="student.user.get_full_name", read_only=True)
    ngo_name = serializers.CharField(source="ngo.name", read_only=True)

    class Meta:
        model = Attendance
        fields = [
            "id", "student", "student_name", "ngo", "ngo_name", "application",
            "date", "status", "activity", "remarks", "marked_by", "created_at", "updated_at",
        ]
        read_only_fields = ["id", "ngo", "application", "marked_by", "created_at", "updated_at"]


class AttendanceMarkSerializer(serializers.Serializer):
    student = serializers.IntegerField()
    date = serializers.DateField()
    status = serializers.ChoiceField(choices=Attendance.Status.choices)
    activity = serializers.CharField(required=False, allow_blank=True, default="")
    remarks = serializers.CharField(required=False, allow_blank=True, default="")
