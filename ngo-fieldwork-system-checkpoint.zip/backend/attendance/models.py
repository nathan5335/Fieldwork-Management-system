from django.conf import settings
from django.db import models


class Attendance(models.Model):
    """One daily attendance record for a student, marked by NGO personnel."""

    class Status(models.TextChoices):
        PRESENT = "PRESENT", "Present"
        ABSENT = "ABSENT", "Absent"

    student = models.ForeignKey(
        "colleges.StudentProfile", on_delete=models.CASCADE, related_name="attendance_records"
    )
    ngo = models.ForeignKey("ngos.NGO", on_delete=models.CASCADE, related_name="attendance_records")
    application = models.ForeignKey(
        "applications.Application", on_delete=models.CASCADE, related_name="attendance_records"
    )
    date = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices)
    activity = models.CharField(max_length=255, blank=True)
    remarks = models.TextField(blank=True)
    marked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="attendance_marked"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-date"]
        constraints = [
            models.UniqueConstraint(
                fields=["student", "date"], name="unique_attendance_per_student_per_day"
            )
        ]

    def __str__(self):
        return f"{self.student} — {self.date} — {self.status}"
