# NGO-Based Student Field Work Management System — Backend

Django + DRF + Django Channels (WebSockets) + Simple JWT + SQLite backend for
the college mini-project. Built for **local deployment and demonstration**.

## Status

This is the backend half of the project. See `/PROGRESS.md` at the repo root
for exactly what's implemented vs. still pending (frontend, in particular,
is not built yet).

## Architecture

```
config/            settings, root urls, asgi (Channels) + ws routing, JWT ws auth middleware
common/            shared DRF permission classes, pagination, upload validators
accounts/          custom User model (5 roles), auth endpoints, registration flows
colleges/          College, PrincipalProfile, TeacherProfile, StudentProfile
ngos/               NGO registration + verification documents
applications/       Application + NGOPrioritySelection + Approval (audit trail)
                     — services.py holds the full workflow state machine
attendance/         daily attendance, marked by NGO personnel
reports/            daily reports (max 3/day), photo uploads, A–D grading
documents/          teacher notes / supporting documents
notifications/       Notification model + Channels consumer + push service
dashboard/          one role-shaped summary endpoint
```

## Local setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env            # edit as needed
python manage.py migrate
python manage.py seed_demo_data
python manage.py runserver      # daphne is installed, so this serves ASGI —
                                 # REST *and* WebSocket both work on :8000
```

No Redis, no separate process, nothing else to install: Channels is
configured with `InMemoryChannelLayer` for local single-process demo use
(see `config/settings.py`). This is intentional and sufficient for one
`runserver` process — the moment you'd run more than one backend process
(e.g. a real multi-worker deployment), swap `CHANNEL_LAYERS` for
`channels_redis.core.RedisChannelLayer` and run a local Redis instance;
everything else (consumer, groups, `group_send`) stays unchanged.

## Demo credentials (created by `seed_demo_data`)

| Role      | Email                    | Password         |
|-----------|---------------------------|-------------------|
| Admin     | admin@demo.local          | DemoAdmin#123     |
| Principal | principal@demo.local      | DemoPrincipal#123 |
| Teacher   | teacher1@demo.local       | DemoTeacher#123   |
| Teacher   | teacher2@demo.local       | DemoTeacher#123   |
| Student   | student1..4@demo.local    | DemoStudent#123   |
| NGO       | ngo1..3@demo.local        | DemoNGO#123       |

`student1` has a **fully completed** pipeline (assigned, attendance marked,
report submitted, grade A). `student2` is mid-cascade (priority-1 NGO
declined, priority-2 now active). `student3` is awaiting principal review.
`student4` is a fresh submission awaiting teacher review.

## Authentication

```
POST /api/auth/login/              {email, password} -> {access, refresh, user}
POST /api/auth/refresh/            {refresh} -> {access}
POST /api/auth/logout/             {refresh} -> 205 (blacklists the token)
GET  /api/auth/me/                 -> current user

POST /api/auth/register/principal/  Principal self-registration + College creation
POST /api/auth/register/teacher/    Principal creates a Teacher (auth required, IsPrincipal)
POST /api/auth/register/student/    Teacher creates a Student (auth required, IsTeacher)
POST /api/ngos/register/            NGO self-registration
```

Send the access token as `Authorization: Bearer <token>` on every other
request. There is deliberately **no public "Admin" registration/login page**
in the eventual frontend spec — but note the backend enforces role via the
JWT claim + `IsAdmin` permission class on every admin-only endpoint
regardless of which frontend route reached it. Hiding a route is a UX
choice, never the actual access boundary.

## Core workflow endpoints

```
POST /api/applications/submit/                          Student submits (3 distinct NGOs)
POST /api/applications/<id>/teacher-review/              {approve, reason}
POST /api/applications/<id>/principal-review/             {approve, reason}
GET  /api/applications/ngo-queue/                         NGO's currently-actionable priority slots
POST /api/applications/priorities/<id>/respond/            {approve, reason} — NGO priority response
POST /api/applications/<id>/cancel-priority-one/           Student cancels while priority-1 pending
POST /api/applications/<id>/reapply/                       After ALL_NGOS_REJECTED
GET  /api/applications/                                    Role-scoped list (filters: status, college, assigned_ngo)
GET  /api/applications/<id>/                               Full detail incl. audit trail

POST /api/attendance/mark/                                 NGO marks/corrects one day
GET  /api/attendance/my-summary/                           working days / present / absent / %

POST /api/reports/submit/                                  multipart; max 3/day, enforced server-side
POST /api/reports/<id>/review/                              NGO approve / request revision
POST /api/reports/photos/upload/                            multipart image upload
POST /api/reports/grades/<application_id>/award/            {grade: A|B|C|D, remarks}

GET  /api/notifications/                                    own notifications only
GET  /api/notifications/unread-count/
POST /api/notifications/<id>/read/
POST /api/notifications/mark-all-read/

GET  /api/dashboard/summary/                                payload shaped by request.user.role
```

Full OpenAPI schema: `GET /api/schema/`. Browsable Swagger UI: `/api/docs/`.

## WebSocket notifications

```
ws://localhost:8000/ws/notifications/?token=<JWT access token>
```

The access token is passed as a query parameter because browsers cannot set
custom headers on the WebSocket handshake. `config/middleware.py` validates
it with the same Simple JWT machinery as the REST API and derives the user
**only** from the token's claims — a client can never claim another user's
id. Each connection joins a private `user_<id>` Channels group; nothing is
ever broadcast to a shared/anonymous channel.

Quick manual test (after `pip install websockets`):

```python
import asyncio, websockets, json

async def main():
    token = "...access token from /api/auth/login/..."
    async with websockets.connect(f"ws://localhost:8000/ws/notifications/?token={token}") as ws:
        print(await ws.recv())          # {"type": "connected", ...}
        # trigger any workflow action from another client/terminal, then:
        print(await ws.recv())          # the real-time notification payload

asyncio.run(main())
```

## Running tests

```bash
python manage.py test               # all apps
python manage.py test applications  # workflow state machine + permission boundary tests
```

14 tests currently cover: submission validation (3 distinct NGOs), the full
teacher→principal→NGO-priority cascade (approval, rejection-to-next-priority,
all-three-rejected→reapply, priority-1 cancellation), the daily-report
3-attempt cap, and cross-role/cross-college API permission boundaries.

## Troubleshooting

- **`ModuleNotFoundError` on startup** — you're probably not inside the venv;
  run `source venv/bin/activate` (or `venv\Scripts\activate`) first.
- **WebSocket connects then immediately closes (code 4401)** — the token
  query param was missing, expired, or invalid; get a fresh access token
  from `/api/auth/login/`.
- **`db.sqlite3` and `media/` together are the persistent state** — back
  both up together; deleting one without the other orphans file references.
