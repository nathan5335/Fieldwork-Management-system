from django.urls import path

from . import views

urlpatterns = [
    path("mine/", views.MyCollegeView.as_view(), name="college-mine"),
    path("", views.CollegeListView.as_view(), name="college-list"),
    path("teachers/", views.TeacherListView.as_view(), name="teacher-list"),
    path("students/", views.StudentListView.as_view(), name="student-list"),
    path("students/<int:pk>/", views.StudentDetailView.as_view(), name="student-detail"),
]
