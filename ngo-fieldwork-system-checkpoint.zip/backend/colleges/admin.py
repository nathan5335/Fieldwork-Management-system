from django.contrib import admin

from .models import College, PrincipalProfile, TeacherProfile, StudentProfile

admin.site.register(College)
admin.site.register(PrincipalProfile)
admin.site.register(TeacherProfile)
admin.site.register(StudentProfile)
