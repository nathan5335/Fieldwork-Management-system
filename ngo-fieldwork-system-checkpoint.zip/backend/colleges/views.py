from django.shortcuts import get_object_or_404
from rest_framework import generics, permissions
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from common.pagination import StandardResultsPagination
from common.permissions import IsAdmin, IsPrincipal, IsTeacher

from .models import College, StudentProfile, TeacherProfile
from .serializers import CollegeSerializer, StudentProfileSerializer, TeacherProfileSerializer


class MyCollegeView(APIView):
    """GET/PATCH — the authenticated Principal's own college."""

    permission_classes = [permissions.IsAuthenticated, IsPrincipal]

    def get(self, request):
        college = request.user.principal_profile.college
        return Response(CollegeSerializer(college).data)

    def patch(self, request):
        college = request.user.principal_profile.college
        serializer = CollegeSerializer(college, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class TeacherListView(generics.ListAPIView):
    """Principal: teachers of their own college. Admin: all teachers."""

    serializer_class = TeacherProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ["department"]
    search_fields = ["user__first_name", "user__last_name", "employee_id", "user__email"]
    ordering_fields = ["created_at", "user__first_name"]

    def get_queryset(self):
        user = self.request.user
        qs = TeacherProfile.objects.select_related("user", "college")
        if user.is_admin:
            return qs
        if user.is_principal:
            return qs.filter(college=user.principal_profile.college)
        return qs.none()


class StudentListView(generics.ListAPIView):
    """Teacher: their own students. Principal: all students of their
    college. Admin: everyone."""

    serializer_class = StudentProfileSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ["department", "year", "semester"]
    search_fields = ["user__first_name", "user__last_name", "student_id", "register_number"]
    ordering_fields = ["created_at", "user__first_name"]

    def get_queryset(self):
        user = self.request.user
        qs = StudentProfile.objects.select_related("user", "college", "teacher__user")
        if user.is_admin:
            return qs
        if user.is_principal:
            return qs.filter(college=user.principal_profile.college)
        if user.is_teacher:
            return qs.filter(teacher=user.teacher_profile)
        return qs.none()


class StudentDetailView(generics.RetrieveAPIView):
    serializer_class = StudentProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        qs = StudentProfile.objects.select_related("user", "college", "teacher__user")
        if user.is_admin:
            return qs
        if user.is_principal:
            return qs.filter(college=user.principal_profile.college)
        if user.is_teacher:
            return qs.filter(teacher=user.teacher_profile)
        if user.is_student:
            return qs.filter(user=user)
        return qs.none()


class CollegeListView(generics.ListAPIView):
    """Admin-only directory of all colleges."""

    queryset = College.objects.all()
    serializer_class = CollegeSerializer
    permission_classes = [permissions.IsAuthenticated, IsAdmin]
    pagination_class = StandardResultsPagination
    filter_backends = [SearchFilter]
    search_fields = ["name", "code", "district", "state"]
