from rest_framework import serializers

from accounts.serializers import UserSerializer

from .models import College, PrincipalProfile, StudentProfile, TeacherProfile


class CollegeSerializer(serializers.ModelSerializer):
    class Meta:
        model = College
        fields = [
            "id", "name", "code", "address", "district", "state",
            "contact_number", "official_email", "website", "is_active", "created_at",
        ]
        read_only_fields = ["id", "code", "is_active", "created_at"]


class TeacherProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    college_name = serializers.CharField(source="college.name", read_only=True)

    class Meta:
        model = TeacherProfile
        fields = [
            "id", "user", "college", "college_name", "employee_id",
            "department", "designation", "created_at",
        ]
        read_only_fields = fields


class StudentProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    college_name = serializers.CharField(source="college.name", read_only=True)
    teacher_name = serializers.CharField(source="teacher.user.get_full_name", read_only=True, default="")

    class Meta:
        model = StudentProfile
        fields = [
            "id", "user", "college", "college_name", "teacher", "teacher_name",
            "student_id", "register_number", "course", "program", "year",
            "semester", "department", "address", "emergency_contact", "created_at",
        ]
        read_only_fields = fields
