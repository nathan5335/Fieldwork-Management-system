from django.conf import settings
from django.db import models


class College(models.Model):
    """A college, registered by the Principal who runs it."""

    name = models.CharField(max_length=255)
    code = models.CharField(max_length=30, unique=True)
    address = models.TextField()
    district = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    contact_number = models.CharField(max_length=20)
    official_email = models.EmailField()
    website = models.URLField(blank=True)

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.code})"


class PrincipalProfile(models.Model):
    """Role data for a Principal. A Principal manages exactly one college —
    the one they registered."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="principal_profile"
    )
    college = models.OneToOneField(
        College, on_delete=models.CASCADE, related_name="principal_profile"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Principal: {self.user.get_full_name()} — {self.college.name}"


class TeacherProfile(models.Model):
    """Role data for a Teacher. Created only by a Principal, always scoped to
    that Principal's college."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="teacher_profile"
    )
    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name="teachers")
    employee_id = models.CharField(max_length=50)
    department = models.CharField(max_length=150)
    designation = models.CharField(max_length=150, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="teachers_created",
        help_text="The Principal who created this Teacher account.",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["college", "employee_id"], name="unique_employee_id_per_college"
            )
        ]

    def __str__(self):
        return f"Teacher: {self.user.get_full_name()} — {self.college.name}"


class StudentProfile(models.Model):
    """Role data for a Student. Created only by a Teacher, who becomes the
    Student's assigned in-charge."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="student_profile"
    )
    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name="students")
    teacher = models.ForeignKey(
        TeacherProfile,
        on_delete=models.SET_NULL,
        null=True,
        related_name="students",
        help_text="Assigned in-charge teacher.",
    )
    student_id = models.CharField(max_length=50)
    register_number = models.CharField(max_length=50)
    course = models.CharField(max_length=150)
    program = models.CharField(max_length=150, blank=True)
    year = models.PositiveSmallIntegerField()
    semester = models.PositiveSmallIntegerField()
    department = models.CharField(max_length=150)
    address = models.TextField(blank=True)
    emergency_contact = models.CharField(max_length=20, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name="students_created",
        help_text="The Teacher who created this Student account.",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["college", "student_id"], name="unique_student_id_per_college"
            ),
            models.UniqueConstraint(
                fields=["college", "register_number"], name="unique_register_number_per_college"
            ),
        ]

    def __str__(self):
        return f"Student: {self.user.get_full_name()} — {self.student_id}"
