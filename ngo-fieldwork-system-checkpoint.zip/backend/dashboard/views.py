from django.db.models import Count
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import APIView

from accounts.models import User
from applications.models import Application, Approval, NGOPrioritySelection
from attendance.models import Attendance
from colleges.models import College, StudentProfile, TeacherProfile
from ngos.models import NGO
from notifications.models import Notification
from reports.models import Grade, PhotoUpload, Report

ACTIVE_STATUSES = [Application.Status.ASSIGNED, Application.Status.COMPLETED]


class DashboardSummaryView(APIView):
    """GET /api/dashboard/summary/ — one endpoint, payload shaped by the
    authenticated user's role. All figures are live aggregate queries, never
    hard-coded placeholders."""

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        handler = {
            User.Role.STUDENT: self._student,
            User.Role.TEACHER: self._teacher,
            User.Role.PRINCIPAL: self._principal,
            User.Role.NGO: self._ngo,
            User.Role.ADMIN: self._admin,
        }.get(user.role)
        if handler is None:
            return Response({"detail": "Unknown role."}, status=400)
        return Response(handler(user))

    # -- Student ------------------------------------------------------
    def _student(self, user):
        student = getattr(user, "student_profile", None)
        if student is None:
            return {"detail": "No student profile."}
        application = student.applications.order_by("-created_at").first()
        attendance_qs = Attendance.objects.filter(student=student)
        total_days = attendance_qs.count()
        present_days = attendance_qs.filter(status=Attendance.Status.PRESENT).count()
        grade = getattr(student, "grade", None)
        return {
            "application_status": application.status if application else None,
            "assigned_ngo": application.assigned_ngo.name if application and application.assigned_ngo else None,
            "attendance_percentage": round((present_days / total_days) * 100, 1) if total_days else 0.0,
            "reports_submitted": Report.objects.filter(student=student).count(),
            "current_grade": grade.grade if grade else None,
            "pending_notifications": Notification.objects.filter(recipient=user, is_read=False).count(),
        }

    # -- Teacher --------------------------------------------------------
    def _teacher(self, user):
        teacher = user.teacher_profile
        students = StudentProfile.objects.filter(teacher=teacher)
        pending_applications = Application.objects.filter(
            student__teacher=teacher, status=Application.Status.SUBMITTED_TO_TEACHER
        ).count()
        approved_students = Application.objects.filter(
            student__teacher=teacher, status__in=ACTIVE_STATUSES
        ).values("student").distinct().count()
        active_fieldwork = Application.objects.filter(
            student__teacher=teacher, status=Application.Status.ASSIGNED
        ).count()
        reports_count = Report.objects.filter(student__teacher=teacher).count()
        return {
            "total_students": students.count(),
            "pending_applications": pending_applications,
            "approved_students": approved_students,
            "active_fieldwork": active_fieldwork,
            "reports_count": reports_count,
        }

    # -- Principal --------------------------------------------------------
    def _principal(self, user):
        college = user.principal_profile.college
        applications = Application.objects.filter(college=college)
        ngo_distribution = list(
            applications.filter(assigned_ngo__isnull=False)
            .values("assigned_ngo__name")
            .annotate(count=Count("id"))
            .order_by("-count")
        )
        attendance_qs = Attendance.objects.filter(student__college=college)
        total_days = attendance_qs.count()
        present_days = attendance_qs.filter(status=Attendance.Status.PRESENT).count()
        return {
            "students": StudentProfile.objects.filter(college=college).count(),
            "teachers": TeacherProfile.objects.filter(college=college).count(),
            "pending_applications": applications.filter(status=Application.Status.PENDING_PRINCIPAL).count(),
            "approved_applications": applications.filter(status__in=ACTIVE_STATUSES).count(),
            "ongoing_fieldwork": applications.filter(status=Application.Status.ASSIGNED).count(),
            "ngo_distribution": ngo_distribution,
            "attendance_percentage": round((present_days / total_days) * 100, 1) if total_days else 0.0,
            "reports_count": Report.objects.filter(student__college=college).count(),
            "grades_awarded": Grade.objects.filter(student__college=college).count(),
        }

    # -- NGO ---------------------------------------------------------------
    def _ngo(self, user):
        ngo = user.ngo_profile
        return {
            "pending_applications": NGOPrioritySelection.objects.filter(
                ngo=ngo, status=NGOPrioritySelection.Status.ACTIVATED
            ).count(),
            "accepted_students": Application.objects.filter(assigned_ngo=ngo, status__in=ACTIVE_STATUSES).count(),
            "active_fieldwork": Application.objects.filter(assigned_ngo=ngo, status=Application.Status.ASSIGNED).count(),
            "todays_attendance_marked": Attendance.objects.filter(ngo=ngo, date=self._today()).count(),
            "pending_reports": Report.objects.filter(ngo=ngo, status=Report.Status.SUBMITTED).count(),
            "graded_students": Grade.objects.filter(ngo=ngo).count(),
        }

    # -- Admin ---------------------------------------------------------------
    def _admin(self, user):
        recent_activity = list(
            Approval.objects.select_related("user", "application")
            .order_by("-created_at")[:15]
            .values("action", "role", "created_at", "user__email", "application_id")
        )
        return {
            "total_users": User.objects.count(),
            "students": User.objects.filter(role=User.Role.STUDENT).count(),
            "teachers": User.objects.filter(role=User.Role.TEACHER).count(),
            "principals": User.objects.filter(role=User.Role.PRINCIPAL).count(),
            "ngos": User.objects.filter(role=User.Role.NGO).count(),
            "colleges": College.objects.count(),
            "applications": Application.objects.count(),
            "active_fieldwork": Application.objects.filter(status=Application.Status.ASSIGNED).count(),
            "completed_fieldwork": Application.objects.filter(status=Application.Status.COMPLETED).count(),
            "reports": Report.objects.count(),
            "photos": PhotoUpload.objects.count(),
            "attendance_records": Attendance.objects.count(),
            "grades": Grade.objects.count(),
            "recent_activity": recent_activity,
        }

    @staticmethod
    def _today():
        from django.utils import timezone
        return timezone.localdate()
