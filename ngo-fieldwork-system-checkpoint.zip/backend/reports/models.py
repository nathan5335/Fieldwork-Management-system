from django.conf import settings
from django.db import models


def report_upload_path(instance, filename):
    return f"reports/{instance.student_id}/{instance.date}/{filename}"


class Report(models.Model):
    """A daily fieldwork report. A student may submit/resubmit at most 3
    times per (student, date) — enforced in the service layer inside a
    transaction, not just here, since it depends on a live COUNT query."""

    class Status(models.TextChoices):
        SUBMITTED = "SUBMITTED", "Submitted"
        UNDER_REVIEW = "UNDER_REVIEW", "Under Review"
        APPROVED = "APPROVED", "Approved"
        REVISION_REQUIRED = "REVISION_REQUIRED", "Revision Required"

    student = models.ForeignKey(
        "colleges.StudentProfile", on_delete=models.CASCADE, related_name="reports"
    )
    ngo = models.ForeignKey("ngos.NGO", on_delete=models.CASCADE, related_name="reports")
    application = models.ForeignKey(
        "applications.Application", on_delete=models.CASCADE, related_name="reports"
    )
    date = models.DateField()
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to=report_upload_path, blank=True, null=True)
    attempt_number = models.PositiveSmallIntegerField()
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED)
    feedback = models.TextField(blank=True)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="reports_reviewed",
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-date", "-attempt_number"]
        constraints = [
            models.UniqueConstraint(
                fields=["student", "date", "attempt_number"],
                name="unique_attempt_per_student_per_day",
            )
        ]

    def __str__(self):
        return f"{self.student} — {self.date} — attempt {self.attempt_number}"


class PhotoUpload(models.Model):
    """Geo-tagged-evidence photo uploaded by a student. No map/GPS tracking
    in this version — the photo itself is the evidence, timestamped."""

    def photo_upload_path(instance, filename):
        return f"photos/{instance.student_id}/{filename}"

    student = models.ForeignKey(
        "colleges.StudentProfile", on_delete=models.CASCADE, related_name="photos"
    )
    ngo = models.ForeignKey("ngos.NGO", on_delete=models.CASCADE, related_name="photos")
    application = models.ForeignKey(
        "applications.Application", on_delete=models.CASCADE, related_name="photos"
    )
    image = models.ImageField(upload_to=photo_upload_path)
    caption = models.CharField(max_length=255, blank=True)
    taken_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-taken_at"]

    def __str__(self):
        return f"Photo — {self.student} — {self.taken_at:%Y-%m-%d %H:%M}"


class Grade(models.Model):
    """Final fieldwork grade, awarded once by NGO personnel. Letter grades
    only — A/B/C/D, never a percentage."""

    class Letter(models.TextChoices):
        A = "A", "A"
        B = "B", "B"
        C = "C", "C"
        D = "D", "D"

    student = models.OneToOneField(
        "colleges.StudentProfile", on_delete=models.CASCADE, related_name="grade"
    )
    ngo = models.ForeignKey("ngos.NGO", on_delete=models.CASCADE, related_name="grades_awarded")
    application = models.OneToOneField(
        "applications.Application", on_delete=models.CASCADE, related_name="grade"
    )
    grade = models.CharField(max_length=1, choices=Letter.choices)
    remarks = models.TextField(blank=True)
    awarded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="grades_given"
    )
    awarded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.student} — Grade {self.grade}"
