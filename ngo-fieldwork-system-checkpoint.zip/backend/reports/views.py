from django.shortcuts import get_object_or_404
from rest_framework import generics, permissions, status
from rest_framework.filters import OrderingFilter
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.response import Response
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend

from applications.models import Application
from common.pagination import StandardResultsPagination
from common.permissions import IsNGO, IsStudent

from . import services
from .models import Grade, PhotoUpload, Report
from .serializers import (
    GradeAwardSerializer,
    GradeSerializer,
    PhotoUploadSerializer,
    ReportReviewSerializer,
    ReportSerializer,
    ReportSubmitSerializer,
)


def _reports_queryset_for(user):
    qs = Report.objects.select_related("student__user", "ngo")
    if user.is_admin:
        return qs
    if user.is_ngo_user:
        return qs.filter(ngo=user.ngo_profile)
    if user.is_student:
        return qs.filter(student=user.student_profile)
    if user.is_teacher:
        return qs.filter(student__teacher=user.teacher_profile)
    if user.is_principal:
        return qs.filter(student__college=user.principal_profile.college)
    return qs.none()


class ReportListView(generics.ListAPIView):
    serializer_class = ReportSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ["student", "date", "status"]
    ordering_fields = ["date", "created_at"]

    def get_queryset(self):
        return _reports_queryset_for(self.request.user)


class ReportSubmitView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsStudent]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        serializer = ReportSubmitSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            report = services.submit_report(request.user.student_profile, **serializer.validated_data)
        except services.ReportError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ReportSerializer(report).data, status=status.HTTP_201_CREATED)


class ReportReviewView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsNGO]

    def post(self, request, pk):
        report = get_object_or_404(Report, pk=pk, ngo=request.user.ngo_profile)
        serializer = ReportReviewSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        report = services.review_report(
            report, request.user, serializer.validated_data["approve"], serializer.validated_data["feedback"]
        )
        return Response(ReportSerializer(report).data)


class PhotoUploadView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsStudent]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        image = request.FILES.get("image")
        if image is None:
            return Response({"detail": "image is required."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            photo = services.upload_photo(request.user.student_profile, image, request.data.get("caption", ""))
        except services.ReportError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(PhotoUploadSerializer(photo).data, status=status.HTTP_201_CREATED)


class PhotoListView(generics.ListAPIView):
    serializer_class = PhotoUploadSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["student"]

    def get_queryset(self):
        user = self.request.user
        qs = PhotoUpload.objects.select_related("student__user", "ngo")
        if user.is_admin:
            return qs
        if user.is_ngo_user:
            return qs.filter(ngo=user.ngo_profile)
        if user.is_student:
            return qs.filter(student=user.student_profile)
        if user.is_teacher:
            return qs.filter(student__teacher=user.teacher_profile)
        if user.is_principal:
            return qs.filter(student__college=user.principal_profile.college)
        return qs.none()


class GradeAwardView(APIView):
    permission_classes = [permissions.IsAuthenticated, IsNGO]

    def post(self, request, application_id):
        application = get_object_or_404(Application, pk=application_id)
        serializer = GradeAwardSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            grade = services.award_grade(application, request.user, **serializer.validated_data)
        except services.ReportError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(GradeSerializer(grade).data, status=status.HTTP_201_CREATED)


class GradeListView(generics.ListAPIView):
    serializer_class = GradeSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination

    def get_queryset(self):
        user = self.request.user
        qs = Grade.objects.select_related("student__user", "ngo")
        if user.is_admin:
            return qs
        if user.is_ngo_user:
            return qs.filter(ngo=user.ngo_profile)
        if user.is_student:
            return qs.filter(student=user.student_profile)
        if user.is_teacher:
            return qs.filter(student__teacher=user.teacher_profile)
        if user.is_principal:
            return qs.filter(student__college=user.principal_profile.college)
        return qs.none()
