from django.contrib import admin

from .models import Report, PhotoUpload, Grade

admin.site.register(Report)
admin.site.register(PhotoUpload)
admin.site.register(Grade)
