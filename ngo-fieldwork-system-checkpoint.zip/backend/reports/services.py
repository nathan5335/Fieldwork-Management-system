from django.db import transaction

from applications.models import Application
from notifications.services import notify

from .models import Grade, PhotoUpload, Report

MAX_REPORT_ATTEMPTS_PER_DAY = 3


class ReportError(Exception):
    pass


def _active_application_for(student_profile):
    application = Application.objects.filter(
        student=student_profile, status__in=[Application.Status.ASSIGNED, Application.Status.COMPLETED]
    ).select_related("assigned_ngo").first()
    if application is None or application.assigned_ngo is None:
        raise ReportError("You do not currently have an active NGO assignment.")
    return application


@transaction.atomic
def submit_report(student_profile, date, title, description="", file=None):
    application = _active_application_for(student_profile)

    # Enforced here, inside the transaction, against a live COUNT — never
    # trust a client-supplied attempt_number.
    existing_count = Report.objects.select_for_update().filter(
        student=student_profile, date=date
    ).count()
    if existing_count >= MAX_REPORT_ATTEMPTS_PER_DAY:
        raise ReportError(
            f"You have already submitted the maximum of {MAX_REPORT_ATTEMPTS_PER_DAY} reports for {date}."
        )

    report = Report.objects.create(
        student=student_profile,
        ngo=application.assigned_ngo,
        application=application,
        date=date,
        title=title,
        description=description,
        file=file,
        attempt_number=existing_count + 1,
        status=Report.Status.SUBMITTED,
    )
    notify(
        application.assigned_ngo.user, "REPORT_SUBMITTED", "New daily report submitted",
        f"{student_profile.user.get_full_name()} submitted a report for {date} (attempt {report.attempt_number}).",
        related_application=application,
    )
    return report


@transaction.atomic
def review_report(report, reviewer_user, approve, feedback=""):
    report.status = Report.Status.APPROVED if approve else Report.Status.REVISION_REQUIRED
    report.feedback = feedback
    report.reviewed_by = reviewer_user
    from django.utils import timezone
    report.reviewed_at = timezone.now()
    report.save()
    notify(
        report.student.user, "REPORT_FEEDBACK", "Feedback on your report",
        feedback or f"Your report for {report.date} was marked {report.get_status_display()}.",
        related_application=report.application,
    )
    return report


@transaction.atomic
def upload_photo(student_profile, image, caption=""):
    application = _active_application_for(student_profile)
    photo = PhotoUpload.objects.create(
        student=student_profile, ngo=application.assigned_ngo, application=application,
        image=image, caption=caption,
    )
    notify(
        application.assigned_ngo.user, "SYSTEM_NOTIFICATION", "New fieldwork photo uploaded",
        f"{student_profile.user.get_full_name()} uploaded a new fieldwork photo.",
        related_application=application,
    )
    return photo


@transaction.atomic
def award_grade(application, ngo_user, grade, remarks=""):
    if application.status not in (Application.Status.ASSIGNED, Application.Status.COMPLETED):
        raise ReportError("This student does not have an active or completed NGO assignment.")
    if application.assigned_ngo is None or application.assigned_ngo.user_id != ngo_user.id:
        raise ReportError("You are not the NGO assigned to this student.")

    grade_obj, _created = Grade.objects.update_or_create(
        application=application,
        defaults={
            "student": application.student, "ngo": application.assigned_ngo,
            "grade": grade, "remarks": remarks, "awarded_by": ngo_user,
        },
    )
    if application.status != Application.Status.COMPLETED:
        application.status = Application.Status.COMPLETED
        application.save(update_fields=["status", "updated_at"])

    notify(
        application.student.user, "GRADE_AWARDED", "Fieldwork grade awarded",
        f"You have been awarded grade {grade} for your fieldwork.", related_application=application,
    )
    return grade_obj
