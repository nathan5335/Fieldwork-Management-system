from django.urls import path

from . import views

urlpatterns = [
    path("", views.ReportListView.as_view(), name="report-list"),
    path("submit/", views.ReportSubmitView.as_view(), name="report-submit"),
    path("<int:pk>/review/", views.ReportReviewView.as_view(), name="report-review"),
    path("photos/", views.PhotoListView.as_view(), name="photo-list"),
    path("photos/upload/", views.PhotoUploadView.as_view(), name="photo-upload"),
    path("grades/", views.GradeListView.as_view(), name="grade-list"),
    path("grades/<int:application_id>/award/", views.GradeAwardView.as_view(), name="grade-award"),
]
