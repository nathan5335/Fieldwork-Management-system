from rest_framework import serializers

from common.validators import validate_document_file, validate_image_file

from .models import Grade, PhotoUpload, Report


class ReportSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source="student.user.get_full_name", read_only=True)

    class Meta:
        model = Report
        fields = [
            "id", "student", "student_name", "ngo", "application", "date", "title",
            "description", "file", "attempt_number", "status", "feedback",
            "reviewed_by", "reviewed_at", "created_at",
        ]
        read_only_fields = [
            "id", "student", "ngo", "application", "attempt_number", "status",
            "feedback", "reviewed_by", "reviewed_at", "created_at",
        ]


class ReportSubmitSerializer(serializers.Serializer):
    date = serializers.DateField()
    title = serializers.CharField(max_length=255)
    description = serializers.CharField(required=False, allow_blank=True, default="")
    file = serializers.FileField(required=False)

    def validate_file(self, value):
        validate_document_file(value)
        return value


class ReportReviewSerializer(serializers.Serializer):
    approve = serializers.BooleanField()
    feedback = serializers.CharField(required=False, allow_blank=True, default="")


class PhotoUploadSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source="student.user.get_full_name", read_only=True)

    class Meta:
        model = PhotoUpload
        fields = ["id", "student", "student_name", "ngo", "application", "image", "caption", "taken_at"]
        read_only_fields = ["id", "student", "ngo", "application", "taken_at"]

    def validate_image(self, value):
        validate_image_file(value)
        return value


class GradeSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source="student.user.get_full_name", read_only=True)
    ngo_name = serializers.CharField(source="ngo.name", read_only=True)

    class Meta:
        model = Grade
        fields = ["id", "student", "student_name", "ngo", "ngo_name", "application", "grade", "remarks", "awarded_at"]
        read_only_fields = fields


class GradeAwardSerializer(serializers.Serializer):
    grade = serializers.ChoiceField(choices=Grade.Letter.choices)
    remarks = serializers.CharField(required=False, allow_blank=True, default="")
