from django.conf import settings
from django.db import models

ALLOWED_DOCUMENT_EXTENSIONS = ["pdf", "doc", "docx", "jpg", "jpeg", "png"]


def document_upload_path(instance, filename):
    return f"teacher_notes/{instance.uploaded_by_id}/{filename}"


class Document(models.Model):
    """Generic supporting document: Teacher PDF notes and other fieldwork
    documents that don't belong to a more specific model (NGO verification
    docs live on NGOVerificationDocument; reports/photos have their own
    models)."""

    class DocumentType(models.TextChoices):
        TEACHER_NOTE = "TEACHER_NOTE", "Teacher Note"
        STUDENT_SUPPORTING_DOC = "STUDENT_SUPPORTING_DOC", "Student Supporting Document"
        OTHER = "OTHER", "Other"

    document_type = models.CharField(max_length=30, choices=DocumentType.choices)
    title = models.CharField(max_length=255)
    file = models.FileField(upload_to=document_upload_path)
    college = models.ForeignKey(
        "colleges.College", on_delete=models.CASCADE, related_name="documents", null=True, blank=True
    )
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="documents_uploaded"
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-uploaded_at"]

    def __str__(self):
        return f"{self.title} ({self.document_type})"
