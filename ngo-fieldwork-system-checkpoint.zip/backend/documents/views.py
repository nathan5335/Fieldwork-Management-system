from rest_framework import generics, permissions
from django_filters.rest_framework import DjangoFilterBackend

from common.pagination import StandardResultsPagination

from .models import Document
from .serializers import DocumentSerializer


class DocumentListCreateView(generics.ListCreateAPIView):
    """Teachers upload notes (scoped to their own college); everyone in the
    same college can list them. Admin sees everything."""

    serializer_class = DocumentSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ["document_type", "college"]

    def get_queryset(self):
        user = self.request.user
        qs = Document.objects.select_related("uploaded_by", "college")
        if user.is_admin:
            return qs
        college = (
            getattr(getattr(user, "principal_profile", None), "college", None)
            or getattr(getattr(user, "teacher_profile", None), "college", None)
            or getattr(getattr(user, "student_profile", None), "college", None)
        )
        return qs.filter(college=college) if college else qs.none()

    def perform_create(self, serializer):
        user = self.request.user
        if not user.is_teacher:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied("Only teachers can upload documents.")
        serializer.save(uploaded_by=user, college=user.teacher_profile.college)
