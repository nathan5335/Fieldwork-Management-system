from channels.generic.websocket import AsyncJsonWebsocketConsumer


class NotificationConsumer(AsyncJsonWebsocketConsumer):
    """One authenticated user = one private notification group
    (`user_<id>`). The connection is rejected outright if the JWT in the
    query string didn't resolve to a real user — there is no anonymous
    notification channel, and a user is never able to join anyone else's
    group."""

    async def connect(self):
        user = self.scope.get("user")
        if user is None or not user.is_authenticated:
            await self.close(code=4401)
            return
        self.group_name = f"user_{user.id}"
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()
        await self.send_json({"type": "connected", "message": "Notification stream connected."})

    async def disconnect(self, close_code):
        if hasattr(self, "group_name"):
            await self.channel_layer.group_discard(self.group_name, self.channel_name)

    # Dispatched for {"type": "notification.message", ...} group_send events
    async def notification_message(self, event):
        await self.send_json(event["payload"])
