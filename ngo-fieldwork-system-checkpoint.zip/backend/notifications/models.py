from django.conf import settings
from django.db import models


class Notification(models.Model):
    """A persisted notification. Always written to the database first/within
    the triggering transaction; WebSocket delivery (see services.py) is an
    additional real-time push on top of this record, never a replacement
    for it."""

    class NotificationType(models.TextChoices):
        APPLICATION_SUBMITTED = "APPLICATION_SUBMITTED", "Application Submitted"
        TEACHER_APPROVED = "TEACHER_APPROVED", "Teacher Approved"
        TEACHER_REJECTED = "TEACHER_REJECTED", "Teacher Rejected"
        PRINCIPAL_APPROVED = "PRINCIPAL_APPROVED", "Principal Approved"
        PRINCIPAL_REJECTED = "PRINCIPAL_REJECTED", "Principal Rejected"
        NGO_APPLICATION_RECEIVED = "NGO_APPLICATION_RECEIVED", "NGO Application Received"
        NGO_APPROVED = "NGO_APPROVED", "NGO Approved"
        NGO_REJECTED = "NGO_REJECTED", "NGO Rejected"
        NGO_PRIORITY_ACTIVATED = "NGO_PRIORITY_ACTIVATED", "NGO Priority Activated"
        NGO_PRIORITY_CANCELLED = "NGO_PRIORITY_CANCELLED", "NGO Priority Cancelled"
        NGO_ASSIGNED = "NGO_ASSIGNED", "NGO Assigned"
        ATTENDANCE_UPDATED = "ATTENDANCE_UPDATED", "Attendance Updated"
        REPORT_SUBMITTED = "REPORT_SUBMITTED", "Report Submitted"
        REPORT_FEEDBACK = "REPORT_FEEDBACK", "Report Feedback"
        GRADE_AWARDED = "GRADE_AWARDED", "Grade Awarded"
        REAPPLY_REQUIRED = "REAPPLY_REQUIRED", "Reapply Required"
        SYSTEM_NOTIFICATION = "SYSTEM_NOTIFICATION", "System Notification"

    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications"
    )
    notification_type = models.CharField(max_length=40, choices=NotificationType.choices)
    title = models.CharField(max_length=255)
    message = models.TextField()
    related_application = models.ForeignKey(
        "applications.Application",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="notifications",
    )
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["recipient", "is_read"])]

    def __str__(self):
        return f"{self.notification_type} → {self.recipient}"
