"""Notification creation + real-time delivery. Every call here (a) always
persists a Notification row, and (b) pushes it over the user's WebSocket
group only after the enclosing DB transaction actually commits — so a
rolled-back action never fires a phantom real-time event."""

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db import transaction

from .models import Notification


def notify(recipient, notification_type, title, message, related_application=None):
    notification = Notification.objects.create(
        recipient=recipient,
        notification_type=notification_type,
        title=title,
        message=message,
        related_application=related_application,
    )

    def _push():
        channel_layer = get_channel_layer()
        if channel_layer is None:
            return
        async_to_sync(channel_layer.group_send)(
            f"user_{recipient.id}",
            {
                "type": "notification.message",
                "payload": {
                    "notification_id": notification.id,
                    "notification_type": notification.notification_type,
                    "title": notification.title,
                    "message": notification.message,
                    "related_application": related_application.id if related_application else None,
                    "is_read": notification.is_read,
                    "created_at": notification.created_at.isoformat(),
                },
            },
        )

    transaction.on_commit(_push)
    return notification


def notify_many(recipients, notification_type, title, message, related_application=None):
    return [
        notify(user, notification_type, title, message, related_application)
        for user in recipients
        if user is not None
    ]
