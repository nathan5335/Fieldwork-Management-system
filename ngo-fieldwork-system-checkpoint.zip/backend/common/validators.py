"""Shared upload validators — extension, MIME sniffing, and size checks used
by NGO documents, teacher notes, reports, and photo uploads."""

import mimetypes

from django.conf import settings
from django.core.exceptions import ValidationError

ALLOWED_DOCUMENT_EXTENSIONS = {"pdf", "doc", "docx", "jpg", "jpeg", "png"}
ALLOWED_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}

ALLOWED_DOCUMENT_MIME_TYPES = {
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/jpeg",
    "image/png",
}
ALLOWED_IMAGE_MIME_TYPES = {"image/jpeg", "image/png", "image/webp"}


def _validate(file_obj, allowed_extensions, allowed_mime_types):
    max_bytes = getattr(settings, "MAX_UPLOAD_SIZE_MB", 10) * 1024 * 1024
    if file_obj.size > max_bytes:
        raise ValidationError(f"File too large — max {settings.MAX_UPLOAD_SIZE_MB} MB.")

    ext = file_obj.name.rsplit(".", 1)[-1].lower() if "." in file_obj.name else ""
    if ext not in allowed_extensions:
        raise ValidationError(f"Unsupported file extension: .{ext}")

    guessed_type, _ = mimetypes.guess_type(file_obj.name)
    content_type = getattr(file_obj, "content_type", None) or guessed_type
    if content_type not in allowed_mime_types:
        raise ValidationError(f"Unsupported file type: {content_type}")


def validate_document_file(file_obj):
    _validate(file_obj, ALLOWED_DOCUMENT_EXTENSIONS, ALLOWED_DOCUMENT_MIME_TYPES)


def validate_image_file(file_obj):
    _validate(file_obj, ALLOWED_IMAGE_EXTENSIONS, ALLOWED_IMAGE_MIME_TYPES)
