"""Reusable DRF permission classes. Every one of these re-checks role AND
ownership/relationship server-side — the frontend hiding a button is never
treated as access control."""

from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_admin)


class IsPrincipal(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_principal)


class IsTeacher(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_teacher)


class IsStudent(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_student)


class IsNGO(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_ngo_user)


class IsCollegeMember(BasePermission):
    """Object-level: the requesting user's college matches the object's
    college (works for objects exposing `.college` directly or via a
    related profile)."""

    def _college_of(self, user):
        if getattr(user, "is_principal", False):
            return getattr(getattr(user, "principal_profile", None), "college", None)
        if getattr(user, "is_teacher", False):
            return getattr(getattr(user, "teacher_profile", None), "college", None)
        if getattr(user, "is_student", False):
            return getattr(getattr(user, "student_profile", None), "college", None)
        return None

    def has_object_permission(self, request, view, obj):
        user_college = self._college_of(request.user)
        obj_college = getattr(obj, "college", None)
        return user_college is not None and obj_college is not None and user_college == obj_college


class IsAssignedTeacher(BasePermission):
    """Object-level: the requesting Teacher is the assigned in-charge of the
    student the object belongs to."""

    def has_object_permission(self, request, view, obj):
        if not getattr(request.user, "is_teacher", False):
            return False
        teacher_profile = getattr(request.user, "teacher_profile", None)
        student = getattr(obj, "student", obj if obj.__class__.__name__ == "StudentProfile" else None)
        return bool(teacher_profile and student and student.teacher_id == teacher_profile.id)


class IsAssignedNGO(BasePermission):
    """Object-level: the requesting NGO user is the NGO the object belongs
    to (directly, or via `.ngo`/`.application.assigned_ngo`)."""

    def has_object_permission(self, request, view, obj):
        if not getattr(request.user, "is_ngo_user", False):
            return False
        ngo_profile = getattr(request.user, "ngo_profile", None)
        obj_ngo = getattr(obj, "ngo", None)
        if obj_ngo is None and hasattr(obj, "assigned_ngo"):
            obj_ngo = obj.assigned_ngo
        return bool(ngo_profile and obj_ngo and ngo_profile.id == obj_ngo.id)


class IsOwner(BasePermission):
    """Object-level: obj.user (or obj itself, for User objects) is the
    requesting user. Used for profile-style endpoints."""

    def has_object_permission(self, request, view, obj):
        owner = getattr(obj, "user", obj)
        return owner == request.user


class ReadOnly(BasePermission):
    def has_permission(self, request, view):
        return request.method in SAFE_METHODS
