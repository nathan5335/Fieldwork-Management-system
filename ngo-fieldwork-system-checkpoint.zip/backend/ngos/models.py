from django.conf import settings
from django.db import models


class NGO(models.Model):
    """An NGO that registers itself and can subsequently receive student
    fieldwork applications."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="ngo_profile"
    )
    name = models.CharField(max_length=255)
    address = models.TextField()
    contact_person = models.CharField(max_length=150)
    contact_number = models.CharField(max_length=20)
    email = models.EmailField()
    areas_of_work = models.TextField(help_text="Comma-separated or free text.")
    description = models.TextField(blank=True)
    registration_info = models.CharField(max_length=255, blank=True)
    logo = models.ImageField(upload_to="ngo_logos/", blank=True, null=True)

    is_verified = models.BooleanField(
        default=False, help_text="Set by Admin after reviewing verification documents."
    )
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class NGOVerificationDocument(models.Model):
    """Verification documents uploaded at NGO registration time."""

    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name="verification_documents")
    file = models.FileField(upload_to="ngo_documents/")
    label = models.CharField(max_length=150, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ngo.name} — {self.label or self.file.name}"
