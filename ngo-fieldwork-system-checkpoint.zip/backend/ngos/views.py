from rest_framework import generics, permissions, status
from rest_framework.filters import SearchFilter
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView

from common.pagination import StandardResultsPagination
from common.permissions import IsAdmin, IsNGO

from .models import NGO, NGOVerificationDocument
from .serializers import NGORegistrationSerializer, NGOSerializer, NGOVerificationDocumentSerializer


class NGORegisterView(generics.CreateAPIView):
    serializer_class = NGORegistrationSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ngo = serializer.save()
        return Response(NGOSerializer(ngo).data, status=status.HTTP_201_CREATED)


class NGOListView(generics.ListAPIView):
    """Verified + active NGOs only — this is the pool students choose their
    three priorities from. Admin sees every NGO, including unverified."""

    serializer_class = NGOSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsPagination
    filter_backends = [SearchFilter]
    search_fields = ["name", "areas_of_work"]

    def get_queryset(self):
        if self.request.user.is_admin:
            return NGO.objects.all().prefetch_related("verification_documents")
        return NGO.objects.filter(is_verified=True, is_active=True).prefetch_related("verification_documents")


class MyNGOView(APIView):
    """GET/PATCH — the authenticated NGO user's own profile."""

    permission_classes = [permissions.IsAuthenticated, IsNGO]

    def get(self, request):
        return Response(NGOSerializer(request.user.ngo_profile).data)

    def patch(self, request):
        serializer = NGOSerializer(request.user.ngo_profile, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class NGOVerificationDocumentUploadView(generics.CreateAPIView):
    serializer_class = NGOVerificationDocumentSerializer
    permission_classes = [permissions.IsAuthenticated, IsNGO]

    def perform_create(self, serializer):
        serializer.save(ngo=self.request.user.ngo_profile)


class NGOVerifyView(APIView):
    """Admin marks an NGO's documents as verified (or revokes verification)."""

    permission_classes = [permissions.IsAuthenticated, IsAdmin]

    def post(self, request, pk):
        ngo = get_object_or_404(NGO, pk=pk)
        ngo.is_verified = bool(request.data.get("is_verified", True))
        ngo.save(update_fields=["is_verified", "updated_at"])
        return Response(NGOSerializer(ngo).data)
