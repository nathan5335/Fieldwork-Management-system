from django.urls import path

from . import views

urlpatterns = [
    path("register/", views.NGORegisterView.as_view(), name="ngo-register"),
    path("", views.NGOListView.as_view(), name="ngo-list"),
    path("mine/", views.MyNGOView.as_view(), name="ngo-mine"),
    path("documents/", views.NGOVerificationDocumentUploadView.as_view(), name="ngo-document-upload"),
    path("<int:pk>/verify/", views.NGOVerifyView.as_view(), name="ngo-verify"),
]
