from django.contrib.auth.password_validation import validate_password
from django.db import transaction
from rest_framework import serializers

from accounts.models import User
from accounts.serializers import UserSerializer
from common.validators import validate_document_file

from .models import NGO, NGOVerificationDocument


class NGOVerificationDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = NGOVerificationDocument
        fields = ["id", "ngo", "file", "label", "uploaded_at"]
        read_only_fields = ["id", "ngo", "uploaded_at"]

    def validate_file(self, value):
        validate_document_file(value)
        return value


class NGOSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    verification_documents = NGOVerificationDocumentSerializer(many=True, read_only=True)

    class Meta:
        model = NGO
        fields = [
            "id", "user", "name", "address", "contact_person", "contact_number",
            "email", "areas_of_work", "description", "registration_info", "logo",
            "verification_documents", "is_verified", "is_active", "created_at",
        ]
        read_only_fields = ["id", "user", "is_verified", "is_active", "created_at"]


class NGORegistrationSerializer(serializers.Serializer):
    """NGO self-registration. Creates the User (role=NGO) and NGO profile
    atomically. is_verified starts False until Admin reviews the uploaded
    verification documents."""

    first_name = serializers.CharField(max_length=150, help_text="Contact person's first name.")
    last_name = serializers.CharField(max_length=150, required=False, allow_blank=True)
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, validators=[validate_password])

    name = serializers.CharField(max_length=255)
    address = serializers.CharField()
    contact_person = serializers.CharField(max_length=150)
    contact_number = serializers.CharField(max_length=20)
    ngo_email = serializers.EmailField()
    areas_of_work = serializers.CharField()
    description = serializers.CharField(required=False, allow_blank=True)
    registration_info = serializers.CharField(max_length=255, required=False, allow_blank=True)

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("A user with this email already exists.")
        return value

    @transaction.atomic
    def create(self, validated_data):
        user = User.objects.create_user(
            email=validated_data["email"],
            password=validated_data["password"],
            first_name=validated_data["first_name"],
            last_name=validated_data.get("last_name", ""),
            role=User.Role.NGO,
        )
        return NGO.objects.create(
            user=user,
            name=validated_data["name"],
            address=validated_data["address"],
            contact_person=validated_data["contact_person"],
            contact_number=validated_data["contact_number"],
            email=validated_data["ngo_email"],
            areas_of_work=validated_data["areas_of_work"],
            description=validated_data.get("description", ""),
            registration_info=validated_data.get("registration_info", ""),
        )
