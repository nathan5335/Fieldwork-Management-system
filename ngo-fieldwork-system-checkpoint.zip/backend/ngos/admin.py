from django.contrib import admin

from .models import NGO, NGOVerificationDocument

admin.site.register(NGO)
admin.site.register(NGOVerificationDocument)
