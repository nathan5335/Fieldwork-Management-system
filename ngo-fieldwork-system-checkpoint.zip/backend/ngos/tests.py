from django.test import TestCase
from rest_framework.test import APIClient

from accounts.models import User
from ngos.models import NGO


class NGOVerificationTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(email="admin@test.local", password="TestPass#123", first_name="Ada")
        self.ngo_user = User.objects.create_user(
            email="ngo@test.local", password="TestPass#123", first_name="N", role=User.Role.NGO
        )
        self.ngo = NGO.objects.create(
            user=self.ngo_user, name="Unverified NGO", address="A", contact_person="C",
            contact_number="1", email="ngo@test.local", areas_of_work="Work",
        )
        self.student = User.objects.create_user(
            email="s@test.local", password="TestPass#123", first_name="S", role=User.Role.STUDENT
        )
        self.client = APIClient()

    def _login(self, email):
        r = self.client.post("/api/auth/login/", {"email": email, "password": "TestPass#123"})
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {r.data['access']}")

    def test_unverified_ngo_hidden_from_students_but_visible_to_admin(self):
        self._login("s@test.local")
        self.assertEqual(self.client.get("/api/ngos/").data["count"], 0)

        self._login("admin@test.local")
        self.assertEqual(self.client.get("/api/ngos/").data["count"], 1)

    def test_admin_verification_makes_ngo_selectable_by_students(self):
        self._login("admin@test.local")
        response = self.client.post(f"/api/ngos/{self.ngo.id}/verify/", {"is_verified": True}, format="json")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["is_verified"])

        self._login("s@test.local")
        self.assertEqual(self.client.get("/api/ngos/").data["count"], 1)

    def test_only_admin_can_verify(self):
        self._login("ngo@test.local")  # an NGO cannot verify itself
        response = self.client.post(f"/api/ngos/{self.ngo.id}/verify/", {"is_verified": True}, format="json")
        self.assertEqual(response.status_code, 403)
        self.ngo.refresh_from_db()
        self.assertFalse(self.ngo.is_verified)
