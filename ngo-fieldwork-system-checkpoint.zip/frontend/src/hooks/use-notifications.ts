"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import type { Notification, Paginated } from "@/lib/types";

const WS_URL = process.env.NEXT_PUBLIC_WS_URL ?? "ws://localhost:8000/ws";

/**
 * Fetches notification history over REST, then opens exactly one
 * authenticated WebSocket connection per mount (never re-opened on every
 * re-render) to receive real-time pushes and prepend them live.
 */
export function useNotifications() {
  const { accessToken, user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [connected, setConnected] = useState(false);
  const socketRef = useRef<WebSocket | null>(null);

  const refresh = useCallback(async () => {
    const [list, count] = await Promise.all([
      api.get<Paginated<Notification>>("/notifications/"),
      api.get<{ unread_count: number }>("/notifications/unread-count/"),
    ]);
    setNotifications(list.data.results);
    setUnreadCount(count.data.unread_count);
  }, []);

  useEffect(() => {
    if (user) refresh().catch(() => {});
  }, [user, refresh]);

  useEffect(() => {
    if (!accessToken || !user) return;

    const socket = new WebSocket(`${WS_URL}/notifications/?token=${accessToken}`);
    socketRef.current = socket;

    socket.onopen = () => setConnected(true);
    socket.onclose = () => setConnected(false);
    socket.onerror = () => setConnected(false);
    socket.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === "connected") return;
        setNotifications((prev) => [payload as Notification, ...prev]);
        setUnreadCount((prev) => prev + 1);
      } catch {
        /* ignore malformed frames */
      }
    };

    return () => {
      socket.close();
      socketRef.current = null;
    };
    // Reconnect only when identity/token actually changes, not on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accessToken, user?.id]);

  const markRead = useCallback(async (id: number) => {
    await api.post(`/notifications/${id}/read/`);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
    setUnreadCount((prev) => Math.max(0, prev - 1));
  }, []);

  const markAllRead = useCallback(async () => {
    await api.post("/notifications/mark-all-read/");
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    setUnreadCount(0);
  }, []);

  return { notifications, unreadCount, connected, markRead, markAllRead, refresh };
}
