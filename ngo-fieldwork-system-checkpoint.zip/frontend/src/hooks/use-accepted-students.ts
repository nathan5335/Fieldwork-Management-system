"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { ApplicationStatus, Paginated } from "@/lib/types";

export interface AcceptedStudent {
  applicationId: number;
  studentId: number; // StudentProfile pk — what the attendance API expects
  name: string;
  number: string;
  status: ApplicationStatus;
}

interface ApplicationRow {
  id: number;
  student: number;
  student_name: string;
  student_number: string;
  status: ApplicationStatus;
  assigned_ngo: number | null;
}

/** Students this NGO has actually accepted (ASSIGNED or COMPLETED). The
 * applications list also contains applications where this NGO was merely
 * a lower-priority option that someone else won, so we filter on the
 * assigned NGO's id, not just the status. */
export function useAcceptedStudents() {
  const [students, setStudents] = useState<AcceptedStudent[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [mine, apps] = await Promise.all([
        api.get<{ id: number }>("/ngos/mine/"),
        api.get<Paginated<ApplicationRow>>("/applications/", { params: { page_size: 100 } }),
      ]);
      if (cancelled) return;
      setStudents(
        apps.data.results
          .filter((a) => a.assigned_ngo === mine.data.id && (a.status === "ASSIGNED" || a.status === "COMPLETED"))
          .map((a) => ({
            applicationId: a.id,
            studentId: a.student,
            name: a.student_name,
            number: a.student_number,
            status: a.status,
          }))
      );
    })().catch(() => !cancelled && setStudents([]));
    return () => {
      cancelled = true;
    };
  }, []);

  return students;
}
