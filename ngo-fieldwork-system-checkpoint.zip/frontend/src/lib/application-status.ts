import type { ApplicationStatus } from "./types";

export const STATUS_LABEL: Record<ApplicationStatus, string> = {
  SUBMITTED_TO_TEACHER: "Awaiting teacher review",
  TEACHER_REJECTED: "Rejected by teacher",
  PENDING_PRINCIPAL: "Awaiting principal review",
  PRINCIPAL_REJECTED: "Rejected by principal",
  NGO_REVIEW: "Under NGO review",
  ALL_NGOS_REJECTED: "All NGOs declined",
  ASSIGNED: "Assigned — fieldwork active",
  COMPLETED: "Fieldwork completed",
  CANCELLED: "Cancelled",
};

export const STATUS_VARIANT: Record<ApplicationStatus, "neutral" | "success" | "warning" | "danger" | "info"> = {
  SUBMITTED_TO_TEACHER: "info",
  TEACHER_REJECTED: "danger",
  PENDING_PRINCIPAL: "info",
  PRINCIPAL_REJECTED: "danger",
  NGO_REVIEW: "warning",
  ALL_NGOS_REJECTED: "danger",
  ASSIGNED: "success",
  COMPLETED: "success",
  CANCELLED: "neutral",
};
