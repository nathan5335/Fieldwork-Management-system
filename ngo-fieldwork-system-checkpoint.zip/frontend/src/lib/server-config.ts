// Server-only: the Django API base URL as reachable FROM the Next.js server
// process (may differ from NEXT_PUBLIC_API_URL, which is what the BROWSER
// uses directly for ordinary authenticated requests).
export const DJANGO_API_URL = process.env.DJANGO_API_URL ?? "http://localhost:8000/api";

export const REFRESH_COOKIE = "fw_refresh_token";
