export type Role = "ADMIN" | "PRINCIPAL" | "TEACHER" | "STUDENT" | "NGO";

export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  full_name: string;
  phone: string;
  role: Role;
  profile_photo: string | null;
  is_active: boolean;
  is_verified: boolean;
}

export interface NGO {
  id: number;
  name: string;
  address: string;
  contact_person: string;
  contact_number: string;
  email: string;
  areas_of_work: string;
  description: string;
  is_verified: boolean;
  is_active: boolean;
}

export type PriorityStatus =
  | "PENDING"
  | "APPROVED"
  | "REJECTED"
  | "CANCELLED"
  | "ACTIVATED"
  | "SKIPPED";

export interface NGOPrioritySelection {
  id: number;
  ngo: NGO;
  priority: 1 | 2 | 3;
  status: PriorityStatus;
  response: string;
  response_reason: string;
  responded_at: string | null;
  created_at: string;
}

export type ApplicationStatus =
  | "SUBMITTED_TO_TEACHER"
  | "TEACHER_REJECTED"
  | "PENDING_PRINCIPAL"
  | "PRINCIPAL_REJECTED"
  | "NGO_REVIEW"
  | "ALL_NGOS_REJECTED"
  | "ASSIGNED"
  | "COMPLETED"
  | "CANCELLED";

export interface Approval {
  id: number;
  user: string | null;
  user_name: string;
  role: string;
  action: string;
  reason: string;
  created_at: string;
}

export interface Application {
  id: number;
  status: ApplicationStatus;
  assigned_ngo: NGO | null;
  teacher_rejection_reason: string;
  principal_rejection_reason: string;
  is_reapplication: boolean;
  previous_application: number | null;
  ngo_priorities: NGOPrioritySelection[];
  audit_trail: Approval[];
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: number;
  notification_type: string;
  title: string;
  message: string;
  related_application: number | null;
  is_read: boolean;
  created_at: string;
  read_at: string | null;
}

export interface StudentDashboardSummary {
  application_status: ApplicationStatus | null;
  assigned_ngo: string | null;
  attendance_percentage: number;
  reports_submitted: number;
  current_grade: string | null;
  pending_notifications: number;
}

export interface AttendanceRecord {
  id: number;
  student: number;
  student_name: string;
  ngo: number;
  ngo_name: string;
  application: number;
  date: string;
  status: "PRESENT" | "ABSENT";
  activity: string;
  remarks: string;
  created_at: string;
}

export interface Report {
  id: number;
  student: number;
  student_name: string;
  ngo: number;
  application: number;
  date: string;
  title: string;
  description: string;
  file: string | null;
  attempt_number: number;
  status: "SUBMITTED" | "UNDER_REVIEW" | "APPROVED" | "REVISION_REQUIRED";
  feedback: string;
  created_at: string;
}

export interface Paginated<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}
