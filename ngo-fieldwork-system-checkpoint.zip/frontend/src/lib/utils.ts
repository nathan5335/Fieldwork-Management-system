import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { isAxiosError } from "axios";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Extracts a human-readable message from an Axios/DRF error response
 * (which may be {detail: "..."} or {field: ["..."]}), falling back to a
 * generic message. Keeps call sites free of `any`. */
export function getErrorMessage(err: unknown, fallback = "Something went wrong."): string {
  if (isAxiosError(err)) {
    const data = err.response?.data;
    if (typeof data?.detail === "string") return data.detail;
    if (data && typeof data === "object") {
      const flattened = Object.values(data).flat().filter(Boolean);
      if (flattened.length) return flattened.join(" ");
    }
  }
  if (err instanceof Error) return err.message;
  return fallback;
}
