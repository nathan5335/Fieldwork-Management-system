import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";

/**
 * The access token lives ONLY in memory (this module-level variable),
 * never in localStorage/sessionStorage — per the spec's "no unnecessary
 * sensitive information in localStorage" requirement. The refresh token
 * lives in an httpOnly cookie set by our own Next.js route handlers
 * (see app/api/auth/*), so client-side JS can never read it either.
 *
 * On a hard page reload the access token is gone from memory; AuthProvider
 * silently calls /api/auth/refresh (our Next route, which forwards the
 * httpOnly cookie) to mint a new one on mount.
 */
let accessToken: string | null = null;

export function setAccessToken(token: string | null) {
  accessToken = token;
}

export function getAccessToken() {
  return accessToken;
}

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api",
});

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

let refreshPromise: Promise<string | null> | null = null;

async function silentRefresh(): Promise<string | null> {
  // De-duplicate concurrent 401s into a single refresh call.
  if (!refreshPromise) {
    refreshPromise = fetch("/api/auth/refresh", { method: "POST" })
      .then(async (res) => {
        if (!res.ok) return null;
        const data = await res.json();
        return data.access as string;
      })
      .catch(() => null)
      .finally(() => {
        refreshPromise = null;
      });
  }
  return refreshPromise;
}

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const original = error.config as (InternalAxiosRequestConfig & { _retried?: boolean }) | undefined;
    if (error.response?.status === 401 && original && !original._retried) {
      original._retried = true;
      const newToken = await silentRefresh();
      if (newToken) {
        setAccessToken(newToken);
        original.headers = original.headers ?? {};
        original.headers.Authorization = `Bearer ${newToken}`;
        return api(original);
      }
    }
    return Promise.reject(error);
  }
);
