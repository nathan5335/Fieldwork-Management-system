"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const schema = z.object({
  first_name: z.string().min(1, "Required"),
  last_name: z.string().optional(),
  email: z.string().email("Enter a valid email."),
  phone: z.string().optional(),
  password: z.string().min(8, "At least 8 characters."),
  student_id: z.string().min(1, "Required"),
  register_number: z.string().min(1, "Required"),
  course: z.string().min(1, "Required"),
  program: z.string().optional(),
  year: z.number({ error: "Required" }).int().min(1, "Must be 1 or more"),
  semester: z.number({ error: "Required" }).int().min(1, "Must be 1 or more"),
  department: z.string().min(1, "Required"),
  address: z.string().optional(),
  emergency_contact: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {error && <p className="text-xs text-danger">{error}</p>}
    </div>
  );
}

/** Teacher-only: creates a Student account. The backend assigns the
 * requesting Teacher as the student's in-charge and scopes the student to
 * the Teacher's college — neither is taken from this form. */
export function StudentCreateForm({ onCreated }: { onCreated: () => void }) {
  const [serverError, setServerError] = useState<string | null>(null);
  const [created, setCreated] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    setServerError(null);
    setCreated(null);
    try {
      await api.post("/auth/register/student/", values);
      setCreated(`${values.first_name} ${values.last_name ?? ""}`.trim());
      reset();
      onCreated();
    } catch (err) {
      setServerError(getErrorMessage(err, "Could not create student."));
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add a student</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="First name" error={errors.first_name?.message}>
              <Input {...register("first_name")} />
            </Field>
            <Field label="Last name" error={errors.last_name?.message}>
              <Input {...register("last_name")} />
            </Field>
          </div>
          <Field label="Email" error={errors.email?.message}>
            <Input type="email" {...register("email")} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Phone" error={errors.phone?.message}>
              <Input {...register("phone")} />
            </Field>
            <Field label="Temporary password" error={errors.password?.message}>
              <Input type="password" autoComplete="new-password" {...register("password")} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Student ID" error={errors.student_id?.message}>
              <Input {...register("student_id")} />
            </Field>
            <Field label="Register number" error={errors.register_number?.message}>
              <Input {...register("register_number")} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Course" error={errors.course?.message}>
              <Input {...register("course")} placeholder="e.g. MCA" />
            </Field>
            <Field label="Program" error={errors.program?.message}>
              <Input {...register("program")} />
            </Field>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Year" error={errors.year?.message}>
              <Input type="number" min={1} {...register("year", { valueAsNumber: true })} />
            </Field>
            <Field label="Semester" error={errors.semester?.message}>
              <Input type="number" min={1} {...register("semester", { valueAsNumber: true })} />
            </Field>
            <Field label="Department" error={errors.department?.message}>
              <Input {...register("department")} />
            </Field>
          </div>
          <Field label="Address" error={errors.address?.message}>
            <Input {...register("address")} />
          </Field>
          <Field label="Emergency contact" error={errors.emergency_contact?.message}>
            <Input {...register("emergency_contact")} />
          </Field>

          {serverError && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{serverError}</p>}
          {created && (
            <p className="rounded-md bg-success/10 px-3 py-2 text-sm text-success">
              {created} was added. Give them their email and the temporary password so they can sign in.
            </p>
          )}
          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Creating…" : "Create student"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
