"use client";

import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

/** Shared read-only profile view, reused by every role's /<role>/profile
 * page. There's no PATCH endpoint wired on the backend yet, so this is
 * display-only for now (see PROGRESS.md). */
export function ProfilePageContent({ extraFields = [] }: { extraFields?: [string, string][] }) {
  const { user } = useAuth();
  if (!user) return null;

  const fields: [string, string][] = [
    ["Full name", user.full_name],
    ["Email", user.email],
    ["Phone", user.phone || "—"],
    ["Role", user.role],
    ["Verified", user.is_verified ? "Yes" : "No"],
    ...extraFields,
  ];

  return (
    <Card className="max-w-lg">
      <CardHeader>
        <CardTitle>Profile</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {fields.map(([label, value]) => (
          <div key={label} className="flex justify-between border-b border-border/60 py-2 text-sm last:border-0">
            <span className="text-muted">{label}</span>
            <span className="font-medium">{value}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
