"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { NGO, Paginated } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { getErrorMessage } from "@/lib/utils";

interface Props {
  onSubmit: (priorities: { ngo_priority_1: number; ngo_priority_2: number; ngo_priority_3: number }) => Promise<void>;
  submitLabel: string;
}

/** Three ranked NGO pickers. Enforces three DISTINCT NGOs client-side —
 * the backend re-validates this regardless (spec section 15). */
export function NGOPriorityForm({ onSubmit, submitLabel }: Props) {
  const [ngos, setNgos] = useState<NGO[]>([]);
  const [choices, setChoices] = useState<[string, string, string]>(["", "", ""]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.get<Paginated<NGO>>("/ngos/?page_size=100").then((res) => setNgos(res.data.results));
  }, []);

  const setChoice = (index: 0 | 1 | 2, value: string) => {
    const next: [string, string, string] = [...choices] as [string, string, string];
    next[index] = value;
    setChoices(next);
  };

  const handleSubmit = async () => {
    setError(null);
    if (choices.some((c) => !c)) {
      setError("Please select all three priorities.");
      return;
    }
    if (new Set(choices).size !== 3) {
      setError("Priorities 1, 2 and 3 must be three different NGOs.");
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit({
        ngo_priority_1: Number(choices[0]),
        ngo_priority_2: Number(choices[1]),
        ngo_priority_3: Number(choices[2]),
      });
    } catch (err) {
      setError(getErrorMessage(err, "Submission failed."));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      {[0, 1, 2].map((i) => (
        <div key={i} className="space-y-1.5">
          <Label>Priority {i + 1} NGO</Label>
          <select
            value={choices[i]}
            onChange={(e) => setChoice(i as 0 | 1 | 2, e.target.value)}
            className="flex h-9 w-full rounded-md border border-border bg-surface-raised px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-role-student"
          >
            <option value="">Select an NGO…</option>
            {ngos.map((ngo) => (
              <option key={ngo.id} value={ngo.id}>
                {ngo.name} — {ngo.areas_of_work}
              </option>
            ))}
          </select>
        </div>
      ))}
      {error && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
      <Button onClick={handleSubmit} disabled={submitting}>
        {submitting ? "Submitting…" : submitLabel}
      </Button>
    </div>
  );
}
