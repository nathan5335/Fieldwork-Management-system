import { formatDistanceToNow } from "date-fns";
import { Badge } from "@/components/ui/badge";
import type { Application } from "@/lib/types";

const PRIORITY_VARIANT: Record<string, "neutral" | "success" | "warning" | "danger" | "info"> = {
  PENDING: "neutral",
  ACTIVATED: "info",
  APPROVED: "success",
  REJECTED: "danger",
  CANCELLED: "neutral",
  SKIPPED: "neutral",
};

export function ApplicationTimeline({ application }: { application: Application }) {
  return (
    <div className="space-y-6">
      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">NGO priorities</p>
        <div className="space-y-2">
          {[...application.ngo_priorities]
            .sort((a, b) => a.priority - b.priority)
            .map((p) => (
              <div
                key={p.id}
                className="flex items-center justify-between rounded-md border border-border bg-surface-raised px-3 py-2"
              >
                <div>
                  <p className="text-sm font-medium">
                    Priority {p.priority} — {p.ngo.name}
                  </p>
                  {p.response_reason && <p className="mt-0.5 text-xs text-muted">{p.response_reason}</p>}
                </div>
                <Badge variant={PRIORITY_VARIANT[p.status]}>{p.status}</Badge>
              </div>
            ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Audit trail</p>
        <ol className="space-y-3 border-l border-border pl-4">
          {application.audit_trail.map((entry) => (
            <li key={entry.id} className="relative">
              <span className="absolute -left-[21px] top-1 h-2 w-2 rounded-full bg-role-student" />
              <p className="text-sm">
                <span className="font-medium">{entry.action}</span>{" "}
                <span className="text-muted">
                  by {entry.user_name || "system"} {entry.role ? `(${entry.role.toLowerCase()})` : ""}
                </span>
              </p>
              {entry.reason && <p className="text-xs text-muted">{entry.reason}</p>}
              <p className="text-[11px] text-muted-soft">
                {formatDistanceToNow(new Date(entry.created_at), { addSuffix: true })}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
