"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { ReviewActions } from "@/components/application/review-actions";
import { STATUS_LABEL, STATUS_VARIANT } from "@/lib/application-status";
import { getErrorMessage } from "@/lib/utils";
import type { ApplicationStatus, Paginated } from "@/lib/types";

interface ApplicationRow {
  id: number;
  student_name: string;
  student_number: string;
  status: ApplicationStatus;
  created_at: string;
}

/** The "awaiting your review" queue + full history, shared by Teacher
 * (first review stage) and Principal (second review stage). The backend
 * scopes which applications each role can even see and independently
 * enforces who may review — this component only chooses which stage's
 * status counts as "pending" and which endpoint the buttons call. */
export function ApplicationReviewQueue({
  pendingStatus,
  reviewEndpoint,
}: {
  pendingStatus: ApplicationStatus;
  reviewEndpoint: "teacher-review" | "principal-review";
}) {
  const [rows, setRows] = useState<ApplicationRow[] | null>(null);

  const load = useCallback(() => {
    api
      .get<Paginated<ApplicationRow>>("/applications/", { params: { ordering: "-created_at", page_size: 100 } })
      .then((res) => setRows(res.data.results));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (!rows) return <Skeleton className="h-64" />;

  const pending = rows.filter((r) => r.status === pendingStatus);
  const others = rows.filter((r) => r.status !== pendingStatus);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="mb-3 text-sm font-medium text-muted">Awaiting your review</h2>
        {pending.length === 0 ? (
          <EmptyState title="Nothing pending" description="Applications needing your decision will show up here." />
        ) : (
          <div className="space-y-3">
            {pending.map((app) => (
              <Card key={app.id}>
                <CardContent className="flex items-center justify-between gap-4 p-4">
                  <p className="text-sm font-medium">
                    {app.student_name} <span className="text-xs text-muted">({app.student_number})</span>
                  </p>
                  <ReviewActions
                    onDecide={async (approve, reason) => {
                      try {
                        await api.post(`/applications/${app.id}/${reviewEndpoint}/`, { approve, reason });
                      } catch (err) {
                        throw new Error(getErrorMessage(err, "Could not record your decision."));
                      }
                      load();
                    }}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium text-muted">All applications</h2>
        <Card>
          <CardContent className="divide-y divide-border p-0">
            {others.length === 0 ? (
              <p className="px-4 py-6 text-center text-sm text-muted">No other applications.</p>
            ) : (
              others.map((app) => (
                <div key={app.id} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span>
                    {app.student_name} <span className="text-xs text-muted">({app.student_number})</span>
                  </span>
                  <Badge variant={STATUS_VARIANT[app.status]}>{STATUS_LABEL[app.status]}</Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
