"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";

/** Reusable approve/reject control with an optional reason field, used by
 * Teacher review, Principal review, and (with different copy) NGO response
 * actions. Reason is required for a rejection, optional for an approval. */
export function ReviewActions({
  onDecide,
  approveLabel = "Approve",
  rejectLabel = "Reject",
}: {
  onDecide: (approve: boolean, reason: string) => Promise<void>;
  approveLabel?: string;
  rejectLabel?: string;
}) {
  const [reason, setReason] = useState("");
  const [showReasonFor, setShowReasonFor] = useState<"reject" | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const decide = async (approve: boolean) => {
    if (!approve && showReasonFor !== "reject") {
      setShowReasonFor("reject");
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await onDecide(approve, reason);
      setReason("");
      setShowReasonFor(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Action failed.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-2">
      {showReasonFor === "reject" && (
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Reason for rejection…"
          rows={2}
          className="w-full rounded-md border border-border bg-surface-raised px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-brand"
        />
      )}
      {error && <p className="text-xs text-danger">{error}</p>}
      <div className="flex gap-2">
        <Button size="sm" variant="success" disabled={submitting} onClick={() => decide(true)}>
          {approveLabel}
        </Button>
        <Button size="sm" variant="destructive" disabled={submitting} onClick={() => decide(false)}>
          {showReasonFor === "reject" ? "Confirm reject" : rejectLabel}
        </Button>
      </div>
    </div>
  );
}
