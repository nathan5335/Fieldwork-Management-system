import { Leaf } from "lucide-react";

/**
 * Shared two-column shell for every auth page (login, hidden admin login).
 * Left panel is pure branding/decoration — no interactive elements, so it
 * carries zero functional risk. Right panel is a slot for the actual form,
 * whose logic is untouched by this wrapper. Collapses to a single column
 * on small screens.
 */
export function AuthLayout({ children, tagline }: { children: React.ReactNode; tagline?: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden border-r border-border bg-surface p-10 lg:flex">
        {/* Faint organic line decoration — CSS/SVG only, no external imagery */}
        <svg
          aria-hidden
          className="pointer-events-none absolute -bottom-24 -right-24 h-96 w-96 text-brand opacity-[0.07]"
          viewBox="0 0 200 200"
          fill="none"
        >
          <path
            d="M20 180C20 120 40 40 140 20C160 60 150 140 100 170C70 188 40 185 20 180Z"
            stroke="currentColor"
            strokeWidth="1.5"
          />
          <path d="M45 165C60 120 90 70 135 35" stroke="currentColor" strokeWidth="1" />
        </svg>

        <div className="flex items-center gap-2.5">
          <Leaf className="h-5 w-5 text-brand" />
          <span className="font-serif text-lg tracking-wide">FieldWork</span>
        </div>

        <div className="relative">
          <p className="font-serif text-3xl leading-snug text-foreground">
            {tagline ?? (
              <>
                Small steps.
                <br />
                Lasting change.
              </>
            )}
          </p>
          <p className="mt-4 max-w-sm text-sm text-muted">
            A shared home for colleges, students and NGO partners to run fieldwork placements
            from application to final grade.
          </p>
        </div>

        <p className="text-xs text-muted-soft">Fieldwork Management System</p>
      </div>

      <div className="flex w-full flex-col items-center justify-center px-4 py-16 lg:w-1/2">
        {children}
      </div>
    </div>
  );
}
