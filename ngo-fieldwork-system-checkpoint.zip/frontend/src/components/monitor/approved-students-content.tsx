"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { STATUS_LABEL, STATUS_VARIANT } from "@/lib/application-status";
import type { ApplicationStatus, Paginated } from "@/lib/types";

interface ApplicationRow {
  id: number;
  student_name: string;
  student_number: string;
  assigned_ngo_name: string;
  status: ApplicationStatus;
}

export function ApprovedStudentsContent() {
  const [rows, setRows] = useState<ApplicationRow[] | null>(null);

  useEffect(() => {
    api.get<Paginated<ApplicationRow>>("/applications/", { params: { page_size: 100 } }).then((res) =>
      setRows(res.data.results.filter((r) => r.status === "ASSIGNED" || r.status === "COMPLETED"))
    );
  }, []);

  const columns: Column<ApplicationRow>[] = [
    { header: "Student", cell: (r) => `${r.student_name} (${r.student_number})` },
    { header: "Assigned NGO", cell: (r) => r.assigned_ngo_name || "—" },
    { header: "Status", cell: (r) => <Badge variant={STATUS_VARIANT[r.status]}>{STATUS_LABEL[r.status]}</Badge> },
  ];

  return (
    <DataTable
      columns={columns}
      rows={rows}
      keyFor={(r) => r.id}
      emptyTitle="No students placed with an NGO yet"
    />
  );
}
