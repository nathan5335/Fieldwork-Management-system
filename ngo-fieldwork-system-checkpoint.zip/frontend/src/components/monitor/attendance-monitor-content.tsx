"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import type { AttendanceRecord, Paginated } from "@/lib/types";

export function AttendanceMonitorContent() {
  const [records, setRecords] = useState<AttendanceRecord[] | null>(null);

  useEffect(() => {
    api
      .get<Paginated<AttendanceRecord>>("/attendance/", { params: { ordering: "-date", page_size: 200 } })
      .then((res) => setRecords(res.data.results));
  }, []);

  const lowAttendance = useMemo(() => {
    if (!records) return [];
    const byStudent = new Map<string, { present: number; total: number }>();
    for (const r of records) {
      const entry = byStudent.get(r.student_name) ?? { present: 0, total: 0 };
      entry.total += 1;
      if (r.status === "PRESENT") entry.present += 1;
      byStudent.set(r.student_name, entry);
    }
    return Array.from(byStudent.entries())
      .map(([name, { present, total }]) => ({ name, pct: Math.round((present / total) * 100) }))
      .filter((s) => s.pct < 75);
  }, [records]);

  const columns: Column<AttendanceRecord>[] = [
    { header: "Student", cell: (r) => r.student_name },
    { header: "Date", cell: (r) => r.date },
    { header: "Status", cell: (r) => <Badge variant={r.status === "PRESENT" ? "success" : "danger"}>{r.status}</Badge> },
    { header: "Activity", cell: (r) => r.activity || "—" },
    { header: "NGO", cell: (r) => r.ngo_name },
  ];

  return (
    <div className="space-y-4">
      {lowAttendance.length > 0 && (
        <div className="rounded-md border border-warning/40 bg-warning/10 px-4 py-3 text-sm text-warning">
          Low attendance alert: {lowAttendance.map((s) => `${s.name} (${s.pct}%)`).join(", ")}
        </div>
      )}
      <DataTable columns={columns} rows={records} keyFor={(r) => r.id} emptyTitle="No attendance records yet" />
    </div>
  );
}
