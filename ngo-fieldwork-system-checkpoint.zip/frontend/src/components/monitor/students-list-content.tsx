"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Input } from "@/components/ui/input";
import type { Paginated } from "@/lib/types";

interface StudentRow {
  id: number;
  user: { full_name: string; email: string };
  teacher_name: string;
  student_id: string;
  register_number: string;
  course: string;
  year: number;
  semester: number;
  department: string;
}

/** Searchable student list shared by Teacher (their own students) and
 * Principal (whole college) — the backend scopes the result set by role. */
export function StudentsListContent({
  showTeacher = false,
  refreshKey = 0,
}: {
  showTeacher?: boolean;
  refreshKey?: number;
}) {
  const [students, setStudents] = useState<StudentRow[] | null>(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const timeout = setTimeout(() => {
      api
        .get<Paginated<StudentRow>>("/colleges/students/", { params: { search, page_size: 50 } })
        .then((res) => setStudents(res.data.results));
    }, 250);
    return () => clearTimeout(timeout);
  }, [search, refreshKey]);

  const columns: Column<StudentRow>[] = [
    { header: "Name", cell: (s) => s.user.full_name },
    { header: "Student ID", cell: (s) => s.student_id },
    { header: "Register No.", cell: (s) => s.register_number },
    { header: "Course", cell: (s) => s.course },
    { header: "Year / Sem", cell: (s) => `${s.year} / ${s.semester}` },
    { header: "Department", cell: (s) => s.department },
    ...(showTeacher ? [{ header: "Teacher", cell: (s: StudentRow) => s.teacher_name || "—" }] : []),
    { header: "Email", cell: (s) => s.user.email },
  ];

  return (
    <div className="space-y-4">
      <Input
        placeholder="Search by name, student ID…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="max-w-xs"
      />
      <DataTable columns={columns} rows={students} keyFor={(s) => s.id} emptyTitle="No students found" />
    </div>
  );
}
