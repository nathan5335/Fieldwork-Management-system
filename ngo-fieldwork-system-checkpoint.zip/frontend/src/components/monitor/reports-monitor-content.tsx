"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import type { Paginated, Report } from "@/lib/types";

const STATUS_VARIANT: Record<Report["status"], "neutral" | "success" | "warning" | "danger" | "info"> = {
  SUBMITTED: "info",
  UNDER_REVIEW: "warning",
  APPROVED: "success",
  REVISION_REQUIRED: "danger",
};

export function ReportsMonitorContent() {
  const [reports, setReports] = useState<Report[] | null>(null);

  useEffect(() => {
    api
      .get<Paginated<Report>>("/reports/", { params: { ordering: "-date", page_size: 200 } })
      .then((res) => setReports(res.data.results));
  }, []);

  const columns: Column<Report>[] = [
    { header: "Student", cell: (r) => r.student_name },
    { header: "Date", cell: (r) => `${r.date} (#${r.attempt_number})` },
    { header: "Title", cell: (r) => r.title },
    { header: "Status", cell: (r) => <Badge variant={STATUS_VARIANT[r.status]}>{r.status.replace("_", " ")}</Badge> },
    { header: "Feedback", cell: (r) => r.feedback || "—" },
  ];

  return <DataTable columns={columns} rows={reports} keyFor={(r) => r.id} emptyTitle="No reports submitted yet" />;
}
