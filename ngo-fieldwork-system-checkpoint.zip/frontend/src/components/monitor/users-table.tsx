"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Input } from "@/components/ui/input";
import type { Paginated, Role, User } from "@/lib/types";

const ROLE_VARIANT: Record<Role, "neutral" | "success" | "warning" | "danger" | "info"> = {
  ADMIN: "warning",
  PRINCIPAL: "info",
  TEACHER: "success",
  STUDENT: "neutral",
  NGO: "danger",
};

interface UserRow extends User {
  created_at: string;
}

/** Admin-only account directory. Pass `role` to lock the list to one role
 * (Students / Teachers / Principals pages); omit it for the all-users view
 * with a role filter. */
export function UsersTable({ role }: { role?: Role }) {
  const [rows, setRows] = useState<UserRow[] | null>(null);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("");

  useEffect(() => {
    const timeout = setTimeout(() => {
      api
        .get<Paginated<UserRow>>("/auth/users/", {
          params: { search, role: role ?? (roleFilter || undefined), page_size: 100, ordering: "-created_at" },
        })
        .then((res) => setRows(res.data.results));
    }, 250);
    return () => clearTimeout(timeout);
  }, [search, role, roleFilter]);

  const columns: Column<UserRow>[] = [
    { header: "Name", cell: (u) => u.full_name },
    { header: "Email", cell: (u) => u.email },
    { header: "Role", cell: (u) => <Badge variant={ROLE_VARIANT[u.role]}>{u.role}</Badge> },
    { header: "Verified", cell: (u) => (u.is_verified ? "Yes" : "No") },
    { header: "Active", cell: (u) => <Badge variant={u.is_active ? "success" : "danger"}>{u.is_active ? "Active" : "Inactive"}</Badge> },
    { header: "Joined", cell: (u) => format(new Date(u.created_at), "d MMM yyyy") },
  ];

  return (
    <div className="space-y-4">
      <div className="flex gap-3">
        <Input
          placeholder="Search name or email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-xs"
        />
        {!role && (
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="h-9 rounded-md border border-border bg-surface-raised px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-role-admin"
          >
            <option value="">All roles</option>
            {(["ADMIN", "PRINCIPAL", "TEACHER", "STUDENT", "NGO"] as Role[]).map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        )}
      </div>
      <DataTable columns={columns} rows={rows} keyFor={(u) => u.id} emptyTitle="No accounts match" />
    </div>
  );
}
