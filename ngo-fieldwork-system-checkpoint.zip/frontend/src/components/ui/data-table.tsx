import * as React from "react";
import { EmptyState } from "./empty-state";
import { Skeleton } from "./skeleton";

export interface Column<T> {
  header: string;
  cell: (row: T) => React.ReactNode;
  className?: string;
}

/** Minimal, theme-matched table used across the dashboards' list views
 * (students, applications, attendance, reports, grades, etc). Not
 * virtualized — fine for the page sizes this project's pagination uses. */
export function DataTable<T>({
  columns,
  rows,
  loading,
  emptyTitle = "Nothing here yet",
  keyFor,
}: {
  columns: Column<T>[];
  rows: T[] | null;
  loading?: boolean;
  emptyTitle?: string;
  keyFor: (row: T) => string | number;
}) {
  if (loading || rows === null) {
    return <Skeleton className="h-48" />;
  }
  if (rows.length === 0) {
    return <EmptyState title={emptyTitle} />;
  }
  return (
    <div className="overflow-x-auto rounded-lg border border-border">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border bg-surface-raised text-left text-xs uppercase tracking-wide text-muted">
            {columns.map((col) => (
              <th key={col.header} className={`px-4 py-2.5 font-medium ${col.className ?? ""}`}>
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={keyFor(row)} className="border-b border-border/60 last:border-0 hover:bg-surface-raised/50">
              {columns.map((col) => (
                <td key={col.header} className={`px-4 py-2.5 ${col.className ?? ""}`}>
                  {col.cell(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
