import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

// Dot + label rather than a filled pill (reference section 31): color
// carries a supporting signal, the text label is what actually
// communicates status, so this never relies on color alone.
const dotVariants = cva("h-1.5 w-1.5 shrink-0 rounded-full", {
  variants: {
    variant: {
      neutral: "bg-muted-soft",
      success: "bg-success",
      warning: "bg-warning",
      danger: "bg-danger",
      info: "bg-info",
    },
  },
  defaultVariants: { variant: "neutral" },
});

const textVariants = cva("text-xs font-medium", {
  variants: {
    variant: {
      neutral: "text-muted",
      success: "text-success",
      warning: "text-warning",
      danger: "text-danger",
      info: "text-info",
    },
  },
  defaultVariants: { variant: "neutral" },
});

export function Badge({
  className,
  variant,
  children,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & VariantProps<typeof dotVariants>) {
  return (
    <span className={cn("inline-flex items-center gap-1.5", className)} {...props}>
      <span className={dotVariants({ variant })} />
      <span className={textVariants({ variant })}>{children}</span>
    </span>
  );
}
