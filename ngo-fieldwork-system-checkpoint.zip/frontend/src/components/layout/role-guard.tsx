"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import type { Role } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";

/**
 * Wraps a role's dashboard tree. Redirects to /login if unauthenticated,
 * or to the user's OWN dashboard if they're logged in as the wrong role —
 * this is UI convenience only, since every API call is independently
 * permission-checked server-side regardless of what page loaded.
 */
export function RoleGuard({ role, children }: { role: Role; children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
      return;
    }
    if (user.role !== role) {
      router.replace("/" + user.role.toLowerCase() + "/dashboard");
    }
  }, [loading, user, role, router]);

  if (loading || !user || user.role !== role) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Skeleton className="h-8 w-48" />
      </div>
    );
  }

  return <>{children}</>;
}
