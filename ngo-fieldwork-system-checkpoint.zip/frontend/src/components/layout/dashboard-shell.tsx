"use client";

import { LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { Sidebar, type NavItem } from "./sidebar";
import { NotificationBell } from "@/components/notifications/notification-bell";
import type { Role } from "@/lib/types";

export function DashboardShell({
  role,
  roleLabel,
  navItems,
  title,
  children,
}: {
  role: Role;
  roleLabel: string;
  navItems: NavItem[];
  title: string;
  children: React.ReactNode;
}) {
  const { user, logout } = useAuth();
  const router = useRouter();

  return (
    <div className="flex h-screen bg-background">
      <Sidebar role={role} roleLabel={roleLabel} items={navItems} />
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-surface px-6">
          <h1 className="text-sm font-semibold">{title}</h1>
          <div className="flex items-center gap-3">
            <NotificationBell />
            <div className="h-6 w-px bg-border" />
            <span className="text-sm text-muted">{user?.full_name}</span>
            <button
              onClick={async () => {
                await logout();
                router.replace("/login");
              }}
              className="flex h-8 w-8 items-center justify-center rounded-md text-muted hover:bg-surface-raised hover:text-foreground"
              aria-label="Log out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  );
}
