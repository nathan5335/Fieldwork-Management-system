"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Leaf, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Role } from "@/lib/types";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

const ROLE_ACCENT: Record<Role, string> = {
  ADMIN: "role-admin",
  PRINCIPAL: "role-principal",
  TEACHER: "role-teacher",
  STUDENT: "role-student",
  NGO: "role-ngo",
};

export function Sidebar({
  role,
  roleLabel,
  items,
}: {
  role: Role;
  roleLabel: string;
  items: NavItem[];
}) {
  const pathname = usePathname();
  const accent = ROLE_ACCENT[role];

  return (
    <aside className="flex h-screen w-60 shrink-0 flex-col border-r border-border bg-surface">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <Leaf className="h-4 w-4 shrink-0" style={{ color: `var(--${accent})` }} />
        <div>
          <p className="font-serif text-base leading-none tracking-wide">FieldWork</p>
          <p className="text-xs text-muted">{roleLabel}</p>
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 px-3">
        {items.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                active
                  ? "bg-surface-raised text-foreground font-medium"
                  : "text-muted hover:bg-surface-raised hover:text-foreground"
              )}
              style={active ? { boxShadow: `inset 2px 0 0 var(--${accent})` } : undefined}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
