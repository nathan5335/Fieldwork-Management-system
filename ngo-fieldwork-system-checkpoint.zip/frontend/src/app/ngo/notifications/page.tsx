import { NotificationsPageContent } from "@/components/notifications/notifications-page-content";

export default function NGONotificationsPage() {
  return <NotificationsPageContent />;
}
