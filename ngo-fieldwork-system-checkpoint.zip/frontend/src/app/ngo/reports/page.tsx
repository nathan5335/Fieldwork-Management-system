"use client";

import { useCallback, useEffect, useState } from "react";
import { format } from "date-fns";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { ReviewActions } from "@/components/application/review-actions";
import type { Paginated, Report } from "@/lib/types";

interface Photo {
  id: number;
  student_name: string;
  image: string;
  caption: string;
  taken_at: string;
}

const STATUS_VARIANT: Record<Report["status"], "neutral" | "success" | "warning" | "danger" | "info"> = {
  SUBMITTED: "info",
  UNDER_REVIEW: "warning",
  APPROVED: "success",
  REVISION_REQUIRED: "danger",
};

export default function NGOReportsPage() {
  const [reports, setReports] = useState<Report[] | null>(null);
  const [photos, setPhotos] = useState<Photo[] | null>(null);

  const loadReports = useCallback(() => {
    api
      .get<Paginated<Report>>("/reports/", { params: { ordering: "-date", page_size: 100 } })
      .then((res) => setReports(res.data.results));
  }, []);

  useEffect(() => {
    loadReports();
    api.get<Paginated<Photo>>("/reports/photos/").then((res) => setPhotos(res.data.results));
  }, [loadReports]);

  return (
    <div className="space-y-10">
      <section>
        <h2 className="mb-3 text-sm font-medium text-muted">Daily reports</h2>
        {!reports ? (
          <Skeleton className="h-48" />
        ) : reports.length === 0 ? (
          <EmptyState title="No reports submitted yet" />
        ) : (
          <div className="space-y-3">
            {reports.map((r) => (
              <Card key={r.id}>
                <CardContent className="space-y-3 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium">
                        {r.title} <span className="text-xs text-muted">— {r.student_name}</span>
                      </p>
                      <p className="mt-0.5 text-xs text-muted">
                        {r.date} · attempt {r.attempt_number} of 3 · submitted {format(new Date(r.created_at), "d MMM, HH:mm")}
                      </p>
                    </div>
                    <Badge variant={STATUS_VARIANT[r.status]}>{r.status.replace("_", " ")}</Badge>
                  </div>
                  {r.description && <p className="text-sm text-muted">{r.description}</p>}
                  {r.file && (
                    <a href={r.file} target="_blank" rel="noreferrer" className="text-sm text-info hover:underline">
                      Open attachment
                    </a>
                  )}
                  {r.feedback && (
                    <p className="rounded-md bg-surface-raised px-3 py-2 text-xs text-muted">Your feedback: {r.feedback}</p>
                  )}
                  {(r.status === "SUBMITTED" || r.status === "UNDER_REVIEW") && (
                    <ReviewActions
                      approveLabel="Approve"
                      rejectLabel="Request revision"
                      onDecide={async (approve, reason) => {
                        try {
                          await api.post(`/reports/${r.id}/review/`, { approve, feedback: reason });
                        } catch (err) {
                          throw new Error(getErrorMessage(err, "Could not save your review."));
                        }
                        loadReports();
                      }}
                    />
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="mb-3 text-sm font-medium text-muted">Fieldwork photographs</h2>
        {!photos ? (
          <Skeleton className="h-40" />
        ) : photos.length === 0 ? (
          <EmptyState title="No photographs uploaded yet" />
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {photos.map((p) => (
              <div key={p.id} className="overflow-hidden rounded-md border border-border">
                {/* eslint-disable-next-line @next/next/no-img-element -- user-uploaded evidence, not a static asset */}
                <img src={p.image} alt={p.caption || "Fieldwork photo"} className="aspect-square w-full object-cover" />
                <div className="p-2">
                  <p className="text-xs font-medium">{p.student_name}</p>
                  {p.caption && <p className="text-xs text-muted">{p.caption}</p>}
                  <p className="text-[11px] text-muted-soft">{format(new Date(p.taken_at), "d MMM yyyy, HH:mm")}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
