"use client";

import { LayoutDashboard, FileText, CalendarCheck, NotebookPen, Award, Bell, User } from "lucide-react";
import { RoleGuard } from "@/components/layout/role-guard";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import type { NavItem } from "@/components/layout/sidebar";
import { usePathname } from "next/navigation";

const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/ngo/dashboard", icon: LayoutDashboard },
  { label: "Applications", href: "/ngo/applications", icon: FileText },
  { label: "Attendance", href: "/ngo/attendance", icon: CalendarCheck },
  { label: "Reports", href: "/ngo/reports", icon: NotebookPen },
  { label: "Grades", href: "/ngo/grades", icon: Award },
  { label: "Notifications", href: "/ngo/notifications", icon: Bell },
  { label: "Profile", href: "/ngo/profile", icon: User },
];

const TITLES: Record<string, string> = {
  "/ngo/dashboard": "Dashboard",
  "/ngo/applications": "Applications",
  "/ngo/attendance": "Attendance",
  "/ngo/reports": "Reports & Photos",
  "/ngo/grades": "Grades",
  "/ngo/notifications": "Notifications",
  "/ngo/profile": "Profile",
};

export default function NGOLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <RoleGuard role="NGO">
      <DashboardShell role="NGO" roleLabel="NGO partner" navItems={NAV_ITEMS} title={TITLES[pathname] ?? "NGO"}>
        {children}
      </DashboardShell>
    </RoleGuard>
  );
}
