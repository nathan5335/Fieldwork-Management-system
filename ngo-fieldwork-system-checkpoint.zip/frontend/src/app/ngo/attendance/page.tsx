"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAcceptedStudents } from "@/hooks/use-accepted-students";
import type { AttendanceRecord, Paginated } from "@/lib/types";

export default function NGOAttendancePage() {
  const students = useAcceptedStudents();
  const [records, setRecords] = useState<AttendanceRecord[] | null>(null);

  const [studentId, setStudentId] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [status, setStatus] = useState<"PRESENT" | "ABSENT">("PRESENT");
  const [activity, setActivity] = useState("");
  const [remarks, setRemarks] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(() => {
    api
      .get<Paginated<AttendanceRecord>>("/attendance/", { params: { ordering: "-date", page_size: 100 } })
      .then((res) => setRecords(res.data.results));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleSubmit = async () => {
    setError(null);
    setSaved(null);
    if (!studentId) {
      setError("Select a student.");
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/attendance/mark/", { student: Number(studentId), date, status, activity, remarks });
      const who = students?.find((s) => String(s.studentId) === studentId)?.name;
      setSaved(`Marked ${who ?? "student"} ${status.toLowerCase()} for ${date}.`);
      setActivity("");
      setRemarks("");
      load();
    } catch (err) {
      setError(getErrorMessage(err, "Could not mark attendance."));
    } finally {
      setSubmitting(false);
    }
  };

  const columns: Column<AttendanceRecord>[] = [
    { header: "Date", cell: (r) => r.date },
    { header: "Student", cell: (r) => r.student_name },
    { header: "Status", cell: (r) => <Badge variant={r.status === "PRESENT" ? "success" : "danger"}>{r.status}</Badge> },
    { header: "Activity", cell: (r) => r.activity || "—" },
    { header: "Remarks", cell: (r) => r.remarks || "—" },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Mark attendance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Student</Label>
              <select
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="flex h-9 w-full rounded-md border border-border bg-surface-raised px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-role-ngo"
              >
                <option value="">{students === null ? "Loading…" : "Select a student…"}</option>
                {students?.map((s) => (
                  <option key={s.studentId} value={s.studentId}>
                    {s.name} ({s.number})
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              <p className="text-xs text-muted">Marking a date that already has a record corrects it.</p>
            </div>
            <div className="space-y-1.5">
              <Label>Status</Label>
              <div className="flex gap-2">
                {(["PRESENT", "ABSENT"] as const).map((s) => (
                  <Button
                    key={s}
                    type="button"
                    size="sm"
                    variant={status === s ? (s === "PRESENT" ? "success" : "destructive") : "outline"}
                    onClick={() => setStatus(s)}
                  >
                    {s === "PRESENT" ? "Present" : "Absent"}
                  </Button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Activity</Label>
              <Input value={activity} onChange={(e) => setActivity(e.target.value)} placeholder="What did they work on?" />
            </div>
            <div className="space-y-1.5">
              <Label>Remarks</Label>
              <Input value={remarks} onChange={(e) => setRemarks(e.target.value)} />
            </div>
            {error && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
            {saved && <p className="rounded-md bg-success/10 px-3 py-2 text-sm text-success">{saved}</p>}
            <Button onClick={handleSubmit} disabled={submitting} className="w-full">
              {submitting ? "Saving…" : "Save attendance"}
            </Button>
          </CardContent>
        </Card>
      </div>
      <div className="lg:col-span-3">
        <DataTable columns={columns} rows={records} keyFor={(r) => r.id} emptyTitle="No attendance marked yet" />
      </div>
    </div>
  );
}
