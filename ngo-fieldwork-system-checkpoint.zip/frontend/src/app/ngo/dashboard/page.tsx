"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChartCard } from "@/components/charts/bar-chart-card";
import type { Paginated } from "@/lib/types";

interface NGOSummary {
  pending_applications: number;
  accepted_students: number;
  active_fieldwork: number;
  todays_attendance_marked: number;
  pending_reports: number;
  graded_students: number;
}

export default function NGODashboardPage() {
  const [summary, setSummary] = useState<NGOSummary | null>(null);
  const [gradeCounts, setGradeCounts] = useState<{ grade: string; students: number }[] | null>(null);

  useEffect(() => {
    api.get<NGOSummary>("/dashboard/summary/").then((res) => setSummary(res.data));
    api.get<Paginated<{ grade: string }>>("/reports/grades/", { params: { page_size: 200 } }).then((res) => {
      const counts = new Map<string, number>(["A", "B", "C", "D"].map((g) => [g, 0]));
      res.data.results.forEach((g) => counts.set(g.grade, (counts.get(g.grade) ?? 0) + 1));
      setGradeCounts(Array.from(counts, ([grade, students]) => ({ grade, students })));
    });
  }, []);

  if (!summary) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }

  const cards = [
    { label: "Awaiting your response", value: summary.pending_applications },
    { label: "Accepted students", value: summary.accepted_students },
    { label: "Active fieldwork", value: summary.active_fieldwork },
    { label: "Attendance marked today", value: summary.todays_attendance_marked },
    { label: "Reports to review", value: summary.pending_reports },
    { label: "Students graded", value: summary.graded_students },
  ];

  const pipeline = [
    { stage: "Awaiting response", count: summary.pending_applications },
    { stage: "Active", count: summary.active_fieldwork },
    { stage: "Graded", count: summary.graded_students },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardHeader>
              <CardTitle>{c.label}</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">{c.value}</CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <BarChartCard title="Application pipeline" data={pipeline} xKey="stage" yKey="count" accent="--role-ngo" />
        <BarChartCard
          title="Grade distribution"
          data={gradeCounts ?? []}
          xKey="grade"
          yKey="students"
          accent="--role-ngo"
          emptyTitle="No grades awarded yet"
        />
      </div>
    </div>
  );
}
