"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { ReviewActions } from "@/components/application/review-actions";
import { useAcceptedStudents } from "@/hooks/use-accepted-students";
import type { Paginated } from "@/lib/types";

interface QueueItem {
  id: number; // NGOPrioritySelection pk — what the respond endpoint takes
  application_id: number;
  priority: number;
  student_name: string;
  student_number: string;
  course: string;
  college_name: string;
}

export default function NGOApplicationsPage() {
  const [queue, setQueue] = useState<QueueItem[] | null>(null);
  const accepted = useAcceptedStudents();

  const load = useCallback(() => {
    api.get<Paginated<QueueItem>>("/applications/ngo-queue/").then((res) => setQueue(res.data.results));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (!queue) return <Skeleton className="h-64" />;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="mb-3 text-sm font-medium text-muted">Awaiting your response</h2>
        {queue.length === 0 ? (
          <EmptyState
            title="No applications need a response"
            description="You'll be notified when a student's application reaches your organization."
          />
        ) : (
          <div className="space-y-3">
            {queue.map((item) => (
              <Card key={item.id}>
                <CardContent className="flex items-center justify-between gap-4 p-4">
                  <div>
                    <p className="text-sm font-medium">
                      {item.student_name} <span className="text-xs text-muted">({item.student_number})</span>
                    </p>
                    <p className="mt-0.5 text-xs text-muted">
                      {item.course} · {item.college_name}
                    </p>
                    <Badge variant="info" className="mt-2">
                      Priority {item.priority}
                    </Badge>
                  </div>
                  <ReviewActions
                    approveLabel="Accept student"
                    rejectLabel="Decline"
                    onDecide={async (approve, reason) => {
                      try {
                        await api.post(`/applications/priorities/${item.id}/respond/`, { approve, reason });
                      } catch (err) {
                        throw new Error(getErrorMessage(err, "Could not record your response."));
                      }
                      load();
                    }}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium text-muted">Accepted students</h2>
        <Card>
          <CardContent className="divide-y divide-border p-0">
            {!accepted ? (
              <Skeleton className="m-4 h-16" />
            ) : accepted.length === 0 ? (
              <p className="px-4 py-6 text-center text-sm text-muted">No accepted students yet.</p>
            ) : (
              accepted.map((s) => (
                <div key={s.applicationId} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span>
                    {s.name} <span className="text-xs text-muted">({s.number})</span>
                  </span>
                  <Badge variant={s.status === "COMPLETED" ? "success" : "info"}>
                    {s.status === "COMPLETED" ? "Completed" : "Active"}
                  </Badge>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
