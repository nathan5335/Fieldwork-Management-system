"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { ProfilePageContent } from "@/components/profile/profile-page-content";

interface NGOProfile {
  name: string;
  address: string;
  areas_of_work: string;
  is_verified: boolean;
}

export default function NGOProfilePage() {
  const [ngo, setNgo] = useState<NGOProfile | null>(null);

  useEffect(() => {
    api.get<NGOProfile>("/ngos/mine/").then((res) => setNgo(res.data));
  }, []);

  return (
    <ProfilePageContent
      extraFields={
        ngo
          ? [
              ["Organization", ngo.name],
              ["Address", ngo.address],
              ["Areas of work", ngo.areas_of_work],
              ["Admin-verified", ngo.is_verified ? "Yes" : "Pending review"],
            ]
          : []
      }
    />
  );
}
