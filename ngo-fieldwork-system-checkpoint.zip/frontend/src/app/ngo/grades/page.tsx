"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { useAcceptedStudents, type AcceptedStudent } from "@/hooks/use-accepted-students";
import type { Paginated } from "@/lib/types";

type Letter = "A" | "B" | "C" | "D";
const LETTERS: Letter[] = ["A", "B", "C", "D"];

interface GradeRow {
  id: number;
  application: number;
  grade: Letter;
  remarks: string;
}

function GradeRowCard({ student, existing, onSaved }: { student: AcceptedStudent; existing?: GradeRow; onSaved: () => void }) {
  const [letter, setLetter] = useState<Letter | "">(existing?.grade ?? "");
  const [remarks, setRemarks] = useState(existing?.remarks ?? "");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!letter) {
      setError("Choose a grade.");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await api.post(`/reports/grades/${student.applicationId}/award/`, { grade: letter, remarks });
      onSaved();
    } catch (err) {
      setError(getErrorMessage(err, "Could not save grade."));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardContent className="space-y-3 p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">
            {student.name} <span className="text-xs text-muted">({student.number})</span>
          </p>
          {existing && <Badge variant="success">Graded {existing.grade}</Badge>}
        </div>
        <div className="flex items-center gap-2">
          {LETTERS.map((l) => (
            <Button key={l} type="button" size="sm" variant={letter === l ? "default" : "outline"} onClick={() => setLetter(l)}>
              {l}
            </Button>
          ))}
        </div>
        <input
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
          placeholder="Remarks (optional)"
          className="flex h-9 w-full rounded-md border border-border bg-surface-raised px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-role-ngo"
        />
        {error && <p className="text-xs text-danger">{error}</p>}
        <Button size="sm" onClick={save} disabled={saving}>
          {saving ? "Saving…" : existing ? "Update grade" : "Award grade"}
        </Button>
      </CardContent>
    </Card>
  );
}

export default function NGOGradesPage() {
  const students = useAcceptedStudents();
  const [grades, setGrades] = useState<GradeRow[] | null>(null);

  const loadGrades = useCallback(() => {
    api.get<Paginated<GradeRow>>("/reports/grades/").then((res) => setGrades(res.data.results));
  }, []);

  useEffect(() => {
    loadGrades();
  }, [loadGrades]);

  if (!students || !grades) return <Skeleton className="h-64" />;
  if (students.length === 0) {
    return <EmptyState title="No accepted students to grade yet" description="Grades can be awarded once a student is assigned to you." />;
  }

  return (
    <div className="grid max-w-3xl gap-3">
      {students.map((s) => (
        <GradeRowCard
          key={`${s.applicationId}-${grades.find((g) => g.application === s.applicationId)?.grade ?? "none"}`}
          student={s}
          existing={grades.find((g) => g.application === s.applicationId)}
          onSaved={loadGrades}
        />
      ))}
    </div>
  );
}
