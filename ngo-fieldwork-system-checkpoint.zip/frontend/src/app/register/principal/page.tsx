"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const schema = z
  .object({
    first_name: z.string().min(1, "Required"),
    last_name: z.string().optional(),
    email: z.string().email(),
    phone: z.string().optional(),
    password: z.string().min(8, "At least 8 characters."),
    confirm_password: z.string(),
    college_name: z.string().min(1, "Required"),
    college_code: z.string().min(1, "Required"),
    address: z.string().min(1, "Required"),
    district: z.string().min(1, "Required"),
    state: z.string().min(1, "Required"),
    contact_number: z.string().min(1, "Required"),
    official_email: z.string().email(),
    website: z.string().optional(),
  })
  .refine((d) => d.password === d.confirm_password, {
    message: "Passwords do not match.",
    path: ["confirm_password"],
  });
type FormValues = z.infer<typeof schema>;

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {error && <p className="text-xs text-danger">{error}</p>}
    </div>
  );
}

export default function RegisterPrincipalPage() {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    setServerError(null);
    try {
      await api.post("/auth/register/principal/", values);
      router.push("/login?registered=principal");
    } catch (err) {
      setServerError(getErrorMessage(err, "Registration failed. Please try again."));
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-2xl">
        <h1 className="font-serif text-2xl">Register your college</h1>
        <p className="mt-1 text-sm text-muted">
          As Principal, you register once for both your own account and your college.
        </p>

        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-6">
          <fieldset className="space-y-4 rounded-lg border border-border p-4">
            <legend className="px-1 text-xs font-medium uppercase tracking-wide text-muted">
              Principal details
            </legend>
            <div className="grid grid-cols-2 gap-4">
              <Field label="First name" error={errors.first_name?.message}>
                <Input {...register("first_name")} />
              </Field>
              <Field label="Last name" error={errors.last_name?.message}>
                <Input {...register("last_name")} />
              </Field>
              <Field label="Email" error={errors.email?.message}>
                <Input type="email" {...register("email")} />
              </Field>
              <Field label="Phone" error={errors.phone?.message}>
                <Input {...register("phone")} />
              </Field>
              <Field label="Password" error={errors.password?.message}>
                <Input type="password" {...register("password")} />
              </Field>
              <Field label="Confirm password" error={errors.confirm_password?.message}>
                <Input type="password" {...register("confirm_password")} />
              </Field>
            </div>
          </fieldset>

          <fieldset className="space-y-4 rounded-lg border border-border p-4">
            <legend className="px-1 text-xs font-medium uppercase tracking-wide text-muted">
              College details
            </legend>
            <div className="grid grid-cols-2 gap-4">
              <Field label="College name" error={errors.college_name?.message}>
                <Input {...register("college_name")} />
              </Field>
              <Field label="College code" error={errors.college_code?.message}>
                <Input {...register("college_code")} />
              </Field>
              <Field label="Address" error={errors.address?.message}>
                <Input {...register("address")} />
              </Field>
              <Field label="District" error={errors.district?.message}>
                <Input {...register("district")} />
              </Field>
              <Field label="State" error={errors.state?.message}>
                <Input {...register("state")} />
              </Field>
              <Field label="Contact number" error={errors.contact_number?.message}>
                <Input {...register("contact_number")} />
              </Field>
              <Field label="Official email" error={errors.official_email?.message}>
                <Input type="email" {...register("official_email")} />
              </Field>
              <Field label="Website" error={errors.website?.message}>
                <Input {...register("website")} placeholder="https://" />
              </Field>
            </div>
          </fieldset>

          {serverError && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{serverError}</p>}

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Registering…" : "Register college"}
          </Button>
        </form>
        <p className="mt-6 text-center text-sm text-muted">
          Already registered? <Link href="/login" className="text-brand hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
