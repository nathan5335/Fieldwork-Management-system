"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const schema = z.object({
  first_name: z.string().min(1, "Required"),
  last_name: z.string().optional(),
  email: z.string().email(),
  password: z.string().min(8, "At least 8 characters."),
  name: z.string().min(1, "Required"),
  address: z.string().min(1, "Required"),
  contact_person: z.string().min(1, "Required"),
  contact_number: z.string().min(1, "Required"),
  ngo_email: z.string().email(),
  areas_of_work: z.string().min(1, "Required"),
  description: z.string().optional(),
  registration_info: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {error && <p className="text-xs text-danger">{error}</p>}
    </div>
  );
}

export default function RegisterNGOPage() {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const onSubmit = async (values: FormValues) => {
    setServerError(null);
    try {
      await api.post("/ngos/register/", values);
      router.push("/login?registered=ngo");
    } catch (err) {
      setServerError(getErrorMessage(err, "Registration failed. Please try again."));
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-10">
      <div className="w-full max-w-xl">
        <h1 className="font-serif text-2xl">Register your NGO</h1>
        <p className="mt-1 text-sm text-muted">
          After registration, an Admin reviews your verification documents before your NGO
          becomes visible to students choosing fieldwork placements.
        </p>

        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field label="Contact person — first name" error={errors.first_name?.message}>
              <Input {...register("first_name")} />
            </Field>
            <Field label="Last name" error={errors.last_name?.message}>
              <Input {...register("last_name")} />
            </Field>
            <Field label="Login email" error={errors.email?.message}>
              <Input type="email" {...register("email")} />
            </Field>
            <Field label="Password" error={errors.password?.message}>
              <Input type="password" {...register("password")} />
            </Field>
          </div>
          <Field label="NGO name" error={errors.name?.message}>
            <Input {...register("name")} />
          </Field>
          <Field label="Address" error={errors.address?.message}>
            <Input {...register("address")} />
          </Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Contact person (org)" error={errors.contact_person?.message}>
              <Input {...register("contact_person")} />
            </Field>
            <Field label="Contact number" error={errors.contact_number?.message}>
              <Input {...register("contact_number")} />
            </Field>
          </div>
          <Field label="Organization email" error={errors.ngo_email?.message}>
            <Input type="email" {...register("ngo_email")} />
          </Field>
          <Field label="Areas of work" error={errors.areas_of_work?.message}>
            <Input {...register("areas_of_work")} placeholder="e.g. Environmental conservation, literacy" />
          </Field>
          <Field label="Description" error={errors.description?.message}>
            <Input {...register("description")} />
          </Field>
          <Field label="Registration info" error={errors.registration_info?.message}>
            <Input {...register("registration_info")} placeholder="Registration number, etc." />
          </Field>

          {serverError && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{serverError}</p>}

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Registering…" : "Register NGO"}
          </Button>
        </form>
        <p className="mt-6 text-center text-sm text-muted">
          Already registered? <Link href="/login" className="text-brand hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
