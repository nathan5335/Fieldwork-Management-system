import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { DJANGO_API_URL, REFRESH_COOKIE } from "@/lib/server-config";

export async function POST() {
  const cookieStore = await cookies();
  const refresh = cookieStore.get(REFRESH_COOKIE)?.value;
  if (!refresh) {
    return NextResponse.json({ detail: "No refresh token." }, { status: 401 });
  }

  const djangoRes = await fetch(`${DJANGO_API_URL}/auth/refresh/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh }),
  });

  const data = await djangoRes.json();
  if (!djangoRes.ok) {
    const response = NextResponse.json(data, { status: djangoRes.status });
    response.cookies.delete(REFRESH_COOKIE);
    return response;
  }

  const response = NextResponse.json({ access: data.access });
  // ROTATE_REFRESH_TOKENS is on server-side, so a new refresh token comes
  // back on every call — re-set the cookie so the old (now-blacklisted)
  // one is never reused.
  if (data.refresh) {
    response.cookies.set(REFRESH_COOKIE, data.refresh, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });
  }
  return response;
}
