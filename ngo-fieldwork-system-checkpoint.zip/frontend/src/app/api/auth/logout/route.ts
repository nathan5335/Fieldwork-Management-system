import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { DJANGO_API_URL, REFRESH_COOKIE } from "@/lib/server-config";

export async function POST() {
  const cookieStore = await cookies();
  const refresh = cookieStore.get(REFRESH_COOKIE)?.value;

  if (refresh) {
    await fetch(`${DJANGO_API_URL}/auth/logout/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh }),
    }).catch(() => {
      /* best-effort blacklist; cookie is cleared regardless */
    });
  }

  const response = NextResponse.json({ ok: true });
  response.cookies.delete(REFRESH_COOKIE);
  return response;
}
