import { NextResponse } from "next/server";
import { DJANGO_API_URL, REFRESH_COOKIE } from "@/lib/server-config";

/**
 * Proxies login to Django, then peels the refresh token off the response
 * and stores it as an httpOnly cookie — it never reaches browser JS. Only
 * the access token + user object go back in the JSON body.
 */
export async function POST(request: Request) {
  const body = await request.json();

  const djangoRes = await fetch(`${DJANGO_API_URL}/auth/login/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const data = await djangoRes.json();
  if (!djangoRes.ok) {
    return NextResponse.json(data, { status: djangoRes.status });
  }

  const response = NextResponse.json({ access: data.access, user: data.user });
  response.cookies.set(REFRESH_COOKIE, data.refresh, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7, // matches SIMPLE_JWT REFRESH_TOKEN_LIFETIME
  });
  return response;
}
