"use client";

import { LayoutDashboard, Users, UserCheck, FileText, CalendarCheck, NotebookPen, StickyNote, Bell, User } from "lucide-react";
import { RoleGuard } from "@/components/layout/role-guard";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import type { NavItem } from "@/components/layout/sidebar";
import { usePathname } from "next/navigation";

const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/teacher/dashboard", icon: LayoutDashboard },
  { label: "Student List", href: "/teacher/students", icon: Users },
  { label: "Approved Students", href: "/teacher/approved-students", icon: UserCheck },
  { label: "Applications", href: "/teacher/applications", icon: FileText },
  { label: "Attendance", href: "/teacher/attendance", icon: CalendarCheck },
  { label: "Reports", href: "/teacher/reports", icon: NotebookPen },
  { label: "Notes", href: "/teacher/notes", icon: StickyNote },
  { label: "Notifications", href: "/teacher/notifications", icon: Bell },
  { label: "Profile", href: "/teacher/profile", icon: User },
];

const TITLES: Record<string, string> = {
  "/teacher/dashboard": "Dashboard",
  "/teacher/students": "Student List",
  "/teacher/approved-students": "Approved Students",
  "/teacher/applications": "Applications",
  "/teacher/attendance": "Attendance",
  "/teacher/reports": "Reports",
  "/teacher/notes": "Notes",
  "/teacher/notifications": "Notifications",
  "/teacher/profile": "Profile",
};

export default function TeacherLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <RoleGuard role="TEACHER">
      <DashboardShell role="TEACHER" roleLabel="Teacher" navItems={NAV_ITEMS} title={TITLES[pathname] ?? "Teacher"}>
        {children}
      </DashboardShell>
    </RoleGuard>
  );
}
