"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface TeacherSummary {
  total_students: number;
  pending_applications: number;
  approved_students: number;
  active_fieldwork: number;
  reports_count: number;
}

export default function TeacherDashboardPage() {
  const [summary, setSummary] = useState<TeacherSummary | null>(null);

  useEffect(() => {
    api.get<TeacherSummary>("/dashboard/summary/").then((res) => setSummary(res.data));
  }, []);

  const cards = summary
    ? [
        { label: "Total students", value: summary.total_students },
        { label: "Pending applications", value: summary.pending_applications },
        { label: "Approved students", value: summary.approved_students },
        { label: "Active fieldwork", value: summary.active_fieldwork },
        { label: "Reports submitted", value: summary.reports_count },
      ]
    : null;

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
      {!cards
        ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24" />)
        : cards.map((c) => (
            <Card key={c.label}>
              <CardHeader>
                <CardTitle>{c.label}</CardTitle>
              </CardHeader>
              <CardContent className="text-2xl font-semibold">{c.value}</CardContent>
            </Card>
          ))}
    </div>
  );
}
