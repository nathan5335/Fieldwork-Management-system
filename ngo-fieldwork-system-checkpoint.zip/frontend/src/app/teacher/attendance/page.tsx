import { AttendanceMonitorContent } from "@/components/monitor/attendance-monitor-content";

export default function TeacherAttendancePage() {
  return <AttendanceMonitorContent />;
}
