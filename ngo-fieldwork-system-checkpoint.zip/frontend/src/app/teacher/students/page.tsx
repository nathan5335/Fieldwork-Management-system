"use client";

import { useState } from "react";
import { StudentsListContent } from "@/components/monitor/students-list-content";
import { StudentCreateForm } from "@/components/forms/student-create-form";

export default function TeacherStudentsPage() {
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="grid gap-6 xl:grid-cols-5">
      <div className="xl:col-span-2">
        <StudentCreateForm onCreated={() => setRefreshKey((k) => k + 1)} />
      </div>
      <div className="xl:col-span-3">
        <StudentsListContent refreshKey={refreshKey} />
      </div>
    </div>
  );
}
