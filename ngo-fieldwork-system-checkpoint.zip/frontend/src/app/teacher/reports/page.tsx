import { ReportsMonitorContent } from "@/components/monitor/reports-monitor-content";

export default function TeacherReportsPage() {
  return <ReportsMonitorContent />;
}
