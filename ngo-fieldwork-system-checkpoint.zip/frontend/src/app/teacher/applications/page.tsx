import { ApplicationReviewQueue } from "@/components/application/application-review-queue";

export default function TeacherApplicationsPage() {
  return <ApplicationReviewQueue pendingStatus="SUBMITTED_TO_TEACHER" reviewEndpoint="teacher-review" />;
}
