"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { getErrorMessage } from "@/lib/utils";
import type { Paginated } from "@/lib/types";

interface DocumentRow {
  id: number;
  title: string;
  file: string;
  uploaded_by_name: string;
  uploaded_at: string;
}

export default function TeacherNotesPage() {
  const [documents, setDocuments] = useState<DocumentRow[] | null>(null);
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = () =>
    api
      .get<Paginated<DocumentRow>>("/documents/", { params: { document_type: "TEACHER_NOTE" } })
      .then((res) => setDocuments(res.data.results));

  useEffect(() => {
    load();
  }, []);

  const handleUpload = async () => {
    setError(null);
    if (!title.trim() || !file) {
      setError("Title and file are both required.");
      return;
    }
    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("document_type", "TEACHER_NOTE");
      formData.append("title", title);
      formData.append("file", file);
      await api.post("/documents/", formData, { headers: { "Content-Type": "multipart/form-data" } });
      setTitle("");
      setFile(null);
      await load();
    } catch (err) {
      setError(getErrorMessage(err, "Upload failed."));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Upload a note</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>File (PDF)</Label>
              <Input type="file" accept=".pdf,.doc,.docx" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            </div>
            {error && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
            <Button onClick={handleUpload} disabled={submitting} className="w-full">
              {submitting ? "Uploading…" : "Upload note"}
            </Button>
          </CardContent>
        </Card>
      </div>
      <div className="lg:col-span-3">
        <Card>
          <CardHeader>
            <CardTitle>College notes</CardTitle>
          </CardHeader>
          <CardContent>
            {!documents ? (
              <Skeleton className="h-40" />
            ) : documents.length === 0 ? (
              <EmptyState className="border-0" title="No notes uploaded yet" />
            ) : (
              <div className="divide-y divide-border">
                {documents.map((d) => (
                  <a
                    key={d.id}
                    href={d.file}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-between py-3 text-sm hover:text-role-teacher"
                  >
                    <span>{d.title}</span>
                    <span className="text-xs text-muted">{d.uploaded_by_name}</span>
                  </a>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
