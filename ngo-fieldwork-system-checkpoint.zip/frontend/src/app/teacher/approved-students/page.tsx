import { ApprovedStudentsContent } from "@/components/monitor/approved-students-content";

export default function TeacherApprovedStudentsPage() {
  return <ApprovedStudentsContent />;
}
