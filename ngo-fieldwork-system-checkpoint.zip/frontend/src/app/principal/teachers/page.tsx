"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { Paginated } from "@/lib/types";

interface TeacherRow {
  id: number;
  user: { full_name: string; email: string; phone: string };
  employee_id: string;
  department: string;
  designation: string;
}

const schema = z.object({
  first_name: z.string().min(1, "Required"),
  last_name: z.string().optional(),
  email: z.string().email("Enter a valid email."),
  phone: z.string().optional(),
  password: z.string().min(8, "At least 8 characters."),
  employee_id: z.string().min(1, "Required"),
  department: z.string().min(1, "Required"),
  designation: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {error && <p className="text-xs text-danger">{error}</p>}
    </div>
  );
}

export default function PrincipalTeachersPage() {
  const [teachers, setTeachers] = useState<TeacherRow[] | null>(null);
  const [serverError, setServerError] = useState<string | null>(null);
  const [created, setCreated] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const load = useCallback(() => {
    api
      .get<Paginated<TeacherRow>>("/colleges/teachers/", { params: { page_size: 100 } })
      .then((res) => setTeachers(res.data.results));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const onSubmit = async (values: FormValues) => {
    setServerError(null);
    setCreated(null);
    try {
      await api.post("/auth/register/teacher/", values);
      setCreated(`${values.first_name} ${values.last_name ?? ""}`.trim());
      reset();
      load();
    } catch (err) {
      setServerError(getErrorMessage(err, "Could not create teacher."));
    }
  };

  const columns: Column<TeacherRow>[] = [
    { header: "Name", cell: (t) => t.user.full_name },
    { header: "Employee ID", cell: (t) => t.employee_id },
    { header: "Department", cell: (t) => t.department },
    { header: "Designation", cell: (t) => t.designation || "—" },
    { header: "Email", cell: (t) => t.user.email },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Add a teacher</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Field label="First name" error={errors.first_name?.message}>
                  <Input {...register("first_name")} />
                </Field>
                <Field label="Last name" error={errors.last_name?.message}>
                  <Input {...register("last_name")} />
                </Field>
              </div>
              <Field label="Email" error={errors.email?.message}>
                <Input type="email" {...register("email")} />
              </Field>
              <Field label="Phone" error={errors.phone?.message}>
                <Input {...register("phone")} />
              </Field>
              <Field label="Temporary password" error={errors.password?.message}>
                <Input type="password" autoComplete="new-password" {...register("password")} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Employee ID" error={errors.employee_id?.message}>
                  <Input {...register("employee_id")} />
                </Field>
                <Field label="Department" error={errors.department?.message}>
                  <Input {...register("department")} />
                </Field>
              </div>
              <Field label="Designation" error={errors.designation?.message}>
                <Input {...register("designation")} />
              </Field>
              {serverError && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{serverError}</p>}
              {created && (
                <p className="rounded-md bg-success/10 px-3 py-2 text-sm text-success">
                  {created} was added. Share the temporary password with them directly.
                </p>
              )}
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Creating…" : "Create teacher"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-3">
        <DataTable columns={columns} rows={teachers} keyFor={(t) => t.id} emptyTitle="No teachers added yet" />
      </div>
    </div>
  );
}
