"use client";

import { LayoutDashboard, Users, UserCheck, CalendarCheck, NotebookPen, FileText, Bell, User, GraduationCap } from "lucide-react";
import { RoleGuard } from "@/components/layout/role-guard";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import type { NavItem } from "@/components/layout/sidebar";
import { usePathname } from "next/navigation";

// Order follows the spec's Principal sidebar (section 47).
const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/principal/dashboard", icon: LayoutDashboard },
  { label: "Student List", href: "/principal/students", icon: Users },
  { label: "Approved Students", href: "/principal/approved-students", icon: UserCheck },
  { label: "Attendance", href: "/principal/attendance", icon: CalendarCheck },
  { label: "Reports", href: "/principal/reports", icon: NotebookPen },
  { label: "Student Applications", href: "/principal/applications", icon: FileText },
  { label: "Notifications", href: "/principal/notifications", icon: Bell },
  { label: "Profile", href: "/principal/profile", icon: User },
  { label: "Teachers", href: "/principal/teachers", icon: GraduationCap },
];

const TITLES: Record<string, string> = {
  "/principal/dashboard": "Dashboard",
  "/principal/students": "Student List",
  "/principal/approved-students": "Approved Students",
  "/principal/attendance": "Attendance",
  "/principal/reports": "Reports",
  "/principal/applications": "Student Applications",
  "/principal/notifications": "Notifications",
  "/principal/profile": "Profile",
  "/principal/teachers": "Teachers",
};

export default function PrincipalLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <RoleGuard role="PRINCIPAL">
      <DashboardShell role="PRINCIPAL" roleLabel="Principal" navItems={NAV_ITEMS} title={TITLES[pathname] ?? "Principal"}>
        {children}
      </DashboardShell>
    </RoleGuard>
  );
}
