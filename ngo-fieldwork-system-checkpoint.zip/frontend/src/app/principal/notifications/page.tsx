import { NotificationsPageContent } from "@/components/notifications/notifications-page-content";

export default function PrincipalNotificationsPage() {
  return <NotificationsPageContent />;
}
