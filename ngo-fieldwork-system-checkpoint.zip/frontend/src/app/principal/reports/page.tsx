import { ReportsMonitorContent } from "@/components/monitor/reports-monitor-content";

export default function PrincipalReportsPage() {
  return <ReportsMonitorContent />;
}
