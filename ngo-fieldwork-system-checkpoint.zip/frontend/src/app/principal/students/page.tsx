import { StudentsListContent } from "@/components/monitor/students-list-content";

export default function PrincipalStudentsPage() {
  return <StudentsListContent showTeacher />;
}
