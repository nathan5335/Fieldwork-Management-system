"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChartCard } from "@/components/charts/bar-chart-card";

interface PrincipalSummary {
  students: number;
  teachers: number;
  pending_applications: number;
  approved_applications: number;
  ongoing_fieldwork: number;
  ngo_distribution: { assigned_ngo__name: string; count: number }[];
  attendance_percentage: number;
  reports_count: number;
  grades_awarded: number;
}

export default function PrincipalDashboardPage() {
  const [summary, setSummary] = useState<PrincipalSummary | null>(null);

  useEffect(() => {
    api.get<PrincipalSummary>("/dashboard/summary/").then((res) => setSummary(res.data));
  }, []);

  if (!summary) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }

  const cards = [
    { label: "Students", value: summary.students },
    { label: "Teachers", value: summary.teachers },
    { label: "Pending applications", value: summary.pending_applications },
    { label: "Approved applications", value: summary.approved_applications },
    { label: "Ongoing fieldwork", value: summary.ongoing_fieldwork },
    { label: "Attendance", value: `${summary.attendance_percentage}%` },
    { label: "Reports", value: summary.reports_count },
    { label: "Grades awarded", value: summary.grades_awarded },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardHeader>
              <CardTitle>{c.label}</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">{c.value}</CardContent>
          </Card>
        ))}
      </div>

      <BarChartCard
        title="Students per NGO"
        data={summary.ngo_distribution.map((d) => ({ ngo: d.assigned_ngo__name, students: d.count }))}
        xKey="ngo"
        yKey="students"
        accent="--role-principal"
        emptyTitle="No students placed with an NGO yet"
      />
    </div>
  );
}
