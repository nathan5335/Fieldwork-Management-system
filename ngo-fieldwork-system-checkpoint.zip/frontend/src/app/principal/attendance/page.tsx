import { AttendanceMonitorContent } from "@/components/monitor/attendance-monitor-content";

export default function PrincipalAttendancePage() {
  return <AttendanceMonitorContent />;
}
