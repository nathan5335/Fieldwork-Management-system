import { ApprovedStudentsContent } from "@/components/monitor/approved-students-content";

export default function PrincipalApprovedStudentsPage() {
  return <ApprovedStudentsContent />;
}
