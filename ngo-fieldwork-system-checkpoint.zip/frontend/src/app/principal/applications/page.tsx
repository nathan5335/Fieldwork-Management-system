import { ApplicationReviewQueue } from "@/components/application/application-review-queue";

export default function PrincipalApplicationsPage() {
  return <ApplicationReviewQueue pendingStatus="PENDING_PRINCIPAL" reviewEndpoint="principal-review" />;
}
