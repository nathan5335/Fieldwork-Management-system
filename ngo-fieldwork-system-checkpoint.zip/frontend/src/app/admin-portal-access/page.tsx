import { AuthLayout } from "@/components/auth/auth-layout";
import { LoginForm } from "@/components/auth/login-form";

// Deliberately not linked from the landing page, navigation, or the shared
// /login page (spec section 13). This is a UX convenience only — every
// admin-only API endpoint independently enforces the ADMIN role
// server-side no matter which URL the request originated from.
export default function AdminPortalAccessPage() {
  return (
    <AuthLayout tagline={<>Quiet oversight.<br />Careful stewardship.</>}>
      <LoginForm heading="Admin access" subheading="Authorized personnel only." />
    </AuthLayout>
  );
}
