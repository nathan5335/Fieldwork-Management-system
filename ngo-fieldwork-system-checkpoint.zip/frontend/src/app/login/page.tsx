import Link from "next/link";
import { AuthLayout } from "@/components/auth/auth-layout";
import { LoginForm } from "@/components/auth/login-form";

export default function LoginPage() {
  return (
    <AuthLayout>
      <div className="flex flex-col items-center">
        <LoginForm
          heading="Welcome back"
          subheading="For Students, Teachers, Principals and NGO partners."
        />
        <p className="mt-6 text-sm text-muted">
          Registering a college?{" "}
          <Link href="/register/principal" className="text-brand hover:underline">
            Register as Principal
          </Link>
        </p>
        <p className="mt-2 text-sm text-muted">
          Representing an NGO?{" "}
          <Link href="/register/ngo" className="text-brand hover:underline">
            Register your organization
          </Link>
        </p>
      </div>
    </AuthLayout>
  );
}
