import Link from "next/link";
import { Leaf, ArrowRight, ClipboardCheck, GitBranch, ShieldCheck, Bell, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";

const STEPS = [
  { role: "Student", detail: "Submits a fieldwork application with three ranked NGO preferences." },
  { role: "Teacher", detail: "Reviews and approves before it reaches the Principal." },
  { role: "Principal", detail: "Approves, forwarding the request to all three selected NGOs." },
  { role: "NGO", detail: "Responds in priority order — accept, or the request moves to the next." },
  { role: "Fieldwork", detail: "Attendance, daily reports, geo-tagged photos, and a final grade." },
];

const FEATURES = [
  { icon: GitBranch, title: "Priority-based NGO matching", body: "An automatic cascade through a student's three ranked NGOs — no manual reassignment." },
  { icon: Bell, title: "Real-time notifications", body: "Every approval, rejection, and assignment arrives instantly, not by polling." },
  { icon: ShieldCheck, title: "Role-scoped access", body: "Every request is checked server-side against role, college, and assignment — never just a hidden button." },
  { icon: ClipboardCheck, title: "A full audit trail", body: "Every decision is timestamped and attributed, laid out on the application's timeline." },
  { icon: BarChart3, title: "Living dashboards", body: "Attendance, reports, and grades, computed from real data, shaped to each role." },
];

export default function LandingPage() {
  return (
    <div className="bg-background">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <span className="flex items-center gap-2">
          <Leaf className="h-4 w-4 text-brand" />
          <span className="font-serif text-base tracking-wide">FieldWork</span>
        </span>
        <nav className="flex items-center gap-5">
          <Link href="/register/ngo" className="text-sm text-muted hover:text-foreground">
            NGO registration
          </Link>
          <Link href="/register/principal" className="text-sm text-muted hover:text-foreground">
            Register a college
          </Link>
          <Button asChild size="sm">
            <Link href="/login">Sign in</Link>
          </Button>
        </nav>
      </header>

      <section className="relative overflow-hidden px-6 pb-20 pt-16">
        {/* Faint organic line decoration — no external imagery, kept extremely subtle */}
        <svg
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-0 h-[560px] w-[900px] -translate-x-1/2 text-brand opacity-[0.06]"
          viewBox="0 0 900 560"
          fill="none"
        >
          <path d="M60 520C120 380 180 160 420 60C560 140 540 340 400 460C300 542 150 538 60 520Z" stroke="currentColor" strokeWidth="1.5" />
          <path d="M780 40C740 160 660 300 520 380" stroke="currentColor" strokeWidth="1" />
        </svg>

        <div className="relative mx-auto max-w-3xl text-center">
          <h1 className="font-serif text-4xl leading-tight text-balance sm:text-5xl">
            Connecting students with meaningful field work.
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-muted">
            A shared home for colleges, students, and NGO partners — from application through
            NGO matching, daily attendance, and a final grade.
          </p>
          <div className="mt-9 flex justify-center gap-3">
            <Button size="lg" asChild>
              <Link href="/login">
                Sign in <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="secondary" asChild>
              <Link href="/register/principal">Register your college</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-surface py-16">
        <div className="mx-auto max-w-5xl px-6">
          <h2 className="font-serif text-2xl">How it works</h2>
          <p className="mt-1 text-sm text-muted">A smooth, transparent process for everyone involved.</p>
          <ol className="mt-8 grid gap-4 md:grid-cols-5">
            {STEPS.map((step, i) => (
              <li key={step.role} className="rounded-md border border-border bg-surface-raised p-4">
                <p className="font-serif text-lg text-brand">{String(i + 1).padStart(2, "0")}</p>
                <p className="mt-2 text-sm font-medium">{step.role}</p>
                <p className="mt-1 text-xs text-muted">{step.detail}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-16">
        <div className="grid gap-8 md:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title}>
              <div className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-surface">
                <f.icon className="h-4 w-4 text-brand" />
              </div>
              <h3 className="mt-3 text-sm font-medium">{f.title}</h3>
              <p className="mt-1 text-sm text-muted">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted">
        FieldWork — small steps, lasting change. A college fieldwork management platform.
      </footer>
    </div>
  );
}
