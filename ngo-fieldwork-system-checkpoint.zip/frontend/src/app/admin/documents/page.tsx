"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { api } from "@/lib/api";
import { DataTable, type Column } from "@/components/ui/data-table";
import type { Paginated } from "@/lib/types";

interface DocRow {
  id: number;
  title: string;
  document_type: string;
  file: string;
  uploaded_by_name: string;
  uploaded_at: string;
}

export default function AdminDocumentsPage() {
  const [rows, setRows] = useState<DocRow[] | null>(null);

  useEffect(() => {
    api.get<Paginated<DocRow>>("/documents/", { params: { page_size: 200 } }).then((r) => setRows(r.data.results));
  }, []);

  const columns: Column<DocRow>[] = [
    {
      header: "Title",
      cell: (d) => (
        <a href={d.file} target="_blank" rel="noreferrer" className="text-info hover:underline">
          {d.title}
        </a>
      ),
    },
    { header: "Type", cell: (d) => d.document_type.replace("_", " ").toLowerCase() },
    { header: "Uploaded by", cell: (d) => d.uploaded_by_name || "—" },
    { header: "Uploaded", cell: (d) => format(new Date(d.uploaded_at), "d MMM yyyy") },
  ];

  return <DataTable columns={columns} rows={rows} keyFor={(d) => d.id} emptyTitle="No documents uploaded yet" />;
}
