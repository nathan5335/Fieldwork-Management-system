"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { DataTable, type Column } from "@/components/ui/data-table";
import type { Paginated } from "@/lib/types";

interface GradeRow {
  id: number;
  student_name: string;
  ngo_name: string;
  grade: "A" | "B" | "C" | "D";
  remarks: string;
  awarded_at: string;
}

export default function AdminGradesPage() {
  const [rows, setRows] = useState<GradeRow[] | null>(null);

  useEffect(() => {
    api.get<Paginated<GradeRow>>("/reports/grades/", { params: { page_size: 200 } }).then((r) => setRows(r.data.results));
  }, []);

  const columns: Column<GradeRow>[] = [
    { header: "Student", cell: (g) => g.student_name },
    { header: "NGO", cell: (g) => g.ngo_name },
    { header: "Grade", cell: (g) => <Badge variant={g.grade === "A" || g.grade === "B" ? "success" : g.grade === "C" ? "warning" : "danger"}>{g.grade}</Badge> },
    { header: "Remarks", cell: (g) => g.remarks || "—" },
    { header: "Awarded", cell: (g) => format(new Date(g.awarded_at), "d MMM yyyy") },
  ];

  return <DataTable columns={columns} rows={rows} keyFor={(g) => g.id} emptyTitle="No grades awarded yet" />;
}
