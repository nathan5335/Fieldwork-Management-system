"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { api } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { DataTable, type Column } from "@/components/ui/data-table";
import { STATUS_LABEL, STATUS_VARIANT } from "@/lib/application-status";
import type { ApplicationStatus, Paginated } from "@/lib/types";

interface Row {
  id: number;
  student_name: string;
  student_number: string;
  college_name: string;
  status: ApplicationStatus;
  assigned_ngo_name: string;
  is_reapplication: boolean;
  created_at: string;
}

export default function AdminApplicationsPage() {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [status, setStatus] = useState("");

  useEffect(() => {
    api
      .get<Paginated<Row>>("/applications/", { params: { status: status || undefined, ordering: "-created_at", page_size: 100 } })
      .then((r) => setRows(r.data.results));
  }, [status]);

  const columns: Column<Row>[] = [
    { header: "#", cell: (a) => a.id },
    { header: "Student", cell: (a) => `${a.student_name} (${a.student_number})` },
    { header: "College", cell: (a) => a.college_name },
    { header: "Status", cell: (a) => <Badge variant={STATUS_VARIANT[a.status]}>{STATUS_LABEL[a.status]}</Badge> },
    { header: "Assigned NGO", cell: (a) => a.assigned_ngo_name || "—" },
    { header: "Type", cell: (a) => (a.is_reapplication ? "Reapplication" : "New") },
    { header: "Submitted", cell: (a) => format(new Date(a.created_at), "d MMM yyyy") },
  ];

  return (
    <div className="space-y-4">
      <select
        value={status}
        onChange={(e) => setStatus(e.target.value)}
        className="h-9 rounded-md border border-border bg-surface-raised px-3 text-sm outline-none focus-visible:ring-2 focus-visible:ring-role-admin"
      >
        <option value="">All statuses</option>
        {(Object.keys(STATUS_LABEL) as ApplicationStatus[]).map((s) => (
          <option key={s} value={s}>{STATUS_LABEL[s]}</option>
        ))}
      </select>
      <DataTable columns={columns} rows={rows} keyFor={(a) => a.id} emptyTitle="No applications match" />
    </div>
  );
}
