import { UsersTable } from "@/components/monitor/users-table";

export default function AdminPrincipalsPage() {
  return <UsersTable role="PRINCIPAL" />;
}
