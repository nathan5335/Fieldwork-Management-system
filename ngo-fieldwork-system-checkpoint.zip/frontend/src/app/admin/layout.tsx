"use client";

import {
  LayoutDashboard, Users, GraduationCap, UserSquare, School, Building2, HeartHandshake,
  FileText, CalendarCheck, NotebookPen, Award, FolderOpen, Bell, Settings,
} from "lucide-react";
import { RoleGuard } from "@/components/layout/role-guard";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import type { NavItem } from "@/components/layout/sidebar";
import { usePathname } from "next/navigation";

// Order follows the spec's Admin sidebar (section 51).
const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
  { label: "Users", href: "/admin/users", icon: Users },
  { label: "Students", href: "/admin/students", icon: GraduationCap },
  { label: "Teachers", href: "/admin/teachers", icon: UserSquare },
  { label: "Principals", href: "/admin/principals", icon: School },
  { label: "Colleges", href: "/admin/colleges", icon: Building2 },
  { label: "NGOs", href: "/admin/ngos", icon: HeartHandshake },
  { label: "Applications", href: "/admin/applications", icon: FileText },
  { label: "Attendance", href: "/admin/attendance", icon: CalendarCheck },
  { label: "Reports", href: "/admin/reports", icon: NotebookPen },
  { label: "Grades", href: "/admin/grades", icon: Award },
  { label: "Documents", href: "/admin/documents", icon: FolderOpen },
  { label: "Notifications", href: "/admin/notifications", icon: Bell },
  { label: "Settings", href: "/admin/settings", icon: Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const title = NAV_ITEMS.find((i) => i.href === pathname)?.label ?? "Admin";
  return (
    <RoleGuard role="ADMIN">
      <DashboardShell role="ADMIN" roleLabel="Administrator" navItems={NAV_ITEMS} title={title}>
        {children}
      </DashboardShell>
    </RoleGuard>
  );
}
