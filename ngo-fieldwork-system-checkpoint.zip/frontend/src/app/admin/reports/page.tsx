import { ReportsMonitorContent } from "@/components/monitor/reports-monitor-content";

export default function AdminReportsPage() {
  return <ReportsMonitorContent />;
}
