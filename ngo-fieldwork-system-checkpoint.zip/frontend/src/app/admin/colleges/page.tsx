"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { DataTable, type Column } from "@/components/ui/data-table";
import { Input } from "@/components/ui/input";
import type { Paginated } from "@/lib/types";

interface CollegeRow {
  id: number;
  name: string;
  code: string;
  district: string;
  state: string;
  official_email: string;
  contact_number: string;
}

export default function AdminCollegesPage() {
  const [rows, setRows] = useState<CollegeRow[] | null>(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const t = setTimeout(() => {
      api.get<Paginated<CollegeRow>>("/colleges/", { params: { search, page_size: 100 } }).then((r) => setRows(r.data.results));
    }, 250);
    return () => clearTimeout(t);
  }, [search]);

  const columns: Column<CollegeRow>[] = [
    { header: "College", cell: (c) => c.name },
    { header: "Code", cell: (c) => c.code },
    { header: "District", cell: (c) => c.district },
    { header: "State", cell: (c) => c.state },
    { header: "Email", cell: (c) => c.official_email },
    { header: "Contact", cell: (c) => c.contact_number },
  ];

  return (
    <div className="space-y-4">
      <Input placeholder="Search name, code, district…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
      <DataTable columns={columns} rows={rows} keyFor={(c) => c.id} emptyTitle="No colleges registered" />
    </div>
  );
}
