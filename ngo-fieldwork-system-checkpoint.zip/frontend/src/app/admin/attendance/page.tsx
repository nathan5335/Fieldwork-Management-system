import { AttendanceMonitorContent } from "@/components/monitor/attendance-monitor-content";

export default function AdminAttendancePage() {
  return <AttendanceMonitorContent />;
}
