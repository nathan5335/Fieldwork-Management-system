"use client";

import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Read-only on purpose: the backend has no editable system-settings model,
// and a form that saved nothing would be a fake control. This page shows
// where the app is pointed and links to the real API documentation.
export default function AdminSettingsPage() {
  const { user } = useAuth();
  const api = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api";
  const ws = process.env.NEXT_PUBLIC_WS_URL ?? "ws://localhost:8000/ws";
  const apiRoot = api.replace(/\/api\/?$/, "");

  const rows: [string, React.ReactNode][] = [
    ["Signed in as", user?.email ?? "—"],
    ["REST API", api],
    ["WebSocket endpoint", `${ws}/notifications/`],
    ["API documentation", <a key="d" href={`${apiRoot}/api/docs/`} target="_blank" rel="noreferrer" className="text-info hover:underline">Open Swagger UI</a>],
    ["Django admin (debugging)", <a key="a" href={`${apiRoot}/admin/`} target="_blank" rel="noreferrer" className="text-info hover:underline">Open</a>],
  ];

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle>System information</CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between gap-4 border-b border-border/60 py-2 text-sm last:border-0">
            <span className="text-muted">{label}</span>
            <span className="text-right font-medium">{value}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
