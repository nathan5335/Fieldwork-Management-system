"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { getErrorMessage } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable, type Column } from "@/components/ui/data-table";
import type { Paginated } from "@/lib/types";

interface NGORow {
  id: number;
  name: string;
  contact_person: string;
  email: string;
  areas_of_work: string;
  is_verified: boolean;
  verification_documents: { id: number; file: string; label: string }[];
}

export default function AdminNGOsPage() {
  const [rows, setRows] = useState<NGORow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const load = useCallback(() => {
    api.get<Paginated<NGORow>>("/ngos/", { params: { page_size: 100 } }).then((r) => setRows(r.data.results));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const setVerified = async (ngo: NGORow, is_verified: boolean) => {
    setError(null);
    setBusyId(ngo.id);
    try {
      await api.post(`/ngos/${ngo.id}/verify/`, { is_verified });
      load();
    } catch (err) {
      setError(getErrorMessage(err, "Could not update verification."));
    } finally {
      setBusyId(null);
    }
  };

  const columns: Column<NGORow>[] = [
    { header: "NGO", cell: (n) => n.name },
    { header: "Contact", cell: (n) => `${n.contact_person} · ${n.email}` },
    { header: "Areas of work", cell: (n) => n.areas_of_work },
    {
      header: "Documents",
      cell: (n) =>
        n.verification_documents.length === 0 ? (
          <span className="text-muted">None uploaded</span>
        ) : (
          <div className="flex flex-col gap-0.5">
            {n.verification_documents.map((d) => (
              <a key={d.id} href={d.file} target="_blank" rel="noreferrer" className="text-info hover:underline">
                {d.label || "Document"}
              </a>
            ))}
          </div>
        ),
    },
    { header: "Status", cell: (n) => <Badge variant={n.is_verified ? "success" : "warning"}>{n.is_verified ? "Verified" : "Pending"}</Badge> },
    {
      header: "Action",
      cell: (n) => (
        <Button
          size="sm"
          variant={n.is_verified ? "outline" : "success"}
          disabled={busyId === n.id}
          onClick={() => setVerified(n, !n.is_verified)}
        >
          {n.is_verified ? "Revoke" : "Verify"}
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted">
        Students can only choose verified NGOs. Newly registered NGOs stay hidden until verified here.
      </p>
      {error && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
      <DataTable columns={columns} rows={rows} keyFor={(n) => n.id} emptyTitle="No NGOs registered" />
    </div>
  );
}
