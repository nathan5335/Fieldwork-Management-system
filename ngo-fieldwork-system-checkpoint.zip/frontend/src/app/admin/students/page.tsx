import { UsersTable } from "@/components/monitor/users-table";

export default function AdminStudentsPage() {
  return <UsersTable role="STUDENT" />;
}
