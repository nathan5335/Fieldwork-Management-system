"use client";

import { useEffect, useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmptyState } from "@/components/ui/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChartCard } from "@/components/charts/bar-chart-card";

interface AdminSummary {
  total_users: number;
  students: number;
  teachers: number;
  principals: number;
  ngos: number;
  colleges: number;
  applications: number;
  active_fieldwork: number;
  completed_fieldwork: number;
  reports: number;
  photos: number;
  attendance_records: number;
  grades: number;
  recent_activity: { action: string; role: string; created_at: string; user__email: string | null; application_id: number }[];
}

export default function AdminDashboardPage() {
  const [s, setS] = useState<AdminSummary | null>(null);

  useEffect(() => {
    api.get<AdminSummary>("/dashboard/summary/").then((res) => setS(res.data));
  }, []);

  if (!s) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {Array.from({ length: 12 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }

  const cards = [
    ["Total users", s.total_users], ["Students", s.students], ["Teachers", s.teachers], ["Principals", s.principals],
    ["NGOs", s.ngos], ["Colleges", s.colleges], ["Applications", s.applications], ["Active fieldwork", s.active_fieldwork],
    ["Completed fieldwork", s.completed_fieldwork], ["Reports", s.reports], ["Attendance records", s.attendance_records], ["Grades", s.grades],
  ] as const;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {cards.map(([label, value]) => (
          <Card key={label}>
            <CardHeader>
              <CardTitle>{label}</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">{value}</CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <BarChartCard
          title="Accounts by role"
          accent="--role-admin"
          xKey="role"
          yKey="accounts"
          data={[
            { role: "Students", accounts: s.students },
            { role: "Teachers", accounts: s.teachers },
            { role: "Principals", accounts: s.principals },
            { role: "NGOs", accounts: s.ngos },
          ]}
        />
        <Card>
          <CardHeader>
            <CardTitle>Recent system activity</CardTitle>
          </CardHeader>
          <CardContent>
            {s.recent_activity.length === 0 ? (
              <EmptyState className="border-0" title="No activity yet" />
            ) : (
              <ul className="divide-y divide-border">
                {s.recent_activity.map((a, i) => (
                  <li key={i} className="flex items-center justify-between py-2.5 text-sm">
                    <span>
                      <span className="font-medium">{a.action}</span>{" "}
                      <span className="text-muted">
                        on application #{a.application_id} by {a.user__email ?? "system"} ({a.role.toLowerCase() || "n/a"})
                      </span>
                    </span>
                    <span className="shrink-0 pl-3 text-xs text-muted-soft">
                      {formatDistanceToNow(new Date(a.created_at), { addSuffix: true })}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
