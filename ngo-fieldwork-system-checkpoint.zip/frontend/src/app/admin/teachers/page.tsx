import { UsersTable } from "@/components/monitor/users-table";

export default function AdminTeachersPage() {
  return <UsersTable role="TEACHER" />;
}
