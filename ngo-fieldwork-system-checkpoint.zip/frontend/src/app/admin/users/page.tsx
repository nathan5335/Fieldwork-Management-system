import { UsersTable } from "@/components/monitor/users-table";

export default function AdminUsersPage() {
  return <UsersTable />;
}
