"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { Application, Paginated } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { NGOPriorityForm } from "@/components/application/ngo-priority-form";
import { ApplicationTimeline } from "@/components/application/application-timeline";
import { STATUS_LABEL, STATUS_VARIANT } from "@/lib/application-status";
import { getErrorMessage } from "@/lib/utils";

export default function StudentApplicationPage() {
  const [application, setApplication] = useState<Application | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionError, setActionError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.get<Paginated<{ id: number }>>("/applications/?ordering=-created_at&page_size=1");
      if (list.data.results.length === 0) {
        setApplication(null);
      } else {
        const detail = await api.get<Application>(`/applications/${list.data.results[0].id}/`);
        setApplication(detail.data);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) return <Skeleton className="h-64" />;

  if (!application) {
    return (
      <div className="max-w-lg">
        <Card>
          <CardHeader>
            <CardTitle>Submit your fieldwork application</CardTitle>
          </CardHeader>
          <CardContent>
            <NGOPriorityForm
              submitLabel="Submit application"
              onSubmit={async (priorities) => {
                await api.post("/applications/submit/", priorities);
                await load();
              }}
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  const priorityOne = application.ngo_priorities.find((p) => p.priority === 1);
  const canCancelPriorityOne = application.status === "NGO_REVIEW" && priorityOne?.status === "ACTIVATED";
  const canReapply = application.status === "ALL_NGOS_REJECTED";

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="space-y-6 lg:col-span-3">
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base font-semibold text-foreground">Application status</CardTitle>
            <Badge variant={STATUS_VARIANT[application.status]}>{STATUS_LABEL[application.status]}</Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            {application.status === "TEACHER_REJECTED" && application.teacher_rejection_reason && (
              <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">
                Teacher&apos;s reason: {application.teacher_rejection_reason}
              </p>
            )}
            {application.status === "PRINCIPAL_REJECTED" && application.principal_rejection_reason && (
              <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">
                Principal&apos;s reason: {application.principal_rejection_reason}
              </p>
            )}
            {application.assigned_ngo && (
              <p className="text-sm">
                Assigned to <span className="font-medium">{application.assigned_ngo.name}</span>
              </p>
            )}

            {actionError && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{actionError}</p>}

            {canCancelPriorityOne && (
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  setActionError(null);
                  try {
                    await api.post(`/applications/${application.id}/cancel-priority-one/`);
                    await load();
                  } catch (err) {
                    setActionError(getErrorMessage(err, "Could not cancel."));
                  }
                }}
              >
                Cancel Priority 1
              </Button>
            )}
          </CardContent>
        </Card>

        {canReapply && (
          <Card>
            <CardHeader>
              <CardTitle>All selected NGOs have rejected this application.</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4 text-sm text-muted">
                You may submit a new application with different NGO preferences.
              </p>
              <NGOPriorityForm
                submitLabel="Reapply"
                onSubmit={async (priorities) => {
                  await api.post(`/applications/${application.id}/reapply/`, priorities);
                  await load();
                }}
              />
            </CardContent>
          </Card>
        )}
      </div>

      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <ApplicationTimeline application={application} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
