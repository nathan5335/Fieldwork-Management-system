"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import type { Paginated, Report } from "@/lib/types";
import { getErrorMessage } from "@/lib/utils";

const STATUS_VARIANT: Record<Report["status"], "neutral" | "success" | "warning" | "danger" | "info"> = {
  SUBMITTED: "info",
  UNDER_REVIEW: "warning",
  APPROVED: "success",
  REVISION_REQUIRED: "danger",
};

export default function StudentReportsPage() {
  const [reports, setReports] = useState<Report[] | null>(null);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = () =>
    api.get<Paginated<Report>>("/reports/?ordering=-date").then((res) => setReports(res.data.results));

  useEffect(() => {
    load();
  }, []);

  const todaysAttempts = reports?.filter((r) => r.date === date).length ?? 0;

  const handleSubmit = async () => {
    setError(null);
    if (!title.trim()) {
      setError("Title is required.");
      return;
    }
    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("date", date);
      formData.append("title", title);
      formData.append("description", description);
      if (file) formData.append("file", file);
      await api.post("/reports/submit/", formData, { headers: { "Content-Type": "multipart/form-data" } });
      setTitle("");
      setDescription("");
      setFile(null);
      await load();
    } catch (err) {
      setError(getErrorMessage(err, "Could not submit report."));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Submit a daily report</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              <p className="text-xs text-muted">
                {todaysAttempts}/3 attempts used for this date.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label>Title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Day 3 — literacy workshop" />
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                className="w-full rounded-md border border-border bg-surface-raised px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-role-student"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Attachment (optional)</Label>
              <Input type="file" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            </div>
            {error && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
            <Button onClick={handleSubmit} disabled={submitting || todaysAttempts >= 3} className="w-full">
              {todaysAttempts >= 3 ? "Daily limit reached (3/3)" : submitting ? "Submitting…" : "Submit report"}
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="lg:col-span-3">
        <Card>
          <CardHeader>
            <CardTitle>Report history</CardTitle>
          </CardHeader>
          <CardContent>
            {!reports ? (
              <Skeleton className="h-40" />
            ) : reports.length === 0 ? (
              <EmptyState className="border-0" title="No reports submitted yet" />
            ) : (
              <div className="space-y-3">
                {reports.map((r) => (
                  <div key={r.id} className="rounded-md border border-border p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">
                        {r.title} <span className="text-xs text-muted">— {r.date} (attempt {r.attempt_number})</span>
                      </p>
                      <Badge variant={STATUS_VARIANT[r.status]}>{r.status.replace("_", " ")}</Badge>
                    </div>
                    {r.description && <p className="mt-1 text-sm text-muted">{r.description}</p>}
                    {r.feedback && (
                      <p className="mt-2 rounded-md bg-surface-raised px-2 py-1 text-xs text-muted">
                        Feedback: {r.feedback}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
