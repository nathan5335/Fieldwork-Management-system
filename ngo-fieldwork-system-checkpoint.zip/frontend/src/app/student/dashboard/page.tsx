"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import type { StudentDashboardSummary } from "@/lib/types";
import { STATUS_LABEL, STATUS_VARIANT } from "@/lib/application-status";

export default function StudentDashboardPage() {
  const [summary, setSummary] = useState<StudentDashboardSummary | null>(null);

  useEffect(() => {
    api.get<StudentDashboardSummary>("/dashboard/summary/").then((res) => setSummary(res.data));
  }, []);

  if (!summary) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
    );
  }

  const cards = [
    {
      label: "Application status",
      value: summary.application_status ? (
        <Badge variant={STATUS_VARIANT[summary.application_status]}>
          {STATUS_LABEL[summary.application_status]}
        </Badge>
      ) : (
        <span className="text-sm text-muted">No application yet</span>
      ),
    },
    { label: "Assigned NGO", value: summary.assigned_ngo ?? "—" },
    { label: "Attendance", value: `${summary.attendance_percentage}%` },
    { label: "Reports submitted", value: summary.reports_submitted },
    { label: "Current grade", value: summary.current_grade ?? "—" },
    { label: "Unread notifications", value: summary.pending_notifications },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardHeader>
              <CardTitle>{c.label}</CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">{c.value}</CardContent>
          </Card>
        ))}
      </div>

      {!summary.application_status && (
        <Card>
          <CardContent className="flex items-center justify-between p-5">
            <div>
              <p className="text-sm font-medium">You haven&apos;t submitted a fieldwork application yet.</p>
              <p className="mt-1 text-sm text-muted">
                Pick three NGOs in priority order to get started.
              </p>
            </div>
            <Link href="/student/application" className="text-sm font-medium text-role-student hover:underline">
              Submit application →
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
