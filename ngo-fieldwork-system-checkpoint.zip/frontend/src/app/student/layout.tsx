"use client";

import { LayoutDashboard, FileText, CalendarCheck, NotebookPen, Camera, Bell, User } from "lucide-react";
import { RoleGuard } from "@/components/layout/role-guard";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import type { NavItem } from "@/components/layout/sidebar";
import { usePathname } from "next/navigation";

const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/student/dashboard", icon: LayoutDashboard },
  { label: "Application", href: "/student/application", icon: FileText },
  { label: "Attendance", href: "/student/attendance", icon: CalendarCheck },
  { label: "Daily Reports", href: "/student/reports", icon: NotebookPen },
  { label: "Geo-Tagged Photos", href: "/student/photos", icon: Camera },
  { label: "Notifications", href: "/student/notifications", icon: Bell },
  { label: "Profile", href: "/student/profile", icon: User },
];

const TITLES: Record<string, string> = {
  "/student/dashboard": "Dashboard",
  "/student/application": "My Application",
  "/student/attendance": "Attendance",
  "/student/reports": "Daily Reports",
  "/student/photos": "Geo-Tagged Photos",
  "/student/notifications": "Notifications",
  "/student/profile": "Profile",
};

export default function StudentLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <RoleGuard role="STUDENT">
      <DashboardShell
        role="STUDENT"
        roleLabel="Student"
        navItems={NAV_ITEMS}
        title={TITLES[pathname] ?? "Student"}
      >
        {children}
      </DashboardShell>
    </RoleGuard>
  );
}
