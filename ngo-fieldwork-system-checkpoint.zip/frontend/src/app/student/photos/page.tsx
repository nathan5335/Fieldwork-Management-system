"use client";

import { useEffect, useState } from "react";
import { Camera } from "lucide-react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import { getErrorMessage } from "@/lib/utils";
import type { Paginated } from "@/lib/types";

interface PhotoUpload {
  id: number;
  image: string;
  caption: string;
  taken_at: string;
}

export default function StudentPhotosPage() {
  const [photos, setPhotos] = useState<PhotoUpload[] | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = () =>
    api.get<Paginated<PhotoUpload>>("/reports/photos/").then((res) => setPhotos(res.data.results));

  useEffect(() => {
    load();
  }, []);

  const handleUpload = async () => {
    setError(null);
    if (!file) {
      setError("Choose a photo first.");
      return;
    }
    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append("image", file);
      formData.append("caption", caption);
      await api.post("/reports/photos/upload/", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setFile(null);
      setCaption("");
      await load();
    } catch (err) {
      setError(getErrorMessage(err, "Upload failed."));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="max-w-lg">
        <CardHeader>
          <CardTitle>Upload fieldwork evidence</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Photo</Label>
            <Input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
            <p className="text-xs text-muted">On mobile, this opens your camera directly.</p>
          </div>
          <div className="space-y-1.5">
            <Label>Caption (optional)</Label>
            <Input value={caption} onChange={(e) => setCaption(e.target.value)} />
          </div>
          {error && <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
          <Button onClick={handleUpload} disabled={submitting} className="w-full">
            <Camera className="h-4 w-4" /> {submitting ? "Uploading…" : "Upload photo"}
          </Button>
        </CardContent>
      </Card>

      <div>
        <h2 className="mb-3 text-sm font-medium text-muted">Your uploads</h2>
        {!photos ? (
          <Skeleton className="h-40" />
        ) : photos.length === 0 ? (
          <EmptyState title="No photos uploaded yet" />
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {photos.map((p) => (
              <div key={p.id} className="overflow-hidden rounded-md border border-border">
                {/* eslint-disable-next-line @next/next/no-img-element -- user-uploaded photo, not a static asset */}
                <img src={p.image} alt={p.caption || "Fieldwork photo"} className="aspect-square w-full object-cover" />
                {p.caption && <p className="p-2 text-xs text-muted">{p.caption}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
