import { NotificationsPageContent } from "@/components/notifications/notifications-page-content";

export default function StudentNotificationsPage() {
  return <NotificationsPageContent />;
}
