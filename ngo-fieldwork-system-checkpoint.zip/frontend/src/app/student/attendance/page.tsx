"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";
import type { AttendanceRecord, Paginated } from "@/lib/types";

interface Summary {
  working_days: number;
  present: number;
  absent: number;
  attendance_percentage: number;
}

export default function StudentAttendancePage() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [records, setRecords] = useState<AttendanceRecord[] | null>(null);

  useEffect(() => {
    api.get<Summary>("/attendance/my-summary/").then((res) => setSummary(res.data));
    api
      .get<Paginated<AttendanceRecord>>("/attendance/?ordering=-date")
      .then((res) => setRecords(res.data.results));
  }, []);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {summary ? (
          <>
            <StatCard label="Working days" value={summary.working_days} />
            <StatCard label="Present" value={summary.present} />
            <StatCard label="Absent" value={summary.absent} />
            <StatCard label="Attendance %" value={`${summary.attendance_percentage}%`} />
          </>
        ) : (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20" />)
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Attendance history</CardTitle>
        </CardHeader>
        <CardContent>
          {!records ? (
            <Skeleton className="h-40" />
          ) : records.length === 0 ? (
            <EmptyState
              className="border-0"
              title="No attendance marked yet"
              description="Your NGO marks daily attendance once your fieldwork begins."
            />
          ) : (
            <div className="divide-y divide-border">
              {records.map((r) => (
                <div key={r.id} className="flex items-center justify-between py-3 text-sm">
                  <div>
                    <p className="font-medium">{r.date}</p>
                    {r.activity && <p className="text-xs text-muted">{r.activity}</p>}
                  </div>
                  <Badge variant={r.status === "PRESENT" ? "success" : "danger"}>{r.status}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{label}</CardTitle>
      </CardHeader>
      <CardContent className="text-2xl font-semibold">{value}</CardContent>
    </Card>
  );
}
